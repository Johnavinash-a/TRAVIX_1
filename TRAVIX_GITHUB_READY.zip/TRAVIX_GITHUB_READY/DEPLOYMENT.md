# TRAVIX Deployment Guide

This guide covers deploying TRAVIX to various platforms.

## Quick Start: Docker Compose (Recommended)

```bash
# 1. Clone and configure
git clone <your-repo>
cd travix
cp .env.production .env
# Edit .env with your secrets

# 2. Deploy
docker-compose up -d --build

# 3. Verify
curl http://localhost:5000/api/health
```

Services:
- Web: http://localhost:5000
- Spatial API: http://localhost:8000
- PostGIS: localhost:5432

## Cloud Platform Deployment

### Railway (Easiest)

1. Connect GitHub repo to Railway
2. Add these environment variables in Railway dashboard:
   ```
   NODE_ENV=production
   JWT_SECRET=<generate: openssl rand -base64 32>
   GEMINI_API_KEY=<your-key>
   OPENWEATHER_API_KEY=<your-key>
   VITE_MAPBOX_TOKEN=<your-token>
   POSTGRES_PASSWORD=<secure-password>
   ```
3. Add PostgreSQL service in Railway (auto-sets `DATABASE_URL`)
4. Deploy - Railway auto-detects Dockerfile

### Render

1. Create Web Service from GitHub
2. Settings:
   - **Build Command**: `docker build -t travix .`
   - **Start Command**: `node server/start.js`
   - **Dockerfile Path**: `./Dockerfile`
3. Add PostgreSQL database in Render
4. Set environment variables (same as Railway)

### Fly.io

```bash
# Install flyctl
curl -L https://fly.io/install.sh | sh

# Launch
fly launch --dockerfile Dockerfile

# Set secrets
fly secrets set JWT_SECRET=$(openssl rand -base64 32)
fly secrets set GEMINI_API_KEY=xxx
fly secrets set OPENWEATHER_API_KEY=xxx
fly secrets set VITE_MAPBOX_TOKEN=xxx

# Deploy
fly deploy
```

### Docker Swarm / Kubernetes

```bash
# Build and push images
docker build -t your-registry/travix-web:latest .
docker build -t your-registry/travix-spatial:latest -f Dockerfile.spatial .
docker push your-registry/travix-web:latest
docker push your-registry/travix-spatial:latest

# Deploy to K8s (see k8s/ directory for manifests)
kubectl apply -f k8s/
```

## Required Secrets Checklist

| Secret | Required | Purpose |
|--------|----------|---------|
| `JWT_SECRET` | ✅ Yes | Auth token signing |
| `POSTGRES_PASSWORD` | ✅ Yes | Database password |
| `GEMINI_API_KEY` | Optional | AI responses |
| `OPENWEATHER_API_KEY` | Optional | Live weather |
| `VITE_MAPBOX_TOKEN` | Optional | Real map tiles |

## SSL/HTTPS

All cloud platforms provide automatic HTTPS. For self-hosted:

```bash
# With nginx reverse proxy + Let's Encrypt
# See nginx.conf.example for config
```

## Health Checks

All services expose `/health` or `/api/health`:
- Web: `GET /api/health`
- Spatial: `GET /health`
- Database: `pg_isready`

## Scaling

- Web: Stateless, scale horizontally behind load balancer
- Spatial: 2+ workers (`--workers 2` in Dockerfile.spatial)
- Database: Read replicas for heavy read workloads

## Monitoring

Add to your platform:
- Log aggregation (Datadog, Logtail, etc.)
- APM (Sentry for errors, custom metrics for AI latency)
- Uptime checks on `/api/health`

## Backup

```bash
# Database backup
docker exec travix-postgis pg_dump -U postgres travelwise > backup.sql

# Restore
docker exec -i travix-postgis psql -U postgres travelwise < backup.sql
```

## Rollback

```bash
# Docker Compose
docker-compose pull && docker-compose up -d

# Fly.io
fly releases
fly deploy --image <previous-release-image>

# Railway/Render: Use dashboard rollback
```