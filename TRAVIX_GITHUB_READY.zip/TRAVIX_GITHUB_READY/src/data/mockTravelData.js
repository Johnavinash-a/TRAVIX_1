/**
 * TRAVIX — AI Travel Intelligence Mock Database & Itinerary Synthesizer
 * 
 * Provides curated, rich travel plans for destinations (Himachal, Coorg, Ladakh, etc.)
 * and a dynamic generator for any custom destination entered by the user.
 */

export const INITIAL_SUGGESTED_PROMPTS = [
  "Plan a 5-day trip to Himachal",
  "Find a peaceful weekend getaway",
  "Plan a budget trip for 4 people",
  "Best places to visit in December"
];

export const FOLLOW_UP_QUESTIONS = [
  {
    id: "budget",
    question: "What's your approximate budget?",
    options: [
      { label: "₹10,000", value: "₹10,000", description: "Budget Explorer" },
      { label: "₹20,000", value: "₹20,000", description: "Comfort & Scenic" },
      { label: "₹30,000+", value: "₹30,000+", description: "Premium Mountain Stays" },
      { label: "Luxury", value: "Luxury", description: "Signature Heritage & Resorts" }
    ]
  },
  {
    id: "travelers",
    question: "How many people are travelling?",
    options: [
      { label: "1", value: "1", description: "Solo Explorer" },
      { label: "2", value: "2", description: "Couple / Duo" },
      { label: "3–5", value: "3–5", description: "Friends / Family" },
      { label: "6+", value: "6+", description: "Group Expedition" }
    ]
  },
  {
    id: "experience",
    question: "What kind of experience do you want?",
    options: [
      { label: "Adventure", value: "Adventure", icon: "Compass" },
      { label: "Nature", value: "Nature", icon: "Trees" },
      { label: "Relaxation", value: "Relaxation", icon: "Sparkles" },
      { label: "Culture", value: "Culture", icon: "Landmark" },
      { label: "Food", value: "Food", icon: "Utensils" },
      { label: "Mixed", value: "Mixed", icon: "Flame" }
    ]
  }
];

// Pre-curated detailed itinerary packages for popular prompt targets
export const CURATED_PLANS = {
  himachal: {
    destinationName: "Himachal Pradesh",
    title: "YOUR HIMACHAL JOURNEY",
    durationText: "5 Days • 4 Nights",
    durationDays: 5,
    tagline: "Glacial rivers, cedar forests, high-altitude passes and serene mountain sanctuaries",
    heroImage: "/himalayan-bg.jpg",
    matchPercentage: 98,
    estimatedBudget: "₹18,500 – ₹24,000 / person",
    weatherOverview: "14°C Highs / 4°C Nights • Clear Himalayan Skies",
    bestTimeToVisit: "March to June & September to December",
    elevation: "2,050m – 3,978m MSL",
    routeStats: {
      totalDistance: "468 km",
      waypointsCount: 5,
      drivingTime: "11 hrs total driving",
      difficulty: "Moderate Mountain Route"
    },
    itinerary: [
      {
        day: 1,
        title: "Arrival & Mountain Escape",
        theme: "Acclimatization & Cedar Groves",
        overview: "Arrive in Kullu-Manali Valley, settle into your wooden chalet, and take an evening stroll along ancient cedar paths.",
        morning: "Scenic arrival alongside rushing Beas River. Spiced mountain Kahwa welcome drink at check-in.",
        afternoon: "Walk through Old Manali pine trails, discovering hidden stone cafes and local weavers.",
        evening: "Sunset at Hadimba Cedar Grove followed by traditional Himachali siddu tasting by the hearth.",
        stay: "Himalayan Pine Chalet",
        coordinates: { lat: 32.2432, lng: 77.1892, name: "Old Manali Valley" }
      },
      {
        day: 2,
        title: "Explore the Valley",
        theme: "Alpine Streams & Apple Orchards",
        overview: "Trek to pristine Jogini Waterfalls and spend a tranquil afternoon amidst apple orchards in Vashisht.",
        morning: "Scenic hike to upper Jogini Falls with panoramic views of snow-crested Dhauladhar peaks.",
        afternoon: "Relax by the natural sulfur thermal springs in Vashisht village and visit 1,000-year-old stone shrines.",
        evening: "Riverside café session with freshly roasted mountain coffee and acoustic live folk tunes.",
        stay: "Himalayan Pine Chalet",
        coordinates: { lat: 32.2612, lng: 77.1952, name: "Jogini Falls & Vashisht" }
      },
      {
        day: 3,
        title: "Adventure Day",
        theme: "Adrenaline & High Passes",
        overview: "Ascend through the engineering marvel of Atal Tunnel into the alpine snow wonderland of Sissu & Solang.",
        morning: "Drive through the 9.02 km Atal Tunnel emerging into the stark moonscapes of Lahaul Valley.",
        afternoon: "Experience Sissu waterfall, river crossing zipline, or paragliding over Solang Valley snow meadows.",
        evening: "Return to valley for a high-altitude stargazing session with zero light pollution.",
        stay: "Himalayan Pine Chalet",
        coordinates: { lat: 32.4824, lng: 77.1264, name: "Solang & Atal Tunnel / Sissu" }
      },
      {
        day: 4,
        title: "Hidden Mountain Experiences",
        theme: "Art, Monasteries & Naggar Castle",
        overview: "Explore Naggar, the medieval capital of Kullu kings, Nicholas Roerich Art Gallery, and riverside camps.",
        morning: "Drive to Naggar Castle, an awe-inspiring blend of Himalayan stone and wood architecture overlooking the valley.",
        afternoon: "Visit the international Roerich Himalayan Estate and sample artisan wood-fired trout and apple crumble.",
        evening: "Cozy bonfire night with traditional mountain storytelling and stargazing.",
        stay: "Naggar Heritage Woods Resort",
        coordinates: { lat: 32.1465, lng: 77.1685, name: "Naggar Castle & Heritage Ridge" }
      },
      {
        day: 5,
        title: "Departure",
        theme: "Riverside Contemplation",
        overview: "Morning riverside yoga, collecting handcrafted woolens and wild blossom honey before departure.",
        morning: "Gentle sunrise stroll along Beas riverside path and souvenir stop at Kullu Shawl Weavers Collective.",
        afternoon: "Scenic downhill transfer towards Chandigarh/Delhi or Bhuntar airport with mountain memories.",
        evening: "Safe arrival and trip wrap-up.",
        stay: "Departure Day",
        coordinates: { lat: 31.9579, lng: 77.1095, name: "Kullu Valley Gateway" }
      }
    ],
    destinations: [
      {
        name: "Old Manali & Hadimba Forest",
        type: "Alpine Village",
        image: "https://images.unsplash.com/photo-1626621341517-bbf3d9990a23?auto=format&fit=crop&w=800&q=80",
        highlight: "Ancient deodar forests & bohemian mountain cafes",
        elevation: "2,050m"
      },
      {
        name: "Atal Tunnel & Sissu Lahaul",
        type: "Engineering Wonder & High Valley",
        image: "https://images.unsplash.com/photo-1596761229094-1a3bcf5e8d91?auto=format&fit=crop&w=800&q=80",
        highlight: "Gateway to Lahaul with hanging glacial waterfalls",
        elevation: "3,060m"
      },
      {
        name: "Naggar Medieval Castle",
        type: "Himalayan Heritage",
        image: "https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=800&q=80",
        highlight: "15th-century wood & stone architecture with valley vista",
        elevation: "1,800m"
      }
    ],
    experiences: [
      {
        title: "Solang Valley Paragliding",
        category: "Adventure",
        duration: "45 mins",
        rating: 4.9,
        description: "Soar above pine canopies with certified tandem pilots overlooking snow-capped ranges."
      },
      {
        title: "Tibetan Monastery Chanting & Meditation",
        category: "Culture",
        duration: "1.5 hrs",
        rating: 4.8,
        description: "Witness serene morning prayer rituals and spinning prayer wheels at Gadhan Thekchhokling."
      },
      {
        title: "Himachali Siddu & Trout Gastronomy",
        category: "Food",
        duration: "2 hrs",
        rating: 4.9,
        description: "Handcrafted steamed wheat bread stuffed with walnuts & spices served with hot ghee."
      },
      {
        title: "Himalayan Nightsky Astronomy",
        category: "Nature",
        duration: "2 hrs",
        rating: 4.95,
        description: "Laser-guided celestial constellation discovery under Bortle-2 high-altitude skies."
      }
    ],
    hotels: [
      {
        name: "The Himalayan Wood & Stone Sanctuary",
        tier: "Boutique Eco-Luxury",
        ratePerNight: "₹7,200",
        rating: 4.9,
        amenities: ["Valley View Balcony", "Fireplace", "Organic Farm Kitchen", "Heated Beds"]
      },
      {
        name: "Wild Cedar Riverside Retreat",
        tier: "Comfort Nature Lodge",
        ratePerNight: "₹4,100",
        rating: 4.7,
        amenities: ["Beas River Access", "Pine Forest Trail", "Bonfire Garden", "High-speed Wi-Fi"]
      }
    ]
  },
  coorg: {
    destinationName: "Coorg (Kodagu)",
    title: "YOUR COORG JOURNEY",
    durationText: "4 Days • 3 Nights",
    durationDays: 4,
    tagline: "Lush Western Ghats, emerald coffee plantations, spice trails, and misty waterfalls",
    heroImage: "https://images.unsplash.com/photo-1590523277543-a94d2e4eb00b?auto=format&fit=crop&w=1200&q=80",
    matchPercentage: 96,
    estimatedBudget: "₹14,000 – ₹19,000 / person",
    weatherOverview: "22°C Highs / 16°C Evenings • Fresh Mountain Mist",
    bestTimeToVisit: "October to April",
    elevation: "900m – 1,750m MSL",
    routeStats: {
      totalDistance: "260 km",
      waypointsCount: 4,
      drivingTime: "6 hrs total scenic drive",
      difficulty: "Gentle Hill Country"
    },
    itinerary: [
      {
        day: 1,
        title: "Arrival into the Coffee Realm",
        theme: "Plantation Heritage",
        overview: "Arrive at Madikeri, check into your coffee estate heritage cottage, and embark on a private bean-to-cup tour.",
        morning: "Scenic drive ascending through Western Ghats misty hairpins. Coffee plantation welcome drink.",
        afternoon: "Guided tour through Arabica and Robusta estate, learning spice cultivation (cardamom & black pepper).",
        evening: "Sunset viewpoint at Raja's Seat followed by traditional Kodava dinner.",
        stay: "Kodagu Heritage Coffee Estate",
        coordinates: { lat: 12.4244, lng: 75.7382, name: "Madikeri Town & Raja's Seat" }
      },
      {
        day: 2,
        title: "Waterfalls & Elephant Sanctuary",
        theme: "Wild Cascades & Gentle Giants",
        overview: "Visit the roaring Abbey Falls nestled between private coffee estates and interact with elephants at Dubare.",
        morning: "Morning walk to Abbey Falls through lush spice trails.",
        afternoon: "Cross Cauvery River to Dubare Elephant Camp for riverside conservation insights.",
        evening: "Golden hour bamboo rafting on Cauvery River.",
        stay: "Kodagu Heritage Coffee Estate",
        coordinates: { lat: 12.4578, lng: 75.7197, name: "Abbey Falls & Dubare" }
      },
      {
        day: 3,
        title: "Tadiandamol Peak & Sacred Springs",
        theme: "Highest Peak of Coorg",
        overview: "Hike through shola grasslands to Tadiandamol or visit the sacred river origin at Talakaveri.",
        morning: "Early ascent towards Tadiandamol with mist rolling across rolling green ridges.",
        afternoon: "Visit Talakaveri temple and Brahmagiri wildlife viewpoint.",
        evening: "Campfire and Kodava folklore under star-lit Western Ghats sky.",
        stay: "Kodagu Heritage Coffee Estate",
        coordinates: { lat: 12.2173, lng: 75.6105, name: "Tadiandamol Peak" }
      },
      {
        day: 4,
        title: "Departure & Tibetan Monastery",
        theme: "Tibetan Culture & Spice Markets",
        overview: "Explore Bylakuppe Tibetan settlement with 40-foot golden Buddha statues before departure.",
        morning: "Visit Namdroling Monastery Golden Temple and listen to resonant prayer horns.",
        afternoon: "Stop at local farmers market for single-origin coffee beans, wild honey, and handmade chocolates.",
        evening: "Departure transfer towards Bengaluru or Mangaluru.",
        stay: "Departure Day",
        coordinates: { lat: 12.4526, lng: 75.9648, name: "Bylakuppe Golden Temple" }
      }
    ],
    destinations: [
      {
        name: "Madikeri & Raja's Seat",
        type: "Misty Hilltop",
        image: "https://images.unsplash.com/photo-1590523277543-a94d2e4eb00b?auto=format&fit=crop&w=800&q=80",
        highlight: "Commanding views over rolling Western Ghats valleys",
        elevation: "1,150m"
      },
      {
        name: "Abbey Waterfalls",
        type: "Cascade & Spices",
        image: "https://images.unsplash.com/photo-1544735716-392fe2489ffa?auto=format&fit=crop&w=800&q=80",
        highlight: "70ft cascade surrounded by hanging pepper vines",
        elevation: "980m"
      },
      {
        name: "Namdroling Tibetan Colony",
        type: "Cultural Heritage",
        image: "https://images.unsplash.com/photo-1548013146-72479768bada?auto=format&fit=crop&w=800&q=80",
        highlight: "Second largest Tibetan settlement outside Tibet",
        elevation: "850m"
      }
    ],
    experiences: [
      {
        title: "Single-Origin Coffee Cupping Masterclass",
        category: "Food",
        duration: "1.5 hrs",
        rating: 4.95,
        description: "Taste the distinct acidity, body, and tasting notes of artisanal sun-dried peaberry."
      },
      {
        title: "Cauvery River Bamboo Rafting",
        category: "Adventure",
        duration: "2 hrs",
        rating: 4.8,
        description: "Glide silently on hand-tied bamboo rafts along dense forest waterways."
      },
      {
        title: "Authentic Kodava Culinary Tasting",
        category: "Culture",
        duration: "2 hrs",
        rating: 4.9,
        description: "Savor smoked kachampuli vinegar flavors, akki roti, and wild mushroom preparations."
      }
    ],
    hotels: [
      {
        name: "Plantation Trails Heritage Bungalow",
        tier: "Colonial Luxury",
        ratePerNight: "₹6,800",
        rating: 4.9,
        amenities: ["Private Estate", "English Verandah", "Personal Butler", "Spice Walks"]
      }
    ]
  }
};

/**
 * Universal dynamic planner to create a customized travel plan for ANY destination prompt.
 */
export function generateDynamicTravelPlan(userQuery = "", userAnswers = {}) {
  const query = (userQuery || "").toLowerCase();
  
  if (query.includes("himachal") || query.includes("manali") || query.includes("spiti") || query.includes("shimla")) {
    return applyPreferences(CURATED_PLANS.himachal, userAnswers);
  }
  if (query.includes("coorg") || query.includes("kodagu") || query.includes("madikeri") || query.includes("mysore")) {
    return applyPreferences(CURATED_PLANS.coorg, userAnswers);
  }

  // Extract destination name
  let destName = "Himalayan Ridge & Valley";
  if (query.includes("goa")) destName = "Goa Coastal Haven";
  else if (query.includes("ladakh") || query.includes("leh")) destName = "Ladakh High Passes";
  else if (query.includes("kashmir")) destName = "Kashmir Alpine Valleys";
  else if (query.includes("kerala") || query.includes("munnar")) destName = "Kerala Tea Valleys";
  else if (query.includes("rajasthan") || query.includes("jaipur") || query.includes("udaipur")) destName = "Rajasthan Heritage Citadels";
  else if (query.includes("bali")) destName = "Bali Rainforests & Oceans";
  else if (query.includes("japan")) destName = "Japan Alpine & Temples";
  else {
    const words = userQuery.replace(/plan|trip|to|for|with|a|me|and|friends|days?|\d+/gi, "").trim();
    if (words.length > 2) {
      destName = words.charAt(0).toUpperCase() + words.slice(1);
    }
  }

  const days = parseInt((userQuery.match(/(\d+)\s*days?/i) || [])[1]) || 5;
  const budgetChoice = userAnswers.budget || "₹20,000";
  const groupChoice = userAnswers.travelers || "3–5";
  const styleChoice = userAnswers.experience || "Adventure + Nature";

  const dynamicPlan = {
    destinationName: destName,
    title: `YOUR ${destName.toUpperCase()} JOURNEY`,
    durationText: `${days} Days • ${days - 1} Nights`,
    durationDays: days,
    tagline: `A tailor-made ${styleChoice.toLowerCase()} expedition curated for ${groupChoice} travellers`,
    heroImage: "/himalayan-bg.jpg",
    matchPercentage: 97,
    estimatedBudget: `${budgetChoice} per person (approx)`,
    weatherOverview: "Optimal travel window • Pleasant daylight & clear stars",
    bestTimeToVisit: "Upcoming optimal season",
    elevation: "Scenic elevation profiles",
    routeStats: {
      totalDistance: `${days * 85} km`,
      waypointsCount: days,
      drivingTime: `${days * 2.2} hrs curated drive`,
      difficulty: "Scenic & Leisurely"
    },
    itinerary: Array.from({ length: days }).map((_, i) => ({
      day: i + 1,
      title: i === 0 
        ? "Arrival & Mountain Escape" 
        : i === 1 
        ? "Explore the Valley" 
        : i === 2 
        ? "Adventure Day" 
        : i === days - 1 
        ? "Departure" 
        : "Hidden Mountain Experiences",
      theme: i === 0 ? "Arrival & Settlement" : i === days - 1 ? "Farewell & Wrap-up" : "Curated Discovery",
      overview: `Tailored itinerary synthesized for ${destName} catering to your selected ${styleChoice} preferences.`,
      morning: `Morning excursion to iconic vantage points and local heritage landmarks in ${destName}.`,
      afternoon: `Immersive hands-on activity, local tasting, or gentle nature walk tailored for ${groupChoice} travellers.`,
      evening: `Sunset observation followed by chef-curated dinner highlighting local regional produce.`,
      stay: `Curated Boutique Chalet in ${destName}`,
      coordinates: {
        lat: 32.24 + (i * 0.08),
        lng: 77.18 + (i * 0.05),
        name: `Day ${i + 1} Waypoint — ${destName}`
      }
    })),
    destinations: [
      {
        name: `${destName} Central Ridge`,
        type: "Scenic Landmark",
        image: "/himalayan-bg.jpg",
        highlight: "Panoramic 360-degree viewpoints and tranquil trails",
        elevation: "Valley Vistas"
      },
      {
        name: `${destName} Hidden Sanctuary`,
        type: "Off-beat Haven",
        image: "https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=800&q=80",
        highlight: "Quiet alpine grove free from tourist crowds",
        elevation: "Ridge High Point"
      },
      {
        name: `${destName} Cultural Quarter`,
        type: "Heritage & Living Culture",
        image: "https://images.unsplash.com/photo-1548013146-72479768bada?auto=format&fit=crop&w=800&q=80",
        highlight: "Artisan workshops and century-old architectural traditions",
        elevation: "Cultural Center"
      }
    ],
    experiences: [
      {
        title: `Signature ${destName} Nature Trail`,
        category: "Nature",
        duration: "3 hrs",
        rating: 4.9,
        description: "Handpicked naturalist-led walk showcasing rare local flora and pristine vistas."
      },
      {
        title: "Sunset Stargazing & Hearth Fire",
        category: "Relaxation",
        duration: "2.5 hrs",
        rating: 4.95,
        description: "Unwind around an open hearth with hot artisanal brew and constellation talks."
      },
      {
        title: "Indigenous Culinary Experience",
        category: "Food",
        duration: "2 hrs",
        rating: 4.85,
        description: "Taste traditional slow-cooked delicacies made from farm-to-table ingredients."
      }
    ],
    hotels: [
      {
        name: `${destName} Panoramic Chalet`,
        tier: "Boutique Eco-Stay",
        ratePerNight: "₹5,400",
        rating: 4.9,
        amenities: ["Valley Balcony", "Fireplace", "Breakfast Included", "Scenic Views"]
      }
    ]
  };

  return applyPreferences(dynamicPlan, userAnswers);
}

function applyPreferences(plan, userAnswers = {}) {
  const cloned = JSON.parse(JSON.stringify(plan));
  if (userAnswers.budget) {
    cloned.estimatedBudget = `${userAnswers.budget} per person (selected)`;
  }
  if (userAnswers.experience) {
    cloned.selectedExperience = userAnswers.experience;
  }
  if (userAnswers.travelers) {
    cloned.selectedTravelers = userAnswers.travelers;
  }
  return cloned;
}
