import React, { createContext, useContext, useState } from 'react';

/**
 * MapContext & MapProvider
 * 
 * Abstraction layer decoupling map state and UI from specific map providers
 * (e.g., Custom Vector Canvas, Google Maps JavaScript API, or Mapbox GL).
 */
const MapContext = createContext(null);

export function MapProvider({ children, initialRoute = null }) {
  const [activeDay, setActiveDay] = useState(1);
  const [selectedPlace, setSelectedPlace] = useState(null);
  const [activeCategory, setActiveCategory] = useState('all'); // 'all', 'places', 'food', 'hotels', 'experiences'
  const [userLocation, setUserLocation] = useState(null);
  const [isLocationAllowed, setIsLocationAllowed] = useState(false);
  const [mapProviderType, setMapProviderType] = useState('vector'); // 'vector', 'google-maps', 'mapbox'
  const [zoomLevel, setZoomLevel] = useState(11);
  const [searchQuery, setSearchQuery] = useState('');

  const value = {
    activeDay,
    setActiveDay,
    selectedPlace,
    setSelectedPlace,
    activeCategory,
    setActiveCategory,
    userLocation,
    setUserLocation,
    isLocationAllowed,
    setIsLocationAllowed,
    mapProviderType,
    setMapProviderType,
    zoomLevel,
    setZoomLevel,
    searchQuery,
    setSearchQuery,
    initialRoute,
  };

  return <MapContext.Provider value={value}>{children}</MapContext.Provider>;
}

export function useMapContext() {
  const ctx = useContext(MapContext);
  if (!ctx) {
    throw new Error('useMapContext must be used within a MapProvider');
  }
  return ctx;
}
