import React from 'react';
import { motion } from 'framer-motion';
import { User } from 'lucide-react';
import TravelQuestion from './TravelQuestion';

export default function ChatMessage({
  message,
  onAnswerQuestion,
}) {
  const isUser = message.sender === 'user';

  return (
    <motion.div
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, ease: 'easeOut' }}
      className={`flex items-start gap-3.5 my-4 ${isUser ? 'flex-row-reverse' : 'flex-row'}`}
    >
      {/* Avatar */}
      <div
        className={`flex items-center justify-center w-8 h-8 rounded-full shrink-0 ${
          isUser
            ? 'bg-white/15 text-white border border-white/20'
            : 'bg-emerald-400/20 text-emerald-300 border border-emerald-400/40 shadow-[0_0_15px_rgba(16,185,129,0.3)]'
        }`}
      >
        {isUser ? <User size={15} /> : <span className="text-xs font-bold">✦</span>}
      </div>

      {/* Message Content */}
      <div className={`flex flex-col max-w-[85%] sm:max-w-[75%] ${isUser ? 'items-end' : 'items-start'}`}>
        <div className="flex items-center gap-2 mb-1 px-1">
          <span className="text-xs font-medium text-white/50">
            {isUser ? 'You' : 'TRAVIX AI'}
          </span>
          <span className="text-[10px] text-white/30 font-mono">
            {message.timestamp || 'Just now'}
          </span>
        </div>

        <div
          className={`p-4 rounded-2xl text-sm sm:text-base leading-relaxed ${
            isUser
              ? 'bg-emerald-600/20 border border-emerald-500/30 text-white rounded-tr-none backdrop-blur-md'
              : 'bg-white/[0.04] border border-white/10 text-white/90 rounded-tl-none backdrop-blur-xl shadow-lg'
          }`}
        >
          {/* Formatted lines */}
          <div className="space-y-2 whitespace-pre-wrap font-sans">
            {message.text}
          </div>

          {/* Interactive Question Embedded */}
          {message.questionData && (
            <TravelQuestion
              question={message.questionData.question}
              options={message.questionData.options}
              selectedOption={message.selectedAnswer}
              onSelectOption={(val) => onAnswerQuestion(message.questionData.id, val)}
              disabled={Boolean(message.selectedAnswer)}
            />
          )}
        </div>
      </div>
    </motion.div>
  );
}
