import React, { useState } from 'react';
import { motion } from 'framer-motion';
import {
  MapPin,
  Calendar,
  Users,
  Compass,
  Sparkles,
  ArrowRight,
  Bookmark,
  Share2,
  ChevronDown,
  ChevronUp,
  Bed,
  Utensils,
  Sun,
  Sunset,
  Moon,
  CheckCircle2,
  Navigation
} from 'lucide-react';
import DestinationCard from './DestinationCard';
import ExperienceCard from './ExperienceCard';

export default function TravelPlan({
  plan,
  onExploreRoute,
  onRefineWithAI,
  userAnswers = {},
  weatherData = null,
}) {
  const [expandedDay, setExpandedDay] = useState(1);
  const [isSaved, setIsSaved] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  if (!plan) return null;

  const handleShare = () => {
    navigator.clipboard?.writeText(window.location.href);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  return (
    <motion.section
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, ease: 'easeOut' }}
      className="relative z-10 max-w-5xl mx-auto w-full px-4 sm:px-6 py-8 sm:py-12"
      aria-label="Synthesized Travel Plan"
    >
      {/* 1. TOP HEADER BANNER */}
      <div className="relative rounded-3xl overflow-hidden border border-white/10 bg-gradient-to-b from-white/[0.07] to-black/60 backdrop-blur-2xl p-6 sm:p-10 shadow-2xl">
        {/* Subtle glowing ambient highlight */}
        <div className="absolute -top-24 right-0 w-80 h-80 bg-emerald-500/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-10 w-60 h-60 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-400/15 border border-emerald-400/30 text-emerald-300 text-xs font-mono font-medium uppercase tracking-wider mb-3">
              <Sparkles size={13} className="text-emerald-300" />
              <span>AI SYNTHESIZED ITINERARY</span>
            </div>

            <h2 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight uppercase">
              {plan.title || `YOUR ${plan.destinationName.toUpperCase()} JOURNEY`}
            </h2>

            <p className="mt-3 text-sm sm:text-base text-white/75 max-w-2xl leading-relaxed">
              {plan.tagline}
            </p>

            {/* Quick Metrics Badges */}
            <div className="mt-6 flex flex-wrap items-center gap-2.5 sm:gap-4 text-xs font-medium">
              <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/5 border border-white/10 text-white/90">
                <Calendar size={13} className="text-emerald-400" />
                {plan.durationText}
              </span>
              <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/5 border border-white/10 text-white/90">
                <Users size={13} className="text-cyan-400" />
                {userAnswers.travelers || plan.selectedTravelers || '3–5'} Travellers
              </span>
              <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/5 border border-white/10 text-white/90">
                <Compass size={13} className="text-amber-400" />
                {userAnswers.experience || plan.selectedExperience || 'Adventure + Nature'}
              </span>
              <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-400/30 text-emerald-300 font-mono">
                Est: {plan.estimatedBudget}
              </span>
            </div>
          </div>

          {/* Action CTAs */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 shrink-0">
            {/* Primary stand-out "Explore Route" button */}
            <motion.button
              type="button"
              onClick={onExploreRoute}
              whileHover={{ scale: 1.04 }}
              whileTap={{ scale: 0.97 }}
              className="group inline-flex items-center justify-center gap-2.5 px-6 py-3.5 rounded-2xl bg-gradient-to-r from-emerald-400 via-teal-400 to-cyan-400 text-slate-950 font-bold text-sm tracking-wide shadow-[0_0_30px_rgba(16,185,129,0.4)] hover:shadow-[0_0_40px_rgba(16,185,129,0.6)] transition-all duration-300 cursor-pointer outline-none"
            >
              <Navigation size={17} className="text-slate-950 fill-slate-950/20 group-hover:rotate-12 transition-transform" />
              <span>Explore Route</span>
              <ArrowRight size={15} className="group-hover:translate-x-1 transition-transform" />
            </motion.button>

            <button
              type="button"
              onClick={() => setIsSaved(!isSaved)}
              className={`inline-flex items-center justify-center gap-2 px-4 py-3.5 rounded-2xl text-xs font-semibold border transition-all cursor-pointer ${
                isSaved
                  ? 'bg-emerald-500/20 border-emerald-400/50 text-emerald-300'
                  : 'bg-white/5 border-white/10 hover:bg-white/10 text-white/80 hover:text-white'
              }`}
            >
              <Bookmark size={15} fill={isSaved ? "currentColor" : "none"} />
              <span>{isSaved ? 'Saved' : 'Save Trip'}</span>
            </button>

            <button
              type="button"
              onClick={handleShare}
              className="inline-flex items-center justify-center gap-2 px-4 py-3.5 rounded-2xl bg-white/5 border border-white/10 hover:bg-white/10 text-xs font-semibold text-white/80 hover:text-white transition-all cursor-pointer"
            >
              <Share2 size={15} />
              <span>{copiedLink ? 'Link Copied!' : 'Share'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* 2. RECOMMENDED DAY-BY-DAY ITINERARY TIMELINE */}
      <div className="mt-10">
        <div className="flex items-center justify-between mb-6">
          <div>
            <span className="text-xs font-mono uppercase tracking-widest text-emerald-400">
              DAY-BY-DAY CHRONOLOGY
            </span>
            <h3 className="text-2xl font-bold text-white mt-1">
              Recommended Experience Schedule
            </h3>
          </div>
          <button
            type="button"
            onClick={onRefineWithAI}
            className="text-xs text-white/60 hover:text-emerald-300 transition-colors underline underline-offset-4 cursor-pointer"
          >
            Refine with AI ↗
          </button>
        </div>

        <div className="space-y-4">
          {plan.itinerary?.map((dayPlan) => {
            const isExpanded = expandedDay === dayPlan.day;
            return (
              <motion.div
                key={dayPlan.day}
                className={`rounded-2xl border transition-all duration-300 overflow-hidden ${
                  isExpanded
                    ? 'border-emerald-400/40 bg-white/[0.04] shadow-[0_0_25px_rgba(16,185,129,0.08)]'
                    : 'border-white/10 bg-white/[0.02] hover:border-white/20'
                }`}
              >
                {/* Accordion Day Header */}
                <button
                  type="button"
                  onClick={() => setExpandedDay(isExpanded ? null : dayPlan.day)}
                  className="w-full flex items-center justify-between p-5 sm:p-6 text-left cursor-pointer outline-none"
                >
                  <div className="flex items-center gap-4">
                    <span className={`flex items-center justify-center w-10 h-10 rounded-xl font-bold text-sm ${
                      isExpanded
                        ? 'bg-emerald-400 text-black shadow-[0_0_15px_rgba(16,185,129,0.4)]'
                        : 'bg-white/10 text-white/80'
                    }`}>
                      D{dayPlan.day}
                    </span>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-mono text-emerald-300/90 font-medium uppercase tracking-wider">
                          {dayPlan.theme}
                        </span>
                      </div>
                      <h4 className="text-lg font-bold text-white mt-0.5">
                        {dayPlan.title}
                      </h4>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <span className="hidden sm:inline-flex items-center gap-1.5 text-xs text-white/50">
                      <MapPin size={12} className="text-emerald-400" />
                      {dayPlan.coordinates?.name || dayPlan.stay}
                    </span>
                    <div className="p-1 rounded-full bg-white/5 text-white/60">
                      {isExpanded ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
                    </div>
                  </div>
                </button>

                {/* Day Details Drawer */}
                {isExpanded && (
                  <div className="px-5 sm:px-6 pb-6 pt-2 border-t border-white/5 space-y-4">
                    <p className="text-sm text-white/80 leading-relaxed">
                      {dayPlan.overview}
                    </p>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-2">
                      <div className="p-3.5 rounded-xl bg-black/40 border border-white/5">
                        <div className="flex items-center gap-2 text-amber-300 text-xs font-semibold mb-1.5">
                          <Sun size={13} />
                          <span>Morning</span>
                        </div>
                        <p className="text-xs text-white/70 leading-relaxed">
                          {dayPlan.morning}
                        </p>
                      </div>

                      <div className="p-3.5 rounded-xl bg-black/40 border border-white/5">
                        <div className="flex items-center gap-2 text-cyan-300 text-xs font-semibold mb-1.5">
                          <Sunset size={13} />
                          <span>Afternoon</span>
                        </div>
                        <p className="text-xs text-white/70 leading-relaxed">
                          {dayPlan.afternoon}
                        </p>
                      </div>

                      <div className="p-3.5 rounded-xl bg-black/40 border border-white/5">
                        <div className="flex items-center gap-2 text-indigo-300 text-xs font-semibold mb-1.5">
                          <Moon size={13} />
                          <span>Evening</span>
                        </div>
                        <p className="text-xs text-white/70 leading-relaxed">
                          {dayPlan.evening}
                        </p>
                      </div>
                    </div>

                    {/* Stay & Waypoint info */}
                    <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-white/5 text-xs text-white/60">
                      <span className="flex items-center gap-1.5">
                        <Bed size={14} className="text-emerald-400" />
                        Night Stay: <strong className="text-white font-medium">{dayPlan.stay}</strong>
                      </span>
                      <button
                        type="button"
                        onClick={onExploreRoute}
                        className="inline-flex items-center gap-1 text-emerald-300 hover:text-emerald-200 transition-colors font-medium"
                      >
                        <MapPin size={12} />
                        <span>View waypoint on route</span>
                      </button>
                    </div>
                  </div>
                )}
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* 3. CURATED DESTINATIONS GRID */}
      {plan.destinations?.length > 0 && (
        <div className="mt-12">
          <div className="mb-6">
            <span className="text-xs font-mono uppercase tracking-widest text-emerald-400">
              KEY VANTAGE POINTS
            </span>
            <h3 className="text-2xl font-bold text-white mt-1">
              Curated Destinations & Highlights
            </h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {plan.destinations.map((dest) => (
              <DestinationCard key={dest.name} destination={dest} />
            ))}
          </div>
        </div>
      )}

      {/* 4. EXPERIENCES & ACTIVITIES */}
      {plan.experiences?.length > 0 && (
        <div className="mt-12">
          <div className="mb-6">
            <span className="text-xs font-mono uppercase tracking-widest text-cyan-400">
              HANDPICKED ACTIVITIES
            </span>
            <h3 className="text-2xl font-bold text-white mt-1">
              Tailored Experiences
            </h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {plan.experiences.map((exp) => (
              <ExperienceCard key={exp.title} experience={exp} />
            ))}
          </div>
        </div>
      )}

      {/* 5. RECOMMENDED STAYS & FOOD HIGHLIGHTS */}
      {plan.hotels?.length > 0 && (
        <div className="mt-12 grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="p-6 rounded-2xl bg-white/[0.03] border border-white/10 backdrop-blur-md">
            <div className="flex items-center gap-2 text-emerald-300 text-xs font-semibold mb-3">
              <Bed size={16} />
              <span>RECOMMENDED STAY SANCTUARY</span>
            </div>
            <h4 className="text-lg font-bold text-white">
              {plan.hotels[0].name}
            </h4>
            <p className="text-xs text-white/60 mt-1 font-mono">
              Tier: {plan.hotels[0].tier} • From {plan.hotels[0].ratePerNight} / night
            </p>
            <div className="mt-4 flex flex-wrap gap-2">
              {plan.hotels[0].amenities?.map((amenity) => (
                <span
                  key={amenity}
                  className="px-2.5 py-1 rounded-lg bg-white/5 border border-white/10 text-[11px] text-white/80"
                >
                  {amenity}
                </span>
              ))}
            </div>
          </div>

          <div className="p-6 rounded-2xl bg-white/[0.03] border border-white/10 backdrop-blur-md flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 text-amber-300 text-xs font-semibold mb-3">
                <Utensils size={16} />
                <span>LOCAL MOUNTAIN GASTRONOMY</span>
              </div>
              <h4 className="text-lg font-bold text-white">
                Authentic Flavor Route
              </h4>
              <p className="text-xs text-white/70 mt-2 leading-relaxed">
                Handpicked farm-to-table stops: wood-fired Himalayan trout, steaming walnut siddu, spiced kahwa tea, and stone-ground corn flatbreads.
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-white/5 text-xs text-emerald-300 flex items-center gap-2">
              <CheckCircle2 size={13} />
              <span>Curated hygiene & local artisan certified</span>
            </div>
          </div>
        </div>
      )}

      {/* 6. BOTTOM ROUTE EXPLORATION BANNER */}
      <div className="mt-12 p-8 rounded-3xl bg-gradient-to-r from-emerald-950/70 via-black to-teal-950/70 border border-emerald-500/30 text-center flex flex-col items-center justify-center">
        <h3 className="text-2xl sm:text-3xl font-bold text-white">
          Your journey is ready.
        </h3>
        <p className="mt-2 text-sm text-white/70 max-w-lg">
          Explore interactive waypoints, terrain elevations, local place stops, and scenic navigation routes.
        </p>

        <motion.button
          type="button"
          onClick={onExploreRoute}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.96 }}
          className="mt-6 inline-flex items-center gap-2.5 px-8 py-4 rounded-2xl bg-white text-black font-bold text-sm tracking-wide shadow-[0_0_30px_rgba(255,255,255,0.3)] hover:bg-emerald-300 transition-all cursor-pointer"
        >
          <Navigation size={18} />
          <span>Explore Route on Map</span>
          <ArrowRight size={16} />
        </motion.button>
      </div>
    </motion.section>
  );
}
