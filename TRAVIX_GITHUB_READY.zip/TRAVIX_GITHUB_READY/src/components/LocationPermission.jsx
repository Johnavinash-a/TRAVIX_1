import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { MapPin, ShieldCheck, Navigation, AlertCircle, X } from 'lucide-react';

export default function LocationPermission({
  isOpen,
  onAllowLocation,
  onNotNow,
  destinationName = "Himachal",
}) {
  const [isRequesting, setIsRequesting] = useState(false);
  const [statusMessage, setStatusMessage] = useState(null);

  if (!isOpen) return null;

  const handleAllow = () => {
    setIsRequesting(true);
    setStatusMessage("Requesting browser location permission...");

    if (!navigator.geolocation) {
      setStatusMessage("Geolocation not supported by browser. Using default scenic route.");
      setTimeout(() => {
        setIsRequesting(false);
        onAllowLocation(null);
      }, 900);
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const coords = {
          lat: position.coords.latitude,
          lng: position.coords.longitude,
        };
        setStatusMessage("Location synchronized! Loading custom route...");
        setTimeout(() => {
          setIsRequesting(false);
          onAllowLocation(coords);
        }, 600);
      },
      (error) => {
        console.warn("Location permission not granted or timeout:", error.message);
        setStatusMessage("Continuing with curated journey gateway coordinates.");
        setTimeout(() => {
          setIsRequesting(false);
          onAllowLocation(null);
        }, 700);
      },
      { timeout: 8000 }
    );
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xl">
        <motion.div
          initial={{ opacity: 0, scale: 0.94, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.94, y: 15 }}
          transition={{ duration: 0.25, ease: 'easeOut' }}
          className="relative max-w-md w-full rounded-3xl bg-slate-950 border border-white/15 p-7 sm:p-8 shadow-2xl text-center overflow-hidden"
        >
          {/* Subtle glowing halo */}
          <div className="absolute -top-20 left-1/2 -translate-x-1/2 w-64 h-64 bg-emerald-500/20 rounded-full blur-3xl pointer-events-none" />

          {/* Close button (acts as Not Now) */}
          <button
            type="button"
            onClick={onNotNow}
            disabled={isRequesting}
            className="absolute top-5 right-5 text-white/40 hover:text-white transition-colors p-1 rounded-lg cursor-pointer"
            aria-label="Close permission modal"
          >
            <X size={18} />
          </button>

          {/* Compass / Location Icon Badge */}
          <div className="mx-auto w-14 h-14 rounded-2xl bg-emerald-400/15 border border-emerald-400/30 text-emerald-300 flex items-center justify-center mb-5 shadow-[0_0_25px_rgba(16,185,129,0.3)]">
            <Navigation size={26} className="rotate-45" />
          </div>

          <span className="inline-block text-[11px] font-mono tracking-widest uppercase text-emerald-400 font-semibold mb-2">
            LOCATION ACCESS
          </span>

          <h3 className="text-xl sm:text-2xl font-bold text-white tracking-tight leading-snug">
            Your journey is ready.
          </h3>

          <p className="text-sm text-white/75 mt-3 leading-relaxed">
            To personalize your route and show places around you,
            Travix can use your location.
          </p>

          {/* Status feedback */}
          {statusMessage && (
            <p className="text-xs text-emerald-300 bg-emerald-500/10 border border-emerald-500/20 rounded-xl py-2 px-3 mt-3 animate-pulse">
              {statusMessage}
            </p>
          )}

          {/* Action Buttons */}
          <div className="mt-7 flex flex-col gap-3">
            <motion.button
              type="button"
              onClick={handleAllow}
              disabled={isRequesting}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="w-full py-3.5 px-6 rounded-xl sm:rounded-2xl bg-gradient-to-r from-emerald-400 to-teal-400 text-slate-950 font-bold text-sm shadow-[0_0_25px_rgba(16,185,129,0.4)] hover:shadow-[0_0_35px_rgba(16,185,129,0.6)] transition-all cursor-pointer disabled:opacity-50"
            >
              {isRequesting ? "Connecting..." : "Allow Location"}
            </motion.button>

            <button
              type="button"
              onClick={onNotNow}
              disabled={isRequesting}
              className="w-full py-3 px-6 rounded-xl sm:rounded-2xl bg-white/5 hover:bg-white/10 text-white/70 hover:text-white font-medium text-xs transition-colors cursor-pointer border border-white/5"
            >
              Not Now
            </button>
          </div>

          <div className="mt-5 flex items-center justify-center gap-1.5 text-[11px] text-white/40">
            <ShieldCheck size={12} className="text-emerald-400" />
            <span>Private & used solely for route plotting in this session</span>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
