import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import mapboxgl from 'mapbox-gl';
import 'mapbox-gl/dist/mapbox-gl.css';
import {
  MapPin,
  Search,
  Navigation,
  ArrowLeft,
  Layers,
  Plus,
  Minus,
  Maximize2,
  Calendar,
  Bed,
  Utensils,
  Compass,
  Sparkles,
  ExternalLink,
  Info,
  ChevronRight
} from 'lucide-react';
import { useMapContext } from './MapProvider';

const MAPBOX_TOKEN = import.meta.env.VITE_MAPBOX_TOKEN || null;
const MAPBOX_STYLE = 'mapbox://styles/mapbox/dark-v11';

const CATEGORY_FILTERS = [
  { id: 'all', label: 'All Highlights', icon: Sparkles },
  { id: 'places', label: 'Explore Places', icon: Compass },
  { id: 'food', label: 'Food & Cafes', icon: Utensils },
  { id: 'hotels', label: 'Hotels & Stays', icon: Bed },
  { id: 'experiences', label: 'Experiences', icon: Sparkles },
];

export default function SmartMap({
  plan,
  onBackToPlan,
  onBackToChat,
  weatherData = null,
}) {
  const {
    activeDay,
    setActiveDay,
    selectedPlace,
    setSelectedPlace,
    activeCategory,
    setActiveCategory,
    userLocation,
    zoomLevel,
    setZoomLevel,
  } = useMapContext();

  const [mapLayer, setMapLayer] = useState('dark-topo');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedWaypointIndex, setSelectedWaypointIndex] = useState(0);
  const [mapInstance, setMapInstance] = useState(null);
  const [useMapbox, setUseMapbox] = useState(false);
  const mapContainerRef = useRef(null);
  const mapboxMapRef = useRef(null);

  const itinerary = plan?.itinerary || [];
  const currentDayPlan = itinerary[selectedWaypointIndex] || itinerary[0];

  // Check if Mapbox token is available
  useEffect(() => {
    if (MAPBOX_TOKEN && mapContainerRef.current && !mapboxMapRef.current) {
      setUseMapbox(true);
    }
  }, []);

  // Initialize Mapbox GL
  useEffect(() => {
    if (!useMapbox || !mapContainerRef.current || mapboxMapRef.current) return;

    mapboxgl.accessToken = MAPBOX_TOKEN;

    const center = userLocation
      ? [userLocation.lng, userLocation.lat]
      : (plan?.destinationCoords ? [plan.destinationCoords.lng, plan.destinationCoords.lat] : [75.74, 12.42]);

    const map = new mapboxgl.Map({
      container: mapContainerRef.current,
      style: MAPBOX_STYLE,
      center,
      zoom: 10,
      attributionControl: false,
    });

    map.addControl(new mapboxgl.NavigationControl({ showCompass: false }), 'bottom-right');

    map.on('load', () => {
      addRouteLayer(map);
      addWaypointMarkers(map);
      if (userLocation) addUserLocationMarker(map);
    });

    mapboxMapRef.current = map;
    setMapInstance(map);

    return () => {
      map.remove();
      mapboxMapRef.current = null;
      setMapInstance(null);
    };
  }, [useMapbox, userLocation, plan]);

  // Convert waypoints to GeoJSON for Mapbox
  const getRouteGeoJSON = () => {
    if (!plan?.destinationCoords || !itinerary.length) return null;

    const coordinates = [];
    if (userLocation) {
      coordinates.push([userLocation.lng, userLocation.lat]);
    } else if (plan.originCoords) {
      coordinates.push([plan.originCoords.lng, plan.originCoords.lat]);
    }

    itinerary.forEach(item => {
      if (item.coordinates) {
        coordinates.push([item.coordinates.lng, item.coordinates.lat]);
      }
    });

    return {
      type: 'Feature',
      properties: {},
      geometry: {
        type: 'LineString',
        coordinates,
      },
    };
  };

  const addRouteLayer = (map) => {
    const routeGeoJSON = getRouteGeoJSON();
    if (!routeGeoJSON) return;

    map.addSource('route', {
      type: 'geojson',
      data: routeGeoJSON,
    });

    map.addLayer({
      id: 'route-line',
      type: 'line',
      source: 'route',
      layout: {
        'line-join': 'round',
        'line-cap': 'round',
      },
      paint: {
        'line-color': ['interpolate', ['linear'], ['line-progress'], 0, '#34d399', 0.5, '#38bdf8', 1, '#fbbf24'],
        'line-width': 4,
        'line-opacity': 0.9,
      },
    });

    map.addLayer({
      id: 'route-glow',
      type: 'line',
      source: 'route',
      layout: {
        'line-join': 'round',
        'line-cap': 'round',
      },
      paint: {
        'line-color': '#10b981',
        'line-width': 10,
        'line-opacity': 0.3,
        'line-blur': 4,
      },
    });
  };

  const addWaypointMarkers = (map) => {
    const coordinates = [];
    if (userLocation) {
      coordinates.push([userLocation.lng, userLocation.lat]);
    } else if (plan.originCoords) {
      coordinates.push([plan.originCoords.lng, plan.originCoords.lat]);
    }

    itinerary.forEach((item, idx) => {
      if (item.coordinates) {
        coordinates.push([item.coordinates.lng, item.coordinates.lat]);
        
        const el = document.createElement('div');
        const isSelected = idx === selectedWaypointIndex;
        el.className = `w-8 h-8 rounded-2xl flex items-center justify-center font-mono font-bold text-xs transition-all duration-300 shadow-xl cursor-pointer ${
          isSelected
            ? 'bg-emerald-400 text-black scale-110 shadow-[0_0_25px_rgba(16,185,129,0.7)]'
            : 'bg-slate-900/90 text-white border border-white/30 hover:border-emerald-400 hover:scale-105'
        }`;
        el.innerHTML = `D${item.day}`;
        el.title = item.title;

        new mapboxgl.Marker(el)
          .setLngLat([item.coordinates.lng, item.coordinates.lat])
          .addTo(map);

        el.addEventListener('click', () => {
          setSelectedWaypointIndex(idx);
          setActiveDay(item.day);
        });
      }
    });
  };

  const addUserLocationMarker = (map) => {
    if (!userLocation) return;

    const el = document.createElement('div');
    el.className = 'w-8 h-8 rounded-full bg-cyan-400 text-black flex items-center justify-center shadow-[0_0_20px_rgba(56,189,248,0.8)]';
    el.innerHTML = '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="23 7 16 12 23 17 23 7"/></svg>';

    new mapboxgl.Marker(el)
      .setLngLat([userLocation.lng, userLocation.lat])
      .addTo(map);
  };

  // Generate SVG waypoints for fallback
  const waypoints = itinerary.map((item, idx) => {
    const angle = (idx / Math.max(1, itinerary.length - 1)) * Math.PI * 0.8;
    const x = 18 + ((idx * 16) % 65) + Math.sin(idx * 1.5) * 8;
    const y = 25 + ((idx * 13) % 55) + Math.cos(idx * 1.2) * 6;
    return {
      day: item.day,
      name: item.coordinates?.name || `Day ${item.day} Waypoint`,
      title: item.title,
      theme: item.theme,
      stay: item.stay,
      x: Math.min(85, Math.max(15, x)),
      y: Math.min(80, Math.max(20, y)),
      rawCoords: item.coordinates,
      morning: item.morning,
      afternoon: item.afternoon,
      evening: item.evening,
    };
  });

  const routePathD = waypoints.reduce((acc, pt, i) => {
    if (i === 0) return `M ${pt.x * 10} ${pt.y * 7}`;
    const prev = waypoints[i - 1];
    const cx1 = (prev.x * 10 + pt.x * 10) / 2;
    const cy1 = prev.y * 7;
    const cx2 = cx1;
    const cy2 = pt.y * 7;
    return `${acc} C ${cx1} ${cy1}, ${cx2} ${cy2}, ${pt.x * 10} ${pt.y * 7}`;
  }, '');

  const handleOpenGoogleMaps = (wp) => {
    const dest = encodeURIComponent(`${wp.name || wp.title}, ${plan?.destinationName || 'India'}`);
    let url = `https://www.google.com/maps/search/?api=1&query=${dest}`;
    if (userLocation) {
      url = `https://www.google.com/maps/dir/?api=1&origin=${userLocation.lat},${userLocation.lng}&destination=${dest}`;
    }
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="relative w-full min-h-screen bg-slate-950 text-white flex flex-col overflow-hidden font-sans">
      {/* 1. TOP SMART MAP NAVIGATION BAR */}
      <header className="relative z-30 flex flex-wrap items-center justify-between gap-3 px-4 sm:px-6 py-3.5 bg-black/80 backdrop-blur-2xl border-b border-white/10 shadow-lg">
        {/* Left: Back & Wordmark */}
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={onBackToPlan}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-white/80 hover:text-white text-xs font-medium transition-colors cursor-pointer border border-white/10"
          >
            <ArrowLeft size={14} />
            <span>Itinerary</span>
          </button>

          <div className="flex items-center gap-2">
            <span className="flex items-center justify-center w-6 h-6 rounded-full bg-emerald-400/20 text-emerald-300 text-xs">
              ✦
            </span>
            <span className="font-bold tracking-tight text-base sm:text-lg text-white font-sans">
              TRAVIX <span className="text-emerald-400 font-mono text-xs font-semibold">SMART MAP</span>
            </span>
            {MAPBOX_TOKEN && (
              <span className="px-2 py-0.5 rounded bg-emerald-400/20 text-emerald-300 font-mono text-[10px] font-bold">
                MAPBOX GL
              </span>
            )}
          </div>
        </div>

        {/* Center Search Bar */}
        <div className="order-3 sm:order-2 w-full sm:w-auto flex-1 max-w-md mx-auto">
          <div className="relative flex items-center">
            <Search size={15} className="absolute left-3.5 text-white/40 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={`Search ${plan?.destinationName || 'Himalayan'} viewpoints, routes, cafes...`}
              className="w-full bg-white/[0.05] border border-white/15 focus:border-emerald-400/60 rounded-full pl-9 pr-4 py-2 text-xs text-white placeholder:text-white/40 outline-none transition-colors"
            />
          </div>
        </div>

        {/* Right Info & Layer Controls */}
        <div className="order-2 sm:order-3 flex items-center gap-2 text-xs">
          <span className="hidden md:inline-flex items-center gap-1 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-400/20 text-emerald-300 font-mono text-[11px]">
            <Navigation size={11} />
            {plan?.routeStats?.totalDistance || '468 km'} • {plan?.durationText || '5 Days'}
          </span>

          <div className="flex items-center rounded-xl bg-white/5 border border-white/10 p-0.5">
            <button
              type="button"
              onClick={() => setMapLayer('dark-topo')}
              className={`px-2.5 py-1 rounded-lg transition-colors cursor-pointer text-[11px] ${
                mapLayer === 'dark-topo' ? 'bg-emerald-400/20 text-emerald-300 font-semibold' : 'text-white/60 hover:text-white'
              }`}
            >
              Topo
            </button>
            <button
              type="button"
              onClick={() => setMapLayer('satellite-sim')}
              className={`px-2.5 py-1 rounded-lg transition-colors cursor-pointer text-[11px] ${
                mapLayer === 'satellite-sim' ? 'bg-emerald-400/20 text-emerald-300 font-semibold' : 'text-white/60 hover:text-white'
              }`}
            >
              Satellite
            </button>
          </div>
        </div>
      </header>

      {/* 2. INTERACTIVE MAP VIEWPORT CANVAS */}
      <div className="relative flex-1 w-full min-h-[420px] sm:min-h-[500px] overflow-hidden bg-slate-950 select-none">
        {useMapbox ? (
          // Mapbox GL Renderer
          <div ref={mapContainerRef} className="absolute inset-0 w-full h-full" />
        ) : (
          // SVG Fallback Renderer
          <>
            {/* Topographic Background Simulation */}
            <div 
              className={`absolute inset-0 w-full h-full transition-all duration-700 ${
                mapLayer === 'satellite-sim' ? 'opacity-40 contrast-125' : 'opacity-20'
              }`}
              style={{
                backgroundImage: `radial-gradient(circle at 50% 50%, rgba(16,185,129,0.06) 0%, transparent 70%), linear-gradient(to right, rgba(255,255,255,0.03) 1px, transparent 1px), linear-gradient(to bottom, rgba(255,255,255,0.03) 1px, transparent 1px)`,
                backgroundSize: '100% 100%, 48px 48px, 48px 48px',
              }}
            />

            {/* Ambient Topographic Elevation Rings */}
            <svg className="absolute inset-0 w-full h-full pointer-events-none opacity-20" aria-hidden="true">
              <defs>
                <radialGradient id="elevationGrad" cx="50%" cy="50%" r="50%">
                  <stop offset="0%" stopColor="#10b981" stopOpacity="0.4" />
                  <stop offset="100%" stopColor="#0284c7" stopOpacity="0" />
                </radialGradient>
              </defs>
              <ellipse cx="35%" cy="40%" rx="240" ry="140" fill="none" stroke="rgba(255,255,255,0.12)" strokeWidth="1" strokeDasharray="3 3" />
              <ellipse cx="35%" cy="40%" rx="180" ry="100" fill="none" stroke="rgba(16,185,129,0.18)" strokeWidth="1" />
              <ellipse cx="35%" cy="40%" rx="110" ry="60" fill="none" stroke="rgba(16,185,129,0.25)" strokeWidth="1.2" />
              <ellipse cx="70%" cy="65%" rx="260" ry="150" fill="none" stroke="rgba(255,255,255,0.1)" strokeWidth="1" strokeDasharray="4 4" />
              <ellipse cx="70%" cy="65%" rx="170" ry="90" fill="none" stroke="rgba(56,189,248,0.15)" strokeWidth="1" />
            </svg>

            {/* Animated Vector Route Line SVG Canvas */}
            <svg
              viewBox="0 0 1000 700"
              className="absolute inset-0 w-full h-full pointer-events-none"
              preserveAspectRatio="none"
            >
              <defs>
                <linearGradient id="routeGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#34d399" />
                  <stop offset="50%" stopColor="#38bdf8" />
                  <stop offset="100%" stopColor="#fbbf24" />
                </linearGradient>
                <filter id="routeGlow" x="-20%" y="-20%" width="140%" height="140%">
                  <feGaussianBlur stdDeviation="6" result="blur" />
                  <feComposite in="SourceGraphic" in2="blur" operator="over" />
                </filter>
              </defs>

              {/* Glowing Backpath */}
              <path
                d={routePathD}
                fill="none"
                stroke="rgba(16,185,129,0.2)"
                strokeWidth="8"
                filter="url(#routeGlow)"
              />

              {/* Crisp Gradient Route Path */}
              <path
                d={routePathD}
                fill="none"
                stroke="url(#routeGradient)"
                strokeWidth="3.5"
                strokeDasharray="6 3"
                className="animate-pulse"
              />
            </svg>

            {/* Waypoint Interactive Markers */}
            <div className="absolute inset-0 w-full h-full pointer-events-auto">
              {waypoints.map((wp, idx) => {
                const isSelected = selectedWaypointIndex === idx;
                return (
                  <div
                    key={wp.day}
                    style={{ left: `${wp.x}%`, top: `${wp.y}%` }}
                    className="absolute -translate-x-1/2 -translate-y-1/2 cursor-pointer z-10 group"
                    onClick={() => {
                      setSelectedWaypointIndex(idx);
                      setActiveDay(wp.day);
                    }}
                  >
                    {/* Marker Pulse Halo */}
                    {isSelected && (
                      <div className="absolute -inset-2.5 rounded-full bg-emerald-400/30 animate-ping pointer-events-none" />
                    )}

                    {/* Marker Pin Icon */}
                    <div
                      className={`relative flex items-center justify-center rounded-2xl transition-all duration-300 shadow-xl ${
                        isSelected
                          ? 'w-10 h-10 bg-emerald-400 text-black font-bold scale-110 shadow-[0_0_25px_rgba(16,185,129,0.7)]'
                          : 'w-8 h-8 bg-slate-900/90 text-white border border-white/30 hover:border-emerald-400 hover:scale-105'
                      }`}
                    >
                      <span className="text-xs font-mono font-bold">D{wp.day}</span>
                    </div>

                    {/* Waypoint Callout Card */}
                    <div
                      className={`absolute top-full left-1/2 -translate-x-1/2 mt-2 px-3 py-1.5 rounded-xl backdrop-blur-xl border transition-all duration-200 pointer-events-none whitespace-nowrap shadow-2xl ${
                        isSelected
                          ? 'bg-black/90 border-emerald-400 text-white opacity-100 scale-100 z-20'
                          : 'bg-black/75 border-white/10 text-white/70 opacity-0 group-hover:opacity-100 scale-95 group-hover:scale-100'
                      }`}
                    >
                      <div className="text-[11px] font-bold leading-none">{wp.name}</div>
                      <div className="text-[9px] text-emerald-300/80 font-mono mt-0.5">{wp.theme}</div>
                    </div>
                  </div>
                );
              })}

              {/* User Location Marker (if granted) */}
              {userLocation && (
                <div
                  style={{ left: '12%', top: '78%' }}
                  className="absolute -translate-x-1/2 -translate-y-1/2 z-20 cursor-default"
                  title="Your Synchronized Starting Point"
                >
                  <div className="absolute -inset-2 rounded-full bg-cyan-400/40 animate-ping pointer-events-none" />
                  <div className="w-8 h-8 rounded-full bg-cyan-400 text-black flex items-center justify-center shadow-[0_0_20px_rgba(56,189,248,0.8)]">
                    <Navigation size={15} />
                  </div>
                  <div className="absolute top-full left-1/2 -translate-x-1/2 mt-1 px-2.5 py-0.5 rounded-md bg-black/80 text-[10px] text-cyan-300 font-mono whitespace-nowrap border border-cyan-400/30">
                    You Are Here
                  </div>
                </div>
              )}
            </div>

            {/* Map Floating Viewport Controls */}
            <div className="absolute bottom-6 right-6 z-20 flex flex-col gap-2">
              <button
                type="button"
                onClick={() => setZoomLevel((z) => Math.min(18, z + 1))}
                className="w-9 h-9 rounded-xl bg-black/70 backdrop-blur-xl border border-white/15 text-white/80 hover:text-white flex items-center justify-center transition-all cursor-pointer hover:bg-white/10"
                title="Zoom In"
              >
                <Plus size={16} />
              </button>
              <button
                type="button"
                onClick={() => setZoomLevel((z) => Math.max(5, z - 1))}
                className="w-9 h-9 rounded-xl bg-black/70 backdrop-blur-xl border border-white/15 text-white/80 hover:text-white flex items-center justify-center transition-all cursor-pointer hover:bg-white/10"
                title="Zoom Out"
              >
                <Minus size={16} />
              </button>
            </div>

            {/* Map Provider Notice */}
            <div className="absolute top-4 left-4 z-20 hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-xl bg-black/70 backdrop-blur-md border border-white/10 text-[11px] text-white/60">
              <Info size={12} className="text-emerald-400" />
              <span>Vector Route Engine Active • Ready for Google Maps / Mapbox connection</span>
            </div>
          </>
        )}
      </div>

      {/* 3. BOTTOM JOURNEY DRAWER & DAY SELECTOR */}
      <footer className="relative z-30 w-full bg-black/90 backdrop-blur-2xl border-t border-white/10 p-4 sm:p-6 shadow-2xl">
        <div className="max-w-6xl mx-auto">
          {/* Day Selector & Category Filters Row */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-white/10">
            {/* Days Tabs */}
            <div>
              <span className="text-[10px] font-mono tracking-widest uppercase text-emerald-400 font-semibold block mb-2">
                YOUR JOURNEY TIMELINE
              </span>
              <div className="flex items-center gap-2 overflow-x-auto pb-1 sm:pb-0 scrollbar-none">
                {itinerary.map((dayPlan, idx) => {
                  const isSelected = selectedWaypointIndex === idx;
                  return (
                    <button
                      key={dayPlan.day}
                      type="button"
                      onClick={() => {
                        setSelectedWaypointIndex(idx);
                        setActiveDay(dayPlan.day);
                      }}
                      className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all cursor-pointer outline-none ${
                        isSelected
                          ? 'bg-emerald-400 text-black shadow-[0_0_15px_rgba(16,185,129,0.4)]'
                          : 'bg-white/5 border border-white/10 text-white/70 hover:text-white hover:bg-white/10'
                      }`}
                    >
                      Day {dayPlan.day}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Category Filter Pills */}
            <div>
              <span className="text-[10px] font-mono tracking-widest uppercase text-white/50 font-semibold block mb-2">
                EXPLORE BY CATEGORY
              </span>
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0 scrollbar-none">
                {CATEGORY_FILTERS.map((cat) => {
                  const Icon = cat.icon;
                  const isCatSelected = activeCategory === cat.id;
                  return (
                    <button
                      key={cat.id}
                      type="button"
                      onClick={() => setActiveCategory(cat.id)}
                      className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium whitespace-nowrap transition-all cursor-pointer ${
                        isCatSelected
                          ? 'bg-white/20 text-white border border-emerald-400/50'
                          : 'bg-white/5 text-white/60 hover:text-white border border-white/5 hover:bg-white/10'
                      }`}
                    >
                      <Icon size={12} className={isCatSelected ? 'text-emerald-300' : 'text-white/40'} />
                      <span>{cat.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Active Waypoint Detail Highlight Card */}
          {currentDayPlan && (
            <div className="mt-4 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4 p-4 rounded-2xl bg-white/[0.03] border border-white/5">
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <span className="px-2 py-0.5 rounded bg-emerald-400/20 text-emerald-300 font-mono text-[10px] font-bold">
                    DAY {currentDayPlan.day}
                  </span>
                  <span className="text-xs text-white/50 font-mono">
                    {currentDayPlan.theme}
                  </span>
                </div>
                <h4 className="text-base font-bold text-white mt-1">
                  {currentDayPlan.title}
                </h4>
                <p className="text-xs text-white/70 mt-1 max-w-2xl leading-relaxed">
                  {currentDayPlan.overview}
                </p>
                <div className="mt-2 flex flex-wrap gap-4 text-xs text-white/50">
                  <span className="flex items-center gap-1">
                    <MapPin size={12} className="text-emerald-400" />
                    {currentDayPlan.coordinates?.name || currentDayPlan.stay}
                  </span>
                  <span className="flex items-center gap-1">
                    <Bed size={12} className="text-cyan-400" />
                    Night Stay: <strong className="text-white/90">{currentDayPlan.stay}</strong>
                  </span>
                </div>
              </div>

              {/* Waypoint Direction Action */}
              <div className="shrink-0 flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => handleOpenGoogleMaps(currentDayPlan)}
                  className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-400 hover:bg-emerald-300 text-black font-bold text-xs shadow-md transition-all cursor-pointer"
                >
                  <Navigation size={13} />
                  <span>Get Turn Directions</span>
                  <ExternalLink size={12} />
                </button>
              </div>
            </div>
          )}
        </div>
      </footer>
    </div>
  );
}