import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Sparkles, Menu, X, Compass, MapPin, Shield, ArrowRight } from 'lucide-react';

const NAV_ITEMS = [
  { label: 'Explore', href: '#explore' },
  { label: 'Destinations', href: '#destinations' },
  { label: 'Experiences', href: '#experiences' },
  { label: 'About', href: '#about' },
];

export default function Navbar({ onLogoClick, onGetStarted, currentState = 'landing' }) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [hoveredNav, setHoveredNav] = useState(null);

  const handleNavClick = (href) => {
    setMobileMenuOpen(false);
    if (currentState !== 'landing' && onLogoClick) {
      onLogoClick();
    }
  };

  return (
    <header className="fixed top-5 left-0 right-0 z-50 px-4 sm:px-6 pointer-events-none">
      <motion.nav
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.6, ease: 'easeOut' }}
        className="max-w-5xl mx-auto flex items-center justify-between p-2 px-5 sm:px-6 rounded-full bg-black/40 backdrop-blur-2xl border border-white/10 shadow-2xl shadow-black/50 pointer-events-auto transition-all duration-300 hover:border-white/20"
        aria-label="Main Navigation"
      >
        {/* Logo */}
        <button
          type="button"
          onClick={onLogoClick}
          className="flex items-center gap-2.5 group text-white outline-none cursor-pointer focus-visible:ring-2 focus-visible:ring-emerald-400 rounded-full px-2 py-1"
          aria-label="TRAVIX AI Travel Platform"
        >
          <span className="flex items-center justify-center w-7 h-7 rounded-full bg-emerald-400/15 border border-emerald-400/30 text-emerald-300 text-xs shadow-[0_0_15px_rgba(16,185,129,0.35)] group-hover:scale-110 transition-all duration-300">
            ✦
          </span>
          <span className="font-bold tracking-tight text-lg text-white font-sans flex items-center gap-1.5">
            TRAVIX
            <span className="text-[10px] uppercase font-mono tracking-widest px-1.5 py-0.5 rounded bg-white/10 text-emerald-300 border border-emerald-400/20">
              AI
            </span>
          </span>
        </button>

        {/* Desktop Navigation */}
        <ul className="hidden md:flex items-center gap-8 list-none m-0 p-0">
          {NAV_ITEMS.map((item) => (
            <li key={item.label} className="relative">
              <a
                href={item.href}
                onClick={() => handleNavClick(item.href)}
                onMouseEnter={() => setHoveredNav(item.label)}
                onMouseLeave={() => setHoveredNav(null)}
                className="relative text-[13px] font-medium text-white/70 hover:text-white transition-colors duration-200 py-1 px-1 outline-none"
              >
                {item.label}
                <span
                  className={`absolute bottom-0 left-0 h-[1.5px] bg-gradient-to-r from-emerald-400 to-cyan-400 transition-all duration-300 ease-out ${
                    hoveredNav === item.label ? 'w-full opacity-100' : 'w-0 opacity-0'
                  }`}
                />
              </a>
            </li>
          ))}
        </ul>

        {/* Right Actions */}
        <div className="hidden md:flex items-center gap-4">
          <button
            type="button"
            className="text-[13px] font-medium text-white/70 hover:text-white transition-colors duration-200 px-3 py-1.5 rounded-full outline-none cursor-pointer"
          >
            Sign In
          </button>
          <button
            type="button"
            onClick={onGetStarted}
            className="group relative inline-flex items-center gap-2 rounded-full px-5 py-2 text-xs font-semibold tracking-wide text-black bg-white shadow-lg shadow-white/10 hover:bg-white/95 hover:scale-105 active:scale-95 transition-all duration-200 cursor-pointer outline-none focus-visible:ring-2 focus-visible:ring-emerald-400"
          >
            <span>Get Started</span>
            <ArrowRight size={13} className="text-black/70 group-hover:translate-x-0.5 transition-transform" />
          </button>
        </div>

        {/* Mobile Hamburger Button */}
        <div className="md:hidden flex items-center">
          <button
            type="button"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-1.5 text-white/80 hover:text-white rounded-lg focus-visible:ring-2 focus-visible:ring-emerald-400 outline-none cursor-pointer"
            aria-expanded={mobileMenuOpen}
            aria-label="Toggle navigation menu"
          >
            {mobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </motion.nav>

      {/* Mobile Animated Dropdown */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -12, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -12, scale: 0.98 }}
            transition={{ duration: 0.22, ease: 'easeOut' }}
            className="max-w-5xl mx-auto mt-2 p-5 rounded-2xl bg-black/85 backdrop-blur-2xl border border-white/10 shadow-2xl pointer-events-auto md:hidden"
          >
            <ul className="flex flex-col gap-3 list-none m-0 p-0">
              {NAV_ITEMS.map((item) => (
                <li key={item.label}>
                  <a
                    href={item.href}
                    onClick={() => handleNavClick(item.href)}
                    className="block text-sm font-medium text-white/80 hover:text-white py-1.5 transition-colors"
                  >
                    {item.label}
                  </a>
                </li>
              ))}
              <li className="pt-3 border-t border-white/10 flex flex-col gap-2.5">
                <button
                  type="button"
                  onClick={() => setMobileMenuOpen(false)}
                  className="text-center text-xs font-medium text-white/70 hover:text-white py-2"
                >
                  Sign In
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setMobileMenuOpen(false);
                    onGetStarted && onGetStarted();
                  }}
                  className="w-full rounded-full py-2.5 bg-white text-black font-semibold text-xs shadow-md active:scale-98 transition-transform"
                >
                  Get Started
                </button>
              </li>
            </ul>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
