import React from 'react';
import { Sparkles, Shield, Compass, Heart } from 'lucide-react';

export default function Footer({ onLogoClick }) {
  return (
    <footer className="relative z-10 w-full border-t border-white/10 bg-black/80 backdrop-blur-2xl py-12 px-6 text-white">
      <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
        {/* Brand & Mission */}
        <div className="flex flex-col items-center md:items-start text-center md:text-left">
          <button
            type="button"
            onClick={onLogoClick}
            className="flex items-center gap-2 group cursor-pointer text-white"
          >
            <span className="flex items-center justify-center w-6 h-6 rounded-full bg-emerald-400/20 text-emerald-300 text-xs">
              ✦
            </span>
            <span className="font-bold tracking-tight text-lg text-white font-sans">
              TRAVIX
            </span>
          </button>
          <p className="text-xs text-white/50 max-w-sm mt-2 leading-relaxed">
            Intelligent AI Travel Companion. Precision route synthesis, Himalayan environmental awareness, and personalized discovery.
          </p>
        </div>

        {/* Supporting Navigation Links */}
        <div className="flex flex-wrap items-center justify-center gap-6 text-xs text-white/70">
          <a href="#privacy" className="hover:text-white transition-colors">Privacy Policy</a>
          <a href="#terms" className="hover:text-white transition-colors">Terms of Service</a>
          <a href="#api" className="hover:text-white transition-colors">Developer API</a>
          <a href="#contact" className="hover:text-white transition-colors">Support & Contact</a>
        </div>

        {/* Copyright */}
        <div className="text-xs text-white/40 font-mono text-center md:text-right">
          <p>© 2026 TRAVIX Inc. All rights reserved.</p>
          <p className="mt-1 text-[11px] text-white/30">Crafted for the conscious mountain explorer.</p>
        </div>
      </div>
    </footer>
  );
}
