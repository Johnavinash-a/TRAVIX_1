import React from 'react';
import { motion } from 'framer-motion';
import { Compass, Sparkles, Utensils, Trees, Landmark, Star, Clock } from 'lucide-react';

const CATEGORY_MAP = {
  Adventure: { icon: Compass, color: 'text-amber-300', bg: 'bg-amber-400/10 border-amber-400/20' },
  Culture: { icon: Landmark, color: 'text-cyan-300', bg: 'bg-cyan-400/10 border-cyan-400/20' },
  Food: { icon: Utensils, color: 'text-rose-300', bg: 'bg-rose-400/10 border-rose-400/20' },
  Nature: { icon: Trees, color: 'text-emerald-300', bg: 'bg-emerald-400/10 border-emerald-400/20' },
  Relaxation: { icon: Sparkles, color: 'text-purple-300', bg: 'bg-purple-400/10 border-purple-400/20' },
};

export default function ExperienceCard({ experience }) {
  const meta = CATEGORY_MAP[experience.category] || CATEGORY_MAP.Adventure;
  const IconComponent = meta.icon;

  return (
    <motion.div
      whileHover={{ y: -3 }}
      className="p-4 rounded-2xl bg-white/[0.03] border border-white/10 hover:border-emerald-400/40 transition-all duration-300 backdrop-blur-md flex flex-col justify-between"
    >
      <div>
        <div className="flex items-center justify-between gap-2 mb-2.5">
          <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-semibold uppercase tracking-wider border ${meta.bg} ${meta.color}`}>
            <IconComponent size={11} />
            {experience.category}
          </span>
          <div className="flex items-center gap-2 text-xs text-white/60">
            {experience.duration && (
              <span className="flex items-center gap-1">
                <Clock size={11} /> {experience.duration}
              </span>
            )}
            {experience.rating && (
              <span className="flex items-center gap-1 text-amber-300 font-semibold">
                <Star size={11} fill="currentColor" /> {experience.rating}
              </span>
            )}
          </div>
        </div>

        <h4 className="text-sm font-bold text-white mb-1.5 leading-snug">
          {experience.title}
        </h4>
        <p className="text-xs text-white/65 leading-relaxed">
          {experience.description}
        </p>
      </div>
    </motion.div>
  );
}
