import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { MemoryRouter, Routes, Route } from 'react-router-dom';
import App from '../App';
import { Navbar } from '../components/Navbar';
import { TravelPlan } from '../components/TravelPlan';
import { TravelQuestion } from '../components/TravelQuestion';

// Mock framer-motion globally
vi.mock('framer-motion', () => ({
  motion: ({ children, ...props }) => <div {...props}>{children}</div>,
  AnimatePresence: ({ children }) => <>{children}</>,
  useReducedMotion: () => false,
}));

// Mock lucide-react
vi.mock('lucide-react', () => {
  const icons = ['MapPin', 'Clock3', 'Compass', 'Send', 'ShieldCheck', 'Sparkles', 'TrainFront', 'Utensils', 'Bot', 'CalendarDays', 'ArrowRight', 'Bookmark', 'Share2', 'ChevronDown', 'ChevronUp', 'Bed', 'Search', 'Navigation', 'ArrowLeft', 'Layers', 'Plus', 'Minus', 'Maximize2', 'ExternalLink', 'Info', 'RefreshCw', 'AlertTriangle', 'Home', 'MapPin', 'Calendar', 'Users', 'Bed', 'Utensils', 'Compass', 'Sparkles', 'ArrowRight', 'Bookmark', 'Share2', 'ChevronDown', 'ChevronUp', 'MapPin', 'Clock3', 'Compass', 'Send', 'ShieldCheck', 'Sparkles', 'TrainFront', 'Utensils', 'Bot'];
  const createIcon = (name) => ({ [name]: ({ size = 20, className = '', ...props }) => <svg width={size} height={size} className={className} {...props} data-testid={`icon-${name.toLowerCase()}`} /> });
  return Object.assign({}, ...icons.map(createIcon));
});

// Mock fetch globally
global.fetch = vi.fn();

describe('App Integration', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    (global.fetch as any).mockReset();
  });

  afterEach(() => {
    vi.resetAllMocks();
  });

  it('renders landing page with Hero', () => {
    render(<App />);
    expect(screen.getByText(/Travel Beyond/i)).toBeInTheDocument();
    expect(screen.getByText(/The Ordinary/i)).toBeInTheDocument();
  });

  it('shows suggested prompt chips', () => {
    render(<App />);
    expect(screen.getByText(/Himachal/i)).toBeInTheDocument();
  });

  it('transitions to chat view on prompt submit', async () => {
    render(<App />);
    const textarea = screen.getByPlaceholderText(/where do you want to go/i);
    fireEvent.change(textarea, { target: { value: 'Coorg' } });
    fireEvent.submit(screen.getByRole('form'));
    await waitFor(() => {
      expect(screen.getByText(/Great choice/i)).toBeInTheDocument();
    });
  });

  it('displays question cards in chat', async () => {
    render(<App />);
    const textarea = screen.getByPlaceholderText(/where do you want to go/i);
    fireEvent.change(textarea, { target: { value: 'Coorg' } });
    fireEvent.submit(screen.getByRole('form'));
    await waitFor(() => {
      expect(screen.getByText(/Budget/i)).toBeInTheDocument();
      expect(screen.getByText(/₹10,000/i)).toBeInTheDocument();
    });
  });
});

describe('Navbar', () => {
  it('renders logo and navigation', () => {
    render(
      <Navbar
        onLogoClick={vi.fn()}
        onGetStarted={vi.fn()}
        currentState="landing"
      />
    );
    expect(screen.getByText(/TRAVIX/i)).toBeInTheDocument();
    expect(screen.getByText(/Get Started/i)).toBeInTheDocument();
  });

  it('shows back button when not in landing', () => {
    render(
      <Navbar
        onLogoClick={vi.fn()}
        onGetStarted={vi.fn()}
        currentState="chat"
      />
    );
    expect(screen.getByText(/← Back/i)).toBeInTheDocument();
  });
});

describe('TravelPlan', () => {
  const mockPlan = {
    destinationName: 'Himachal Pradesh',
    durationText: '5 Days • 4 Nights',
    matchPercentage: 98,
    estimatedBudget: '₹18,500 – ₹24,000 / person',
    bestTimeToVisit: 'March to June',
    elevation: '2,050m – 3,978m MSL',
    tagline: 'Mountain journey',
    routeStats: { totalDistance: '468 km', waypointsCount: 5 },
    itinerary: [
      {
        day: 1,
        title: 'Arrival & Mountain Escape',
        theme: 'Acclimatization',
        overview: 'Arrive and settle in.',
        morning: 'Morning arrival',
        afternoon: 'Afternoon walk',
        evening: 'Evening rest',
        stay: 'Pine Chalet',
        coordinates: { lat: 32.2432, lng: 77.1892, name: 'Old Manali' }
      }
    ],
    destinations: [
      { name: 'Old Manali', type: 'Alpine Village', image: '/himalayan-bg.jpg', highlight: 'Cedar forests', elevation: '2,050m' }
    ],
    experiences: [
      { title: 'Paragliding', category: 'Adventure', duration: '45 mins', rating: 4.9, description: 'Soar above pines' }
    ],
    hotels: [
      { name: 'Pine Sanctuary', tier: 'Boutique', ratePerNight: '₹7,200', rating: 4.9, amenities: ['View', 'Fireplace'] }
    ]
  };

  it('renders plan header with destination', () => {
    render(<TravelPlan plan={mockPlan} onExploreRoute={vi.fn()} onRefineWithAI={vi.fn()} />);
    expect(screen.getByText(/Himachal Pradesh/i)).toBeInTheDocument();
    expect(screen.getByText(/5 Days/i)).toBeInTheDocument();
  });

  it('renders itinerary days', () => {
    render(<TravelPlan plan={mockPlan} onExploreRoute={vi.fn()} onRefineWithAI={vi.fn()} />);
    expect(screen.getByText(/Day 1/i)).toBeInTheDocument();
    expect(screen.getByText(/Arrival & Mountain Escape/i)).toBeInTheDocument();
  });

  it('calls onExploreRoute when explore button clicked', () => {
    const mockExplore = vi.fn();
    render(<TravelPlan plan={mockPlan} onExploreRoute={mockExplore} onRefineWithAI={vi.fn()} />);
    fireEvent.click(screen.getByText(/Explore Route/i));
    expect(mockExplore).toHaveBeenCalled();
  });
});

describe('TravelQuestion', () => {
  const mockQuestion = {
    id: 'budget',
    question: "What's your approximate budget?",
    options: [
      { label: '₹10,000', value: '₹10,000', description: 'Budget Explorer' },
      { label: '₹20,000', value: '₹20,000', description: 'Comfort & Scenic' },
    ]
  };

  it('renders question and options', () => {
    render(<TravelQuestion question={mockQuestion} selectedAnswer={null} onAnswer={vi.fn()} />);
    expect(screen.getByText(/What's your approximate budget/i)).toBeInTheDocument();
    expect(screen.getByText(/₹10,000/i)).toBeInTheDocument();
    expect(screen.getByText(/₹20,000/i)).toBeInTheDocument();
  });

  it('calls onAnswer when option clicked', () => {
    const mockAnswer = vi.fn();
    render(<TravelQuestion question={mockQuestion} selectedAnswer={null} onAnswer={mockAnswer} />);
    fireEvent.click(screen.getByText(/₹10,000/i));
    expect(mockAnswer).toHaveBeenCalledWith('budget', '₹10,000');
  });

  it('shows selected state', () => {
    render(<TravelQuestion question={mockQuestion} selectedAnswer="₹10,000" onAnswer={vi.fn()} />);
    expect(screen.getByText(/₹10,000/i)).toHaveClass('border-emerald-400');
  });
});

describe('ErrorBoundary', () => {
  it('catches errors in children', () => {
    const ThrowError = () => { throw new Error('Test error'); };
    render(
      <ErrorBoundary fallback={<div data-testid="fallback">Error caught</div>}>
        <ThrowError />
      </ErrorBoundary>
    );
    expect(screen.getByTestId('fallback')).toBeInTheDocument();
  });
});

// API integration tests (mocked fetch)
describe('API Integration', () => {
  beforeEach(() => {
    (global.fetch as any).mockReset();
  });

  it('calls /api/ai/chat on prompt submit', async () => {
    (global.fetch as any).mockResolvedValue({
      ok: true,
      json: () => Promise.resolve({
        message: 'AI response',
        recommendations: [],
        followUpQuestion: 'What is your budget?'
      })
    });

    render(<App />);
    const textarea = screen.getByPlaceholderText(/where do you want to go/i);
    fireEvent.change(textarea, { target: { value: 'Coorg' } });
    fireEvent.submit(screen.getByRole('form'));

    await waitFor(() => {
      expect(global.fetch).toHaveBeenCalledWith(
        '/api/ai/chat',
        expect.objectContaining({
          method: 'POST',
          body: expect.stringContaining('Coorg')
        })
      );
    });
  });
});