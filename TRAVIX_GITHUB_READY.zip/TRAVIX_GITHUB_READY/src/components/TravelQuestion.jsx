import React from 'react';
import { motion } from 'framer-motion';
import { Check, Compass, Trees, Sparkles, Landmark, Utensils, Flame } from 'lucide-react';

const ICON_MAP = {
  Compass,
  Trees,
  Sparkles,
  Landmark,
  Utensils,
  Flame,
};

export default function TravelQuestion({
  question,
  options = [],
  selectedOption,
  onSelectOption,
  disabled = false,
}) {
  return (
    <div className="w-full mt-3 p-4 rounded-2xl bg-white/[0.03] border border-white/[0.08] backdrop-blur-md">
      <p className="text-xs sm:text-sm font-semibold text-emerald-300/90 mb-3 flex items-center gap-2">
        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
        {question}
      </p>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
        {options.map((option) => {
          const isSelected = selectedOption === option.value;
          const IconComponent = option.icon ? ICON_MAP[option.icon] : null;

          return (
            <motion.button
              key={option.value}
              type="button"
              disabled={disabled}
              onClick={() => onSelectOption(option.value)}
              whileHover={disabled ? {} : { scale: 1.02, y: -2 }}
              whileTap={disabled ? {} : { scale: 0.98 }}
              className={`relative flex flex-col items-center text-center p-3 rounded-xl border transition-all duration-200 cursor-pointer outline-none ${
                isSelected
                  ? 'bg-emerald-500/15 border-emerald-400/80 text-white shadow-[0_0_20px_rgba(16,185,129,0.3)] ring-1 ring-emerald-400/40'
                  : 'bg-white/[0.03] border-white/10 hover:border-white/30 hover:bg-white/[0.07] text-white/80'
              } ${disabled && !isSelected ? 'opacity-50 cursor-not-allowed' : ''}`}
            >
              {isSelected && (
                <span className="absolute top-2 right-2 flex items-center justify-center w-4 h-4 rounded-full bg-emerald-400 text-black text-[10px]">
                  <Check size={10} strokeWidth={3} />
                </span>
              )}

              {IconComponent && (
                <IconComponent
                  size={20}
                  className={`mb-1.5 ${isSelected ? 'text-emerald-300' : 'text-white/60'}`}
                />
              )}

              <span className="text-sm font-bold text-white tracking-tight">
                {option.label}
              </span>

              {option.description && (
                <span className="text-[11px] text-white/50 mt-1 line-clamp-1">
                  {option.description}
                </span>
              )}
            </motion.button>
          );
        })}
      </div>
    </div>
  );
}
