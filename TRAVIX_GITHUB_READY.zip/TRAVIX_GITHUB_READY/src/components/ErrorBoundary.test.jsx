import { render, screen, fireEvent } from '@testing-library/react';
import { describe, it, expect, vi } from 'vitest';
import ErrorBoundary from '../components/ErrorBoundary';

describe('ErrorBoundary', () => {
  it('renders children when no error', () => {
    const ThrowError = () => { throw new Error('Test error'); };
    render(
      <ErrorBoundary fallback={<div>Fallback UI</div>}>
        <div data-testid="child">Child content</div>
      </ErrorBoundary>
    );
    expect(screen.getByTestId('child')).toBeInTheDocument();
  });

  it('renders fallback when error thrown in child', () => {
    const ThrowError = () => { throw new Error('Test error'); };
    render(
      <ErrorBoundary fallback={<div data-testid="fallback">Fallback UI</div>}>
        <ThrowError />
      </ErrorBoundary>
    );
    expect(screen.getByTestId('fallback')).toBeInTheDocument();
    expect(screen.getByText(/Something went wrong/i)).toBeInTheDocument();
  });

  it('shows error message in fallback', () => {
    const ThrowError = () => { throw new Error('Specific error message'); };
    render(
      <ErrorBoundary fallback={<div>Fallback</div>}>
        <ThrowError />
      </ErrorBoundary>
    );
    expect(screen.getByText('Specific error message')).toBeInTheDocument();
  });

  it('calls onRetry when reload button clicked', () => {
    const ThrowError = () => { throw new Error('Test error'); };
    const onRetry = vi.fn();
    render(
      <ErrorBoundary fallback={<button onClick={onRetry} data-testid="retry">Retry</button>}>
        <ThrowError />
      </ErrorBoundary>
    );
    fireEvent.click(screen.getByTestId('retry'));
    expect(onRetry).toHaveBeenCalled();
  });

  it('renders custom fallback when provided as prop', () => {
    const ThrowError = () => { throw new Error('Test error'); };
    const CustomFallback = () => <div data-testid="custom-fallback">Custom fallback!</div>;
    render(
      <ErrorBoundary fallback={<CustomFallback />}>
        <ThrowError />
      </ErrorBoundary>
    );
    expect(screen.getByTestId('custom-fallback')).toBeInTheDocument();
  });
});