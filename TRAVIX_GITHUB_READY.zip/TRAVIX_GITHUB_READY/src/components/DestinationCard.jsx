import React from 'react';
import { motion } from 'framer-motion';
import { Mountain, MapPin } from 'lucide-react';

export default function DestinationCard({ destination }) {
  return (
    <motion.div
      whileHover={{ y: -4 }}
      className="group relative rounded-2xl overflow-hidden bg-white/[0.03] border border-white/10 hover:border-emerald-400/40 transition-all duration-300 backdrop-blur-md flex flex-col"
    >
      <div className="relative h-48 w-full overflow-hidden">
        <img
          src={destination.image}
          alt={destination.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/30 to-transparent" />

        {destination.elevation && (
          <div className="absolute top-3 left-3">
            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-mono font-medium bg-black/60 backdrop-blur-md border border-white/10 text-emerald-300">
              <Mountain size={11} />
              {destination.elevation}
            </span>
          </div>
        )}

        <div className="absolute top-3 right-3">
          <span className="px-2.5 py-1 rounded-full text-[10px] font-semibold uppercase tracking-wider bg-white/10 backdrop-blur-md text-white border border-white/15">
            {destination.type}
          </span>
        </div>

        <div className="absolute bottom-3 left-3 right-3">
          <h4 className="text-base font-bold text-white leading-tight">
            {destination.name}
          </h4>
        </div>
      </div>

      <div className="p-4 flex-1 flex flex-col justify-between">
        <p className="text-xs text-white/70 leading-relaxed">
          {destination.highlight}
        </p>
      </div>
    </motion.div>
  );
}
