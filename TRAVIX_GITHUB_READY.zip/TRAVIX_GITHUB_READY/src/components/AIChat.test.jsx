import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import AIChat from '../components/AIChat';

describe('AIChat', () => {
  const mockMessages = [
    { id: '1', sender: 'ai', text: 'Hello! How can I help?', timestamp: '10:00', questionData: null },
    { id: '2', sender: 'user', text: 'I want to visit Coorg', timestamp: '10:01' },
  ];

  const defaultProps = {
    messages: mockMessages,
    onSendMessage: vi.fn(),
    onAnswerQuestion: vi.fn(),
    isThinking: false,
    thinkingText: 'Thinking...',
    inputValue: '',
    onInputChange: vi.fn(),
    onBackToLanding: vi.fn(),
    onResetChat: vi.fn(),
    onViewPlan: vi.fn(),
    hasPlanReady: false,
  };

  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('renders chat messages', () => {
    render(<AIChat {...defaultProps} />);
    expect(screen.getByText('Hello! How can I help?')).toBeInTheDocument();
    expect(screen.getByText('I want to visit Coorg')).toBeInTheDocument();
  });

  it('renders input field', () => {
    render(<AIChat {...defaultProps} />);
    expect(screen.getByPlaceholderText(/type your message/i)).toBeInTheDocument();
  });

  it('calls onSendMessage when form submitted', async () => {
    render(<AIChat {...defaultProps} />);
    const input = screen.getByPlaceholderText(/type your message/i);
    fireEvent.change(input, { target: { value: 'New message' } });
    fireEvent.submit(screen.getByRole('form'));
    await waitFor(() => expect(defaultProps.onSendMessage).toHaveBeenCalledWith('New message'));
  });

  it('shows thinking indicator when isThinking is true', () => {
    render(<AIChat {...defaultProps} isThinking={true} thinkingText="AI is thinking..." />);
    expect(screen.getByText('AI is thinking...')).toBeInTheDocument();
  });

  it('renders question card when message has questionData', () => {
    const props = {
      ...defaultProps,
      messages: [
        { id: '1', sender: 'ai', text: 'Choose budget', timestamp: '10:00', questionData: { id: 'budget', options: ['Low', 'Medium', 'High'] } }
      ]
    };
    render(<AIChat {...props} />);
    expect(screen.getByText('Low')).toBeInTheDocument();
    expect(screen.getByText('Medium')).toBeInTheDocument();
    expect(screen.getByText('High')).toBeInTheDocument();
  });

  it('calls onAnswerQuestion when option selected', () => {
    const props = {
      ...defaultProps,
      messages: [
        { id: '1', sender: 'ai', text: 'Choose budget', timestamp: '10:00', questionData: { id: 'budget', options: ['Low', 'Medium', 'High'] } }
      ]
    };
    render(<AIChat {...props} />);
    fireEvent.click(screen.getByText('Medium'));
    expect(defaultProps.onAnswerQuestion).toHaveBeenCalledWith('budget', 'Medium');
  });
});