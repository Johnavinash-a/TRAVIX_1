import React from 'react';
import { motion } from 'framer-motion';
import { Sparkles, Compass, Users, Calendar, ArrowUpRight } from 'lucide-react';
import { INITIAL_SUGGESTED_PROMPTS } from '../data/mockTravelData';

const PROMPT_ICONS = [
  Compass,
  Sparkles,
  Users,
  Calendar,
];

export default function SuggestedPrompts({ onSelectPrompt }) {
  return (
    <div className="w-full max-w-2xl mx-auto mt-4">
      <p className="text-center text-xs font-medium text-white/40 tracking-wider uppercase mb-2.5">
        Suggested Journeys
      </p>
      <div className="flex flex-wrap items-center justify-center gap-2">
        {INITIAL_SUGGESTED_PROMPTS.map((prompt, idx) => {
          const Icon = PROMPT_ICONS[idx % PROMPT_ICONS.length];
          return (
            <motion.button
              key={prompt}
              type="button"
              onClick={() => onSelectPrompt(prompt)}
              whileHover={{ scale: 1.03, y: -1 }}
              whileTap={{ scale: 0.98 }}
              className="group inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/[0.04] hover:bg-white/[0.09] backdrop-blur-md border border-white/[0.08] hover:border-emerald-400/40 text-xs text-white/80 hover:text-white transition-all duration-200 cursor-pointer shadow-sm shadow-black/20"
            >
              <Icon size={12} className="text-emerald-400/80 group-hover:text-emerald-300 transition-colors" />
              <span>{prompt}</span>
              <ArrowUpRight size={11} className="text-white/30 group-hover:text-white/70 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-all" />
            </motion.button>
          );
        })}
      </div>
    </div>
  );
}
