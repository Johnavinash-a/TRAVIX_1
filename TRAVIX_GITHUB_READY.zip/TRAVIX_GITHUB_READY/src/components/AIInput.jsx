import React, { useState, useRef, useEffect } from 'react';
import { motion } from 'framer-motion';
import { ArrowUp, Mic, Paperclip, Sparkles, X, Check } from 'lucide-react';

export default function AIInput({
  value,
  onChange,
  onSubmit,
  placeholder = "Where do you want to go? Ask Travix anything about your next journey...",
  disabled = false,
  isCompact = false,
  autoFocus = false,
}) {
  const [isFocused, setIsFocused] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [attachedFiles, setAttachedFiles] = useState([]);
  const textareaRef = useRef(null);
  const fileInputRef = useRef(null);

  // Auto-resize textarea height
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 180)}px`;
    }
  }, [value]);

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      if (value?.trim() && !disabled) {
        onSubmit(value.trim());
      }
    }
  };

  const handleFormSubmit = (e) => {
    e.preventDefault();
    if (value?.trim() && !disabled) {
      onSubmit(value.trim());
    }
  };

  const toggleMic = () => {
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
      // Mock speech input for demonstration if browser Web Speech API is not available
      setIsListening(true);
      setTimeout(() => {
        onChange((prev) => (prev ? prev + ' ' : '') + 'Plan a scenic 5-day mountain escape to Himachal with friends');
        setIsListening(false);
      }, 1500);
      return;
    }

    try {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang = 'en-US';

      recognition.onstart = () => setIsListening(true);
      recognition.onend = () => setIsListening(false);
      recognition.onerror = () => setIsListening(false);
      recognition.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        onChange(transcript);
      };

      recognition.start();
    } catch {
      setIsListening(false);
    }
  };

  const handleFileChange = (e) => {
    const files = Array.from(e.target.files || []);
    if (files.length) {
      setAttachedFiles((prev) => [...prev, ...files.map((f) => f.name)]);
    }
  };

  const removeAttachment = (fileName) => {
    setAttachedFiles((prev) => prev.filter((name) => name !== fileName));
  };

  const hasContent = Boolean(value?.trim());

  return (
    <div className={`w-full transition-all duration-300 ${isCompact ? 'max-w-3xl' : 'max-w-2xl'} mx-auto`}>
      <form
        onSubmit={handleFormSubmit}
        className={`relative flex flex-col rounded-2xl md:rounded-3xl border transition-all duration-300 ${
          isFocused
            ? 'border-emerald-400/60 bg-black/75 shadow-[0_0_35px_rgba(16,185,129,0.18)]'
            : 'border-white/15 bg-black/50 hover:border-white/30 hover:bg-black/60 shadow-2xl shadow-black/60'
        } backdrop-blur-2xl p-3 sm:p-4`}
      >
        {/* Render attached mock files if any */}
        {attachedFiles.length > 0 && (
          <div className="flex flex-wrap gap-2 pb-2 mb-2 border-b border-white/10">
            {attachedFiles.map((file) => (
              <span
                key={file}
                className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-emerald-400/10 border border-emerald-400/30 text-emerald-300 text-xs font-mono"
              >
                <Paperclip size={11} />
                <span className="max-w-[140px] truncate">{file}</span>
                <button
                  type="button"
                  onClick={() => removeAttachment(file)}
                  className="text-emerald-300/70 hover:text-emerald-200 ml-1"
                >
                  <X size={12} />
                </button>
              </span>
            ))}
          </div>
        )}

        {/* Textarea Input */}
        <div className="flex items-start gap-2.5">
          <textarea
            ref={textareaRef}
            rows={isCompact ? 1 : 2}
            value={value}
            onChange={(e) => onChange(e.target.value)}
            onFocus={() => setIsFocused(true)}
            onBlur={() => setIsFocused(false)}
            onKeyDown={handleKeyDown}
            placeholder={isListening ? "Listening to your journey request..." : placeholder}
            disabled={disabled}
            autoFocus={autoFocus}
            className={`w-full bg-transparent text-white placeholder:text-white/40 text-sm sm:text-base outline-none resize-none leading-relaxed transition-colors py-1 ${
              disabled ? 'opacity-50 cursor-not-allowed' : ''
            }`}
          />
        </div>

        {/* Input Bottom Action Bar */}
        <div className="flex items-center justify-between pt-2.5 mt-1 border-t border-white/[0.06]">
          {/* Left tools: Attachment & Mic */}
          <div className="flex items-center gap-1 sm:gap-2">
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileChange}
              multiple
              accept="image/*,.pdf"
              className="hidden"
            />
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              title="Attach travel inspiration or itinerary photo"
              className="p-2 text-white/50 hover:text-white/90 hover:bg-white/10 rounded-xl transition-all duration-150 cursor-pointer outline-none"
            >
              <Paperclip size={17} />
            </button>

            <button
              type="button"
              onClick={toggleMic}
              title={isListening ? "Stop listening" : "Speak your destination or travel wish"}
              className={`p-2 rounded-xl transition-all duration-150 cursor-pointer outline-none ${
                isListening
                  ? 'bg-emerald-500/20 text-emerald-300 animate-pulse border border-emerald-400/40'
                  : 'text-white/50 hover:text-white/90 hover:bg-white/10'
              }`}
            >
              <Mic size={17} />
            </button>

            {isListening && (
              <span className="text-[11px] text-emerald-400 animate-pulse hidden sm:inline font-mono">
                Listening...
              </span>
            )}
          </div>

          {/* Right submit button */}
          <div className="flex items-center gap-2">
            <span className="hidden sm:inline text-[11px] text-white/30 font-mono">
              Press Enter ↵
            </span>
            <motion.button
              type="submit"
              disabled={!hasContent || disabled}
              whileHover={hasContent ? { scale: 1.05 } : {}}
              whileTap={hasContent ? { scale: 0.95 } : {}}
              className={`flex items-center justify-center w-9 h-9 sm:w-10 sm:h-10 rounded-xl sm:rounded-2xl transition-all duration-200 outline-none cursor-pointer ${
                hasContent
                  ? 'bg-gradient-to-br from-emerald-400 to-teal-500 text-black shadow-[0_0_20px_rgba(16,185,129,0.45)]'
                  : 'bg-white/10 text-white/30 cursor-not-allowed'
              }`}
              aria-label="Send travel prompt"
            >
              <ArrowUp size={18} strokeWidth={2.5} />
            </motion.button>
          </div>
        </div>
      </form>
    </div>
  );
}
