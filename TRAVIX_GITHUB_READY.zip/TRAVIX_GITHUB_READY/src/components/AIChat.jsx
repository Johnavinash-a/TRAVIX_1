import React, { useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Sparkles, ArrowLeft, RotateCcw } from 'lucide-react';
import ChatMessage from './ChatMessage';
import AIInput from './AIInput';

export default function AIChat({
  messages = [],
  onSendMessage,
  onAnswerQuestion,
  isThinking = false,
  thinkingText = "Travix is planning your journey...",
  inputValue = "",
  onInputChange,
  onBackToLanding,
  onResetChat,
  onViewPlan,
  hasPlanReady = false,
}) {
  const messagesEndRef = useRef(null);

  // Auto-scroll to bottom of chat
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isThinking]);

  return (
    <section className="relative min-h-screen w-full flex flex-col justify-between bg-black text-white selection:bg-emerald-400/20 selection:text-white pt-20 pb-6 px-3 sm:px-6">
      {/* Background Ambient Himalayan Scrim */}
      <div className="fixed inset-0 pointer-events-none z-0">
        <div 
          className="absolute inset-0 bg-cover bg-center opacity-25 filter blur-sm brightness-50"
          style={{ backgroundImage: `url(/himalayan-bg.jpg)` }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/80 via-black/70 to-black/95" />
        <div className="absolute top-20 left-1/3 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
      </div>

      {/* Top Chat Header Bar */}
      <div className="relative z-20 max-w-3xl mx-auto w-full flex items-center justify-between py-3 px-4 rounded-2xl bg-white/[0.04] backdrop-blur-xl border border-white/10 mb-4 shadow-lg">
        <button
          type="button"
          onClick={onBackToLanding}
          className="inline-flex items-center gap-1.5 text-xs text-white/70 hover:text-white transition-colors cursor-pointer px-2 py-1 rounded-lg hover:bg-white/10"
        >
          <ArrowLeft size={14} />
          <span>Home</span>
        </button>

        <div className="flex items-center gap-2">
          <span className="flex items-center justify-center w-5 h-5 rounded-full bg-emerald-400/20 text-emerald-300 text-xs">
            ✦
          </span>
          <span className="text-sm font-bold tracking-wider text-white">
            TRAVIX AI
          </span>
        </div>

        <div className="flex items-center gap-2">
          {hasPlanReady && (
            <button
              type="button"
              onClick={onViewPlan}
              className="text-xs font-semibold px-3 py-1 rounded-full bg-emerald-400 text-black shadow-[0_0_15px_rgba(16,185,129,0.3)] hover:scale-105 transition-all cursor-pointer"
            >
              View Plan ↓
            </button>
          )}
          <button
            type="button"
            onClick={onResetChat}
            title="Start over"
            className="p-1.5 text-white/50 hover:text-white/90 hover:bg-white/10 rounded-lg transition-colors cursor-pointer"
          >
            <RotateCcw size={14} />
          </button>
        </div>
      </div>

      {/* Chat Messages Stream */}
      <div className="relative z-10 flex-1 max-w-3xl mx-auto w-full overflow-y-auto pr-1">
        {messages.map((msg) => (
          <ChatMessage
            key={msg.id}
            message={msg}
            onAnswerQuestion={onAnswerQuestion}
          />
        ))}

        {/* AI Thinking Animation */}
        <AnimatePresence>
          {isThinking && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="flex items-center gap-3 my-4 p-4 rounded-2xl bg-white/[0.04] border border-emerald-400/20 backdrop-blur-xl max-w-md"
            >
              <div className="flex items-center justify-center w-8 h-8 rounded-full bg-emerald-500/20 text-emerald-300">
                <Sparkles size={16} className="animate-spin text-emerald-400" />
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="text-xs font-semibold text-emerald-300">
                    ✦ {thinkingText}
                  </span>
                </div>
                <div className="flex items-center gap-1 mt-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-bounce [animation-delay:-0.3s]" />
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-bounce [animation-delay:-0.15s]" />
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-bounce" />
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <div ref={messagesEndRef} />
      </div>

      {/* Sticky Bottom Prompt Box */}
      <div className="relative z-20 max-w-3xl mx-auto w-full pt-3">
        <AIInput
          value={inputValue}
          onChange={onInputChange}
          onSubmit={onSendMessage}
          placeholder="Ask Travix anything about your journey..."
          disabled={isThinking}
          isCompact
        />
        <p className="text-center text-[10px] text-white/30 mt-2 font-mono">
          TRAVIX AI specializes in routes, seasonal timings, stays, and mountain intelligence.
        </p>
      </div>
    </section>
  );
}
