import React, { useRef, useEffect } from 'react';
import { motion } from 'framer-motion';
import AIInput from './AIInput';
import SuggestedPrompts from './SuggestedPrompts';

const CAPABILITIES = [
  { icon: '✦', label: 'AI Travel Assistant' },
  { icon: '⌁', label: 'Smart Travel Planning' },
  { icon: '☁', label: 'Live Weather' },
  { icon: '♡', label: 'Personalized Experiences' },
  { icon: '◈', label: 'Travel Memories' },
];

export default function Hero({
  inputValue,
  onInputChange,
  onSubmitPrompt,
  onSelectSuggestedPrompt,
  posterSrc = "/himalayan-bg.jpg",
  videoSrc = "https://assets.mixkit.co/videos/preview/mixkit-clouds-and-blue-sky-over-a-mountain-range-41484-large.mp4",
}) {
  const videoRef = useRef(null);

  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.playbackRate = 0.55;
    }
  }, []);

  return (
    <section className="relative min-h-screen w-full flex flex-col justify-between overflow-hidden bg-black text-white">
      {/* 1. CINEMATIC HIMALAYAN BACKGROUND WITH AMBIENT LIGHTING */}
      <div className="absolute inset-0 w-full h-full pointer-events-none z-0 overflow-hidden">
        <video
          ref={videoRef}
          autoPlay
          muted
          loop
          playsInline
          poster={posterSrc}
          className="absolute inset-0 w-full h-full object-cover z-0 filter brightness-[0.82] contrast-[1.08] saturate-[1.05]"
          aria-hidden="true"
        >
          {videoSrc && <source src={videoSrc} type="video/mp4" />}
        </video>

        {/* Static fallback image */}
        <div
          className="absolute inset-0 w-full h-full bg-cover bg-center -z-10"
          style={{ backgroundImage: `url(${posterSrc})` }}
          aria-hidden="true"
        />

        {/* Ambient emerald & cyan glowing highlights */}
        <div className="absolute -top-40 left-1/2 -translate-x-1/2 w-[700px] h-[500px] bg-gradient-to-b from-emerald-500/15 via-cyan-500/10 to-transparent blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 right-10 w-[450px] h-[350px] bg-emerald-600/10 blur-3xl pointer-events-none" />

        {/* Dark gradient overlay for clear contrast while preserving Himalayan vistas */}
        <div className="absolute inset-0 bg-black/30 z-[1]" />
        <div className="absolute inset-0 bg-gradient-to-b from-black/75 via-black/25 to-black/90 z-[1]" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_30%,rgba(0,0,0,0.65)_100%)] z-[1]" />
      </div>

      {/* 2. CENTER HERO CONTENT */}
      <div className="relative z-10 flex-1 flex flex-col items-center justify-center text-center px-4 sm:px-6 pt-32 pb-12 max-w-4xl mx-auto w-full">
        {/* Small AI Badge */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="inline-flex items-center gap-2 rounded-full bg-white/[0.07] backdrop-blur-xl border border-emerald-400/30 px-3.5 py-1.5 text-xs font-medium text-white shadow-[0_0_20px_rgba(16,185,129,0.15)] mb-6 cursor-default"
        >
          <span className="text-emerald-400 text-xs animate-pulse">✦</span>
          <span className="tracking-[0.16em] uppercase font-mono text-[11px] text-emerald-200">
            AI-POWERED TRAVEL
          </span>
        </motion.div>

        {/* Main Heading */}
        <motion.h1
          initial={{ opacity: 0, y: 22 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.1 }}
          className="font-bold text-4xl sm:text-6xl md:text-[68px] leading-[1.08] tracking-[-0.03em] text-white max-w-3xl"
        >
          Travel Beyond <br />
          <span className="italic font-serif font-light text-emerald-200/95 tracking-normal">
            The Ordinary
          </span>
        </motion.h1>

        {/* Subheading */}
        <motion.p
          initial={{ opacity: 0, y: 18 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="text-sm sm:text-base md:text-lg text-white/80 max-w-xl leading-relaxed mt-5 text-balance font-normal"
        >
          Your intelligent travel companion for discovering places, planning journeys, and creating experiences made for you.
        </motion.p>

        {/* 3. MAIN AI PROMPT BOX (CHATGPT-STYLE) */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.3 }}
          className="w-full mt-8 sm:mt-10"
        >
          <AIInput
            value={inputValue}
            onChange={onInputChange}
            onSubmit={onSubmitPrompt}
            placeholder="Where do you want to go? Ask Travix anything about your next journey..."
          />

          {/* Suggested Example Prompts Underneath */}
          <SuggestedPrompts onSelectPrompt={onSelectSuggestedPrompt} />
        </motion.div>
      </div>

      {/* 4. SUBTLE CAPABILITY ROW */}
      <footer className="relative z-10 w-full border-t border-white/[0.08] bg-black/50 backdrop-blur-xl py-5 px-6">
        <div className="max-w-4xl mx-auto flex flex-wrap items-center justify-center md:justify-between gap-5 sm:gap-7 text-xs sm:text-sm text-white/75 font-medium">
          {CAPABILITIES.map((cap, i) => (
            <motion.div
              key={cap.label}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 0.75, y: 0 }}
              transition={{ delay: 0.4 + i * 0.07, duration: 0.4 }}
              whileHover={{ opacity: 1, y: -1 }}
              className="flex items-center gap-2 cursor-default transition-all duration-200"
            >
              <span className="text-emerald-400 text-xs">{cap.icon}</span>
              <span className="tracking-wide text-white/80">{cap.label}</span>
            </motion.div>
          ))}
        </div>
      </footer>
    </section>
  );
}
