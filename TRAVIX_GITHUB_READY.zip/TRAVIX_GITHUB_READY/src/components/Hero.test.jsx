import { render, screen, fireEvent } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import Hero from '../components/Hero';

describe('Hero', () => {
  const mockSubmit = vi.fn();
  const mockSelect = vi.fn();

  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('renders hero section with headline', () => {
    render(<Hero
      inputValue=""
      onInputChange={vi.fn()}
      onSubmitPrompt={mockSubmit}
      onSelectSuggestedPrompt={mockSelect}
      posterSrc="/himalayan-bg.jpg"
    />);

    expect(screen.getByText(/Travel Beyond/i)).toBeInTheDocument();
    expect(screen.getByText(/The Ordinary/i)).toBeInTheDocument();
  });

  it('renders suggested prompt chips', () => {
    render(<Hero
      inputValue=""
      onInputChange={vi.fn()}
      onSubmitPrompt={mockSubmit}
      onSelectSuggestedPrompt={mockSelect}
      posterSrc="/himalayan-bg.jpg"
    />);

    expect(screen.getByText(/Spiti Valley/i)).toBeInTheDocument();
    expect(screen.getByText(/Ladakh/i)).toBeInTheDocument();
  });

  it('calls onSelectSuggestedPrompt when chip clicked', () => {
    render(<Hero
      inputValue=""
      onInputChange={vi.fn()}
      onSubmitPrompt={mockSubmit}
      onSelectSuggestedPrompt={mockSelect}
      posterSrc="/himalayan-bg.jpg"
    />);

    const chip = screen.getByText(/Spiti Valley/i);
    fireEvent.click(chip);
    expect(mockSelect).toHaveBeenCalledWith(expect.stringContaining('Spiti'));
  });

  it('calls onSubmitPrompt when form submitted', () => {
    render(<Hero
      inputValue="test query"
      onInputChange={vi.fn()}
      onSubmitPrompt={mockSubmit}
      onSelectSuggestedPrompt={mockSelect}
      posterSrc="/himalayan-bg.jpg"
    />);

    const form = screen.getByRole('form');
    fireEvent.submit(form);
    expect(mockSubmit).toHaveBeenCalledWith('test query');
  });
});