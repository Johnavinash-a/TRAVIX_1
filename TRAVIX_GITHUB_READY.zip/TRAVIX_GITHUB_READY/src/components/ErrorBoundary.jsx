import React, { Component, useEffect } from 'react';
import { RefreshCw, AlertTriangle, Home, ExternalLink } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

class ErrorBoundary extends Component {
  state = { hasError: false, error: null, errorInfo: null };

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    this.setState({ error, errorInfo });
    console.error('[ErrorBoundary] Caught error:', error);
    console.error('[ErrorBoundary] Component stack:', errorInfo?.componentStack);
  }

  handleRetry = () => {
    this.setState({ hasError: false, error: null, errorInfo: null });
    window.location.reload();
  };

  render() {
    if (this.state.hasError) {
      return this.props.fallback || (
        <ErrorFallback
          error={this.state.error}
          errorInfo={this.state.errorInfo}
          onRetry={this.handleRetry}
        />
      );
    }
    return this.props.children;
  }
}

function ErrorFallback({ error, errorInfo, onRetry }) {
  useEffect(() => {
    document.title = 'Error | TRAVIX';
  }, []);

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="min-h-screen bg-slate-950 text-white flex items-center justify-center p-4"
    >
      <motion.div
        className="max-w-md w-full text-center"
        initial={{ y: 20 }}
        animate={{ y: 0 }}
        transition={{ duration: 0.4 }}
      >
        <AnimatePresence>
          <motion.div
            key="error-icon"
            initial={{ scale: 0, rotate: -180 }}
            animate={{ scale: 1, rotate: 0 }}
            exit={{ scale: 0, rotate: 180 }}
            className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-rose-500/20 border border-rose-500/40 mb-6"
          >
            <AlertTriangle size={32} className="text-rose-400" />
          </motion.div>
        </AnimatePresence>

        <h1 className="text-2xl font-bold text-white mb-3">Something went wrong</h1>
        <p className="text-slate-400 mb-6 leading-relaxed">
          We encountered an unexpected issue. Your journey data is safe — this is just a UI glitch.
        </p>

        {error && (
          <details className="mb-6 text-left bg-slate-900/50 border border-white/10 rounded-xl p-4">
            <summary className="text-xs font-mono text-emerald-400 cursor-pointer mb-2">
              Technical Details (click to expand)
            </summary>
            <pre className="text-[10px] text-slate-300 overflow-auto max-h-48 whitespace-pre-wrap font-mono">
              {error.message}
              {errorInfo?.componentStack && `\n\n${errorInfo.componentStack}`}
            </pre>
          </details>
        )}

        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={onRetry}
            className="flex-1 flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-emerald-400 text-slate-950 font-semibold text-sm transition-colors hover:bg-emerald-300"
          >
            <RefreshCw size={16} />
            <span>Reload Application</span>
          </motion.button>

          <motion.a
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            href="/"
            className="flex-1 flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-white/5 border border-white/10 text-white/80 hover:text-white text-sm transition-colors hover:bg-white/10"
          >
            <Home size={16} />
            <span>Back to Home</span>
          </motion.a>
        </div>

        <p className="mt-6 text-xs text-slate-500">
          If this persists, <a href="mailto:support@travix.ai" className="text-emerald-400 hover:underline">contact support</a> with the error details above.
        </p>
      </motion.div>
    </motion.div>
  );
}

export default ErrorBoundary;