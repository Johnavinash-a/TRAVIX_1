import React, { useState, useEffect } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import AIChat from './components/AIChat';
import TravelPlan from './components/TravelPlan';
import LocationPermission from './components/LocationPermission';
import SmartMap from './components/SmartMap';
import Footer from './components/Footer';
import ErrorBoundary from './components/ErrorBoundary';
import { MapProvider } from './components/MapProvider';
import { api } from './lib/api';
import {
  FOLLOW_UP_QUESTIONS,
  generateDynamicTravelPlan,
  CURATED_PLANS
} from './data/mockTravelData';

async function callAI(message, context = {}) {
  try {
    return await api.ai.chat(message, context.conversationId, context.userId);
  } catch {
    return null;
  }
}

async function fetchWeather(location) {
  if (!location) return null;
  try {
    return await api.weather(location);
  } catch {
    return null;
  }
}

export default function App() {
  // State Machine: 'landing' | 'chat' | 'travelPlan' | 'map'
  const [viewState, setViewState] = useState('landing');
  
  // Prompt input state
  const [landingInput, setLandingInput] = useState('');
  const [chatInput, setChatInput] = useState('');

  // Conversational State
  const [messages, setMessages] = useState([]);
  const [isThinking, setIsThinking] = useState(false);
  const [thinkingText, setThinkingText] = useState('Travix is planning your journey...');
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [userAnswers, setUserAnswers] = useState({
    budget: null,
    travelers: null,
    experience: null,
  });
  const [initialUserPrompt, setInitialUserPrompt] = useState('');

  // Generated Travel Plan
  const [travelPlan, setTravelPlan] = useState(null);

  // Location Permission Modal State
  const [showLocationModal, setShowLocationModal] = useState(false);
  const [userCoordinates, setUserCoordinates] = useState(null);

  // Backend integration
  const [weatherData, setWeatherData] = useState(null);
  const [conversationId] = useState(`conv_${Date.now()}`);
  const [userId] = useState(`user_${Date.now()}`);

  // Helper to format timestamps
  const getCurrentTime = () => {
    const d = new Date();
    return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  // 1. User submits prompt from Landing Page
  const handleLandingSubmit = async (promptText) => {
    if (!promptText?.trim()) return;
    const text = promptText.trim();
    setInitialUserPrompt(text);
    setViewState('chat');

    // Create user message
    const userMsg = {
      id: `msg_${Date.now()}_user`,
      sender: 'user',
      text,
      timestamp: getCurrentTime(),
    };

    setMessages([userMsg]);
    setIsThinking(true);
    setThinkingText('Travix AI is analyzing your destination request...');

    try {
      const response = await callAI(text, { conversationId, userId });
      if (response && response.message) {
        setIsThinking(false);
        const firstQuestion = FOLLOW_UP_QUESTIONS[0];
        const aiGreetingMsg = {
          id: `msg_${Date.now()}_ai_1`,
          sender: 'ai',
          text: `Great choice.\n\nI can build a personalized journey for "${text}".\n\nBefore I create your plan, I need a few details to tailor the route to your style.`,
          timestamp: getCurrentTime(),
          questionData: firstQuestion,
          selectedAnswer: null,
        };
        setMessages((prev) => [...prev, aiGreetingMsg]);
        setCurrentQuestionIndex(0);
      } else {
        throw new Error('Fallback');
      }
    } catch {
      setTimeout(() => {
      setIsThinking(false);
      const firstQuestion = FOLLOW_UP_QUESTIONS[0];
      
      const aiGreetingMsg = {
        id: `msg_${Date.now()}_ai_1`,
        sender: 'ai',
        text: `Great choice.\n\nI can build a personalized journey for "${text}".\n\nBefore I create your plan, I need a few details to tailor the route to your style.`,
        timestamp: getCurrentTime(),
        questionData: firstQuestion,
        selectedAnswer: null,
      };

      setMessages((prev) => [...prev, aiGreetingMsg]);
      setCurrentQuestionIndex(0);
      }, 900);
      }
    };

  // 2. User selects an example suggested prompt chip
  const handleSelectSuggestedPrompt = (prompt) => {
    setLandingInput(prompt);
    handleLandingSubmit(prompt);
  };

  // 3. User answers an interactive question card
  const handleAnswerQuestion = (questionId, selectedValue) => {
    const updatedAnswers = { ...userAnswers, [questionId]: selectedValue };
    setUserAnswers(updatedAnswers);

    // Update the message so the selected button remains marked
    setMessages((prev) =>
      prev.map((m) =>
        m.questionData?.id === questionId ? { ...m, selectedAnswer: selectedValue } : m
      )
    );

    // Append user selection message in chat
    const userSelectionMsg = {
      id: `msg_${Date.now()}_user_ans`,
      sender: 'user',
      text: selectedValue,
      timestamp: getCurrentTime(),
    };

    setMessages((prev) => [...prev, userSelectionMsg]);

    const nextIndex = currentQuestionIndex + 1;

    if (nextIndex < FOLLOW_UP_QUESTIONS.length) {
      // Ask the next question
      setIsThinking(true);
      setThinkingText('Updating journey preferences...');

      setTimeout(() => {
        setIsThinking(false);
        const nextQ = FOLLOW_UP_QUESTIONS[nextIndex];
        const nextAiMsg = {
          id: `msg_${Date.now()}_ai_q_${nextIndex}`,
          sender: 'ai',
          text: `Got it (${selectedValue}). Next:`,
          timestamp: getCurrentTime(),
          questionData: nextQ,
          selectedAnswer: null,
        };

        setMessages((prev) => [...prev, nextAiMsg]);
        setCurrentQuestionIndex(nextIndex);
      }, 600);
    } else {
      // All required questions answered -> synthesize Travel Plan!
      setIsThinking(true);
      setThinkingText('Synthesizing your personalized Himalayan route & itinerary...');

      setTimeout(() => {
        setIsThinking(false);
        const plan = generateDynamicTravelPlan(initialUserPrompt, updatedAnswers);
        setTravelPlan(plan);

        const completionMsg = {
          id: `msg_${Date.now()}_ai_done`,
          sender: 'ai',
          text: `✦ Your journey plan is ready!\n\nI've generated a comprehensive ${plan.durationText} itinerary for ${plan.destinationName} featuring mountain passes, stays, and curated activities.\n\nYou can review your day-by-day plan below or explore the interactive route on the map when you're ready.`,
          timestamp: getCurrentTime(),
        };

        setMessages((prev) => [...prev, completionMsg]);

        // Transition smoothly to travelPlan view
        setTimeout(() => {
          setViewState('travelPlan');
        }, 800);
      }, 1200);
    }
  };

  // 4. User sends a free-form message in chat input
  const handleChatSendMessage = async (text) => {
    if (!text?.trim()) return;
    const cleanText = text.trim();
    setChatInput('');

    const userMsg = {
      id: `msg_${Date.now()}_user`,
      sender: 'user',
      text: cleanText,
      timestamp: getCurrentTime(),
    };

    setMessages((prev) => [...prev, userMsg]);
    setIsThinking(true);
    setThinkingText('Travix AI is thinking...');

    try {
      const response = await callAI(cleanText, { conversationId, userId });
      if (response && response.message) {
        setIsThinking(false);
        if (travelPlan && response.recommendations) {
          const revisedPlan = generateDynamicTravelPlan(cleanText || initialUserPrompt, userAnswers);
          setTravelPlan(revisedPlan);
          const replyMsg = {
            id: `msg_${Date.now()}_ai`,
            sender: 'ai',
            text: response.message || `I've updated your itinerary based on "${cleanText}".`,
            timestamp: getCurrentTime(),
          };
          setMessages((prev) => [...prev, replyMsg]);
        } else if (response.recommendations && response.recommendations.length > 0) {
          const replyMsg = {
            id: `msg_${Date.now()}_ai`,
            sender: 'ai',
            text: response.message,
            timestamp: getCurrentTime(),
            recommendations: response.recommendations,
          };
          setMessages((prev) => [...prev, replyMsg]);
          if (response.followUpQuestion) {
            const qMsg = {
              id: `msg_${Date.now()}_ai_followup`,
              sender: 'ai',
              text: response.followUpQuestion,
              timestamp: getCurrentTime(),
            };
            setMessages((prev) => [...prev, qMsg]);
          }
        } else {
          const replyMsg = {
            id: `msg_${Date.now()}_ai`,
            sender: 'ai',
            text: response.message || `Noted: "${cleanText}". Let's finish answering the quick preferences above so I can compute your route and costs.`,
            timestamp: getCurrentTime(),
          };
          setMessages((prev) => [...prev, replyMsg]);
        }
      } else {
        throw new Error('Fallback');
      }
    } catch {
      setTimeout(() => {
        setIsThinking(false);
        
        // If plan already exists, adjust it
        if (travelPlan) {
          const revisedPlan = generateDynamicTravelPlan(cleanText || initialUserPrompt, userAnswers);
          setTravelPlan(revisedPlan);

          const replyMsg = {
            id: `msg_${Date.now()}_ai`,
            sender: 'ai',
            text: `I've updated your itinerary based on "${cleanText}". You can inspect the updated stops and elevation profile.`,
            timestamp: getCurrentTime(),
          };
          setMessages((prev) => [...prev, replyMsg]);
        } else {
          const replyMsg = {
            id: `msg_${Date.now()}_ai`,
            sender: 'ai',
            text: `Noted: "${cleanText}". Let's finish answering the quick preferences above so I can compute your route and costs.`,
            timestamp: getCurrentTime(),
          };
          setMessages((prev) => [...prev, replyMsg]);
        }
      }, 800);
    }
  };

  // 5. User clicks "Explore Route" or "View on Map"
  const handleExploreRouteClick = async () => {
    setShowLocationModal(true);
    const weather = await fetchWeather(travelPlan?.destinationName || 'Himachal');
    if (weather) setWeatherData(weather);
  };

  const handleLocationAllowed = (coords) => {
    setUserCoordinates(coords);
    setShowLocationModal(false);
    setViewState('map');
    fetchWeather(travelPlan?.destinationName || 'Himachal').then(setWeatherData);
  };

  // 7. User clicks "Not Now" on location modal
  const handleLocationNotNow = () => {
    setShowLocationModal(false);
    setViewState('map');
  };

  // Reset to landing
  const handleResetToLanding = () => {
    setViewState('landing');
    setLandingInput('');
  };

  // Reset entire conversation
  const handleResetChat = () => {
    setMessages([]);
    setCurrentQuestionIndex(0);
    setUserAnswers({ budget: null, travelers: null, experience: null });
    setTravelPlan(null);
    setViewState('landing');
  };

  return (
    <ErrorBoundary>
      <MapProvider initialRoute={travelPlan}>
      <div className="min-h-screen bg-slate-950 text-white selection:bg-emerald-400/20 selection:text-white flex flex-col justify-between">
        {/* Persistent Floating Navbar (only when not in full map view) */}
        {viewState !== 'map' && (
          <Navbar
            onLogoClick={handleResetToLanding}
            onGetStarted={() => {
              if (viewState === 'landing') {
                const el = document.querySelector('textarea');
                el?.focus();
              } else {
                setViewState('landing');
              }
            }}
            currentState={viewState}
          />
        )}

        {/* View State Rendering */}
        <main className="flex-1 w-full">
          <AnimatePresence mode="wait">
            {/* 1. INITIAL LANDING PAGE (AI-FIRST HERO) */}
            {viewState === 'landing' && (
              <motion.div
                key="landing-view"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.4 }}
              >
                <Hero
                  inputValue={landingInput}
                  onInputChange={setLandingInput}
                  onSubmitPrompt={handleLandingSubmit}
                  onSelectSuggestedPrompt={handleSelectSuggestedPrompt}
                  posterSrc="/himalayan-bg.jpg"
                />
              </motion.div>
            )}

            {/* 2. CHAT & QUESTIONS INTERACTION */}
            {viewState === 'chat' && (
              <motion.div
                key="chat-view"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.4 }}
              >
                <AIChat
                  messages={messages}
                  onSendMessage={handleChatSendMessage}
                  onAnswerQuestion={handleAnswerQuestion}
                  isThinking={isThinking}
                  thinkingText={thinkingText}
                  inputValue={chatInput}
                  onInputChange={setChatInput}
                  onBackToLanding={handleResetToLanding}
                  onResetChat={handleResetChat}
                  onViewPlan={() => setViewState('travelPlan')}
                  hasPlanReady={Boolean(travelPlan)}
                />
              </motion.div>
            )}

            {/* 3. TRAVEL PLAN RESULT PAGE */}
            {viewState === 'travelPlan' && (
              <motion.div
                key="plan-view"
                initial={{ opacity: 0, y: 25 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -25 }}
                transition={{ duration: 0.4 }}
                className="pt-24 pb-16"
              >
                {/* Back to AI Chat Bar */}
                <div className="max-w-5xl mx-auto px-4 sm:px-6 mb-4 flex items-center justify-between">
                  <button
                    type="button"
                    onClick={() => setViewState('chat')}
                    className="inline-flex items-center gap-2 text-xs text-emerald-300 hover:text-emerald-200 transition-colors bg-white/5 border border-white/10 px-3 py-1.5 rounded-full cursor-pointer hover:bg-white/10"
                  >
                    <span>← Back to AI Chat</span>
                  </button>
                  <button
                    type="button"
                    onClick={handleResetChat}
                    className="text-xs text-white/50 hover:text-white transition-colors cursor-pointer"
                  >
                    Plan Another Trip
                  </button>
                </div>

                <TravelPlan
                  plan={travelPlan || CURATED_PLANS.himachal}
                  onExploreRoute={handleExploreRouteClick}
                  onRefineWithAI={() => setViewState('chat')}
                  userAnswers={userAnswers}
                  weatherData={weatherData}
                />
              </motion.div>
            )}

            {/* 4. SMART MAP EXPERIENCE */}
            {viewState === 'map' && (
              <motion.div
                key="map-view"
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.98 }}
                transition={{ duration: 0.4 }}
                className="w-full min-h-screen"
              >
                 <SmartMap
                   plan={travelPlan || CURATED_PLANS.himachal}
                   onBackToPlan={() => setViewState('travelPlan')}
                   onBackToChat={() => setViewState('chat')}
                   weatherData={weatherData}
                 />
              </motion.div>
            )}
          </AnimatePresence>
        </main>

        {/* Location Permission Context Modal (Strictly shown only after user clicks Explore Route) */}
        <LocationPermission
          isOpen={showLocationModal}
          onAllowLocation={handleLocationAllowed}
          onNotNow={handleLocationNotNow}
          destinationName={travelPlan?.destinationName || 'Himachal'}
        />

        {/* Footer (shown on landing and travelPlan views) */}
        {(viewState === 'landing' || viewState === 'travelPlan') && (
          <Footer onLogoClick={handleResetToLanding} />
        )}
      </div>
    </MapProvider>
    </ErrorBoundary>
  );
}
