type LogLevel = 'debug' | 'info' | 'warn' | 'error';

interface LogEntry {
  level: LogLevel;
  message: string;
  timestamp: string;
  context?: Record<string, unknown>;
  error?: Error;
}

class Logger {
  private logs: LogEntry[] = [];
  private maxLogs = 1000;
  private isDevelopment = import.meta.env.DEV;

  private formatMessage(level: LogLevel, message: string, context?: Record<string, unknown>, error?: Error): LogEntry {
    return {
      level,
      message,
      timestamp: new Date().toISOString(),
      context,
      error,
    };
  }

  private addLog(entry: LogEntry) {
    this.logs.push(entry);
    if (this.logs.length > this.maxLogs) {
      this.logs.shift();
    }

    if (this.isDevelopment) {
      const style = this.getConsoleStyle(entry.level);
      console.log(`%c[${entry.timestamp}] ${entry.level.toUpperCase()}: ${entry.message}`, style, entry.context || '', entry.error || '');
    }
  }

  private getConsoleStyle(level: LogLevel): string {
    switch (level) {
      case 'debug': return 'color: #888; font-size: 11px;';
      case 'info': return 'color: #38bdf8; font-size: 11px; font-weight: bold;';
      case 'warn': return 'color: #fbbf24; font-size: 11px; font-weight: bold;';
      case 'error': return 'color: #f87171; font-size: 11px; font-weight: bold;';
    }
  }

  debug(message: string, context?: Record<string, unknown>) {
    this.addLog(this.formatMessage('debug', message, context));
  }

  info(message: string, context?: Record<string, unknown>) {
    this.addLog(this.formatMessage('info', message, context));
  }

  warn(message: string, context?: Record<string, unknown>) {
    this.addLog(this.formatMessage('warn', message, context));
  }

  error(message: string, error?: Error, context?: Record<string, unknown>) {
    this.addLog(this.formatMessage('error', message, context, error));
  }

  getLogs(level?: LogLevel): LogEntry[] {
    if (!level) return [...this.logs];
    return this.logs.filter(l => l.level === level);
  }

  clearLogs() {
    this.logs = [];
  }

  exportLogs(): string {
    return JSON.stringify(this.logs, null, 2);
  }
}

export const logger = new Logger();

export function createModuleLogger(moduleName: string) {
  return {
    debug: (message: string, context?: Record<string, unknown>) => logger.debug(`[${moduleName}] ${message}`, context),
    info: (message: string, context?: Record<string, unknown>) => logger.info(`[${moduleName}] ${message}`, context),
    warn: (message: string, context?: Record<string, unknown>) => logger.warn(`[${moduleName}] ${message}`, context),
    error: (message: string, error?: Error, context?: Record<string, unknown>) => logger.error(`[${moduleName}] ${message}`, error, context),
  };
}

if (typeof window !== 'undefined') {
  (window as any).__TRAVIX_LOGGER__ = logger;
}