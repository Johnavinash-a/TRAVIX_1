import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { logger, createModuleLogger } from '../lib/logger';

describe('Logger', () => {
  const originalConsoleLog = console.log;
  const originalConsoleWarn = console.warn;
  const originalConsoleError = console.error;

  beforeEach(() => {
    console.log = vi.fn();
    console.warn = vi.fn();
    console.error = vi.fn();
    logger.clearLogs();
  });

  afterEach(() => {
    console.log = originalConsoleLog;
    console.warn = originalConsoleWarn;
    console.error = originalConsoleError;
  });

  it('logs debug messages', () => {
    logger.debug('Debug message', { key: 'value' });
    const logs = logger.getLogs('debug');
    expect(logs).toHaveLength(1);
    expect(logs[0].message).toBe('Debug message');
    expect(logs[0].context).toEqual({ key: 'value' });
  });

  it('logs info messages', () => {
    logger.info('Info message');
    const logs = logger.getLogs('info');
    expect(logs).toHaveLength(1);
    expect(logs[0].message).toBe('Info message');
  });

  it('logs warn messages', () => {
    logger.warn('Warning message');
    const logs = logger.getLogs('warn');
    expect(logs).toHaveLength(1);
    expect(logs[0].message).toBe('Warning message');
  });

  it('logs error messages with error object', () => {
    const error = new Error('Test error');
    logger.error('Error message', error, { context: 'test' });
    const logs = logger.getLogs('error');
    expect(logs).toHaveLength(1);
    expect(logs[0].message).toBe('Error message');
    expect(logs[0].error).toBe(error);
    expect(logs[0].context).toEqual({ context: 'test' });
  });

  it('filters logs by level', () => {
    logger.debug('Debug');
    logger.info('Info');
    logger.warn('Warn');
    logger.error('Error');

    expect(logger.getLogs('debug')).toHaveLength(1);
    expect(logger.getLogs('info')).toHaveLength(1);
    expect(logger.getLogs('warn')).toHaveLength(1);
    expect(logger.getLogs('error')).toHaveLength(1);
    expect(logger.getLogs()).toHaveLength(4);
  });

  it('clears logs', () => {
    logger.info('Test');
    expect(logger.getLogs()).toHaveLength(1);
    logger.clearLogs();
    expect(logger.getLogs()).toHaveLength(0);
  });

  it('exports logs as JSON', () => {
    logger.info('Export test', { data: 123 });
    const json = logger.exportLogs();
    const parsed = JSON.parse(json);
    expect(parsed).toHaveLength(1);
    expect(parsed[0].message).toBe('Export test');
  });

  it('creates module logger with prefix', () => {
    const moduleLogger = createModuleLogger('TestModule');
    moduleLogger.info('Module message');
    const logs = logger.getLogs('info');
    expect(logs[0].message).toBe('[TestModule] Module message');
  });

  it('respects max log limit', () => {
    // The maxLogs is 1000, let's test it doesn't exceed
    for (let i = 0; i < 1005; i++) {
      logger.info(`Message ${i}`);
    }
    expect(logger.getLogs().length).toBeLessThanOrEqual(1000);
  });
});