import '@testing-library/jest-dom';
import { vi } from 'vitest';

vi.mock('framer-motion', () => ({
  motion: ({ children, ...props }) => <div {...props}>{children}</div>,
  AnimatePresence: ({ children }) => <>{children}</>,
  useReducedMotion: () => false,
}));

vi.mock('lucide-react', () => {
  const icons = [
    'MapPin', 'Clock3', 'Compass', 'Send', 'ShieldCheck', 'Sparkles', 'TrainFront',
    'Utensils', 'Bot', 'CalendarDays', 'ArrowRight', 'Bookmark', 'Share2',
    'ChevronDown', 'ChevronUp', 'Bed', 'Search', 'Navigation', 'ArrowLeft',
    'Layers', 'Plus', 'Minus', 'Maximize2', 'ExternalLink', 'Info',
    'RefreshCw', 'AlertTriangle', 'Home'
  ];
  const createIcon = (name) => ({ [name]: ({ size = 20, className = '', ...props }) => (
    <svg width={size} height={size} className={className} {...props} data-testid={`icon-${name.toLowerCase()}`} />
  ) });
  return Object.assign({}, ...icons.map(createIcon));
});

Object.defineProperty(window, 'matchMedia', {
  writable: true,
  value: vi.fn().mockImplementation(query => ({
    matches: false,
    media: query,
    onchange: null,
    addListener: vi.fn(),
    removeListener: vi.fn(),
    addEventListener: vi.fn(),
    removeEventListener: vi.fn(),
    dispatchEvent: vi.fn(),
  })),
});

Object.defineProperty(window, 'localStorage', {
  writable: true,
  value: {
    getItem: vi.fn(() => null),
    setItem: vi.fn(),
    removeItem: vi.fn(),
    clear: vi.fn(),
  },
});

HTMLCanvasElement.prototype.getContext = vi.fn(() => ({
  fillRect: vi.fn(),
  clearRect: vi.fn(),
  getImageData: vi.fn(() => ({ data: [] })),
  putImageData: vi.fn(),
  createImageData: vi.fn(() => []),
  setTransform: vi.fn(),
  drawImage: vi.fn(),
  save: vi.fn(),
  fillText: vi.fn(),
  restore: vi.fn(),
  beginPath: vi.fn(),
  moveTo: vi.fn(),
  lineTo: vi.fn(),
  closePath: vi.fn(),
  stroke: vi.fn(),
  translate: vi.fn(),
  scale: vi.fn(),
  rotate: vi.fn(),
  arc: vi.fn(),
  fill: vi.fn(),
}));