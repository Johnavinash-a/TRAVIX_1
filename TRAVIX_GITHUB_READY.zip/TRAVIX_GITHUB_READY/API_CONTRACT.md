# TRAVIX API Contract

## Overview

This document describes the REST API endpoints for the TRAVIX platform.

**Base URL**: `/api` (proxied via Vite in development, served by Express in production)

**Content-Type**: `application/json`

**Authentication**: Bearer token (JWT) for protected endpoints. Some endpoints support optional authentication.

---

## Error Response Format

All error responses follow this format:

```json
{
  "error": "Human-readable error message",
  "code": "ERROR_CODE",
  "details": {}
}
```

Common HTTP status codes:
- `200` - Success
- `201` - Created
- `400` - Bad Request
- `401` - Unauthorized
- `403` - Forbidden
- `404` - Not Found
- `409` - Conflict
- `429` - Rate Limited
- `500` - Internal Server Error
- `502` - Bad Gateway (spatial service)
- `503` - Service Unavailable

---

## Endpoints

### Health Check

#### GET `/api/health`

Returns application health status.

**Response (200/503)**:
```json
{
  "status": "ok",
  "service": "travix-api",
  "timestamp": "2024-01-15T10:30:00.000Z",
  "uptime": 3600,
  "environment": "production",
  "database": "connected",
  "spatial": "connected"
}
```

---

### Authentication

All auth endpoints are rate limited (10 req/min).

#### POST `/api/auth/register`

Register a new user.

**Request**:
```json
{
  "email": "user@example.com",
  "password": "securepassword",
  "name": "John Doe"
}
```

**Response (201)**:
```json
{
  "token": "eyJhbGciOiJIUzI1NiIs...",
  "user": {
    "id": "uuid",
    "email": "user@example.com",
    "name": "John Doe"
  }
}
```

#### POST `/api/auth/login`

Login with email and password.

**Request**:
```json
{
  "email": "user@example.com",
  "password": "securepassword"
}
```

**Response (200)**:
```json
{
  "token": "eyJhbGciOiJIUzI1NiIs...",
  "user": {
    "id": "uuid",
    "email": "user@example.com",
    "name": "John Doe"
  }
}
```

#### GET `/api/auth/me`

Get current user profile (requires authentication).

**Headers**: `Authorization: Bearer <token>`

**Response (200)**:
```json
{
  "user": {
    "id": "uuid",
    "email": "user@example.com",
    "name": "John Doe"
  }
}
```

---

### AI Chat & Recommendations

AI endpoints support optional authentication. Rate limited (20 req/min).

#### POST `/api/ai/chat`

Conversational AI travel assistant.

**Headers** (optional): `Authorization: Bearer <token>`

**Request**:
```json
{
  "message": "I want to visit Coorg with 2 people for 3 days with a budget of 15000 rupees",
  "conversationId": "conv_123",
  "userId": "user_456"
}
```

**Response (200)**:
```json
{
  "message": "I found 3 trips that fit your group and budget:\n\n1. Coorg (Kodagu)...",
  "intent": "DESTINATION_SEARCH",
  "recommendations": [
    {
      "name": "Coorg (Kodagu)",
      "location": "Karnataka, India",
      "reason": "Recommended based on your preferences...",
      "recommendationScore": 87,
      "scoreBreakdown": {
        "preference": 85,
        "budget": 90,
        "weather": 85,
        "distance": 95,
        "activity": 80,
        "accessibility": 75
      },
      "budgetEstimate": "₹18,500",
      "estimatedTravelTime": "4.5 hours drive (270 km)",
      "bestTimeToVisit": "October to March",
      "categories": ["nature", "coffee", "waterfall"],
      "places": [...],
      "mapData": {...},
      "mapAction": {...}
    }
  ],
  "groupPacingTag": "STANDARD_ACTIVE",
  "mapActions": [...],
  "followUpQuestion": null
}
```

#### POST `/api/ai/recommend`

Get destination recommendations based on context.

**Request**:
```json
{
  "location": "Bengaluru",
  "budget": 15000,
  "duration": 2,
  "travelers": [{ "age": 25 }, { "age": 26 }],
  "preferences": { "nature": 0.8, "food": 0.7 },
  "originLat": 12.9716,
  "originLon": 77.5946
}
```

**Response (200)**:
```json
{
  "status": "SUCCESS",
  "count": 3,
  "recommendations": [...]
}
```

#### GET `/api/ai/memory`

Get user's travel memory/profile.

**Query Parameters**: `userId` (optional, defaults to demo)

**Response (200)**:
```json
{
  "status": "SUCCESS",
  "memory": {
    "userId": "user_123",
    "homeCity": "Bengaluru",
    "travelerCount": 2,
    "preferences": {
      "budgetPreference": "mid-range",
      "travelStyle": ["nature", "adventure"],
      "foodPreference": ["local"],
      "preferredTripLength": 3,
      "preferredAccommodation": "homestay"
    }
  }
}
```

---

### Trips (Protected)

Requires authentication.

#### GET `/api/trips`

List user's saved trips.

**Headers**: `Authorization: Bearer <token>`

**Response (200)**:
```json
{
  "status": "SUCCESS",
  "trips": [
    {
      "id": "uuid",
      "userId": "uuid",
      "destinationName": "Coorg (Kodagu)",
      "plan": {...},
      "durationDays": 3,
      "budgetEstimate": "₹18,500",
      "metadata": {},
      "createdAt": "2024-01-15T10:30:00.000Z"
    }
  ]
}
```

#### POST `/api/trips`

Save a new trip.

**Headers**: `Authorization: Bearer <token>`

**Request**:
```json
{
  "destinationName": "Coorg (Kodagu)",
  "plan": {...},
  "durationDays": 3,
  "budgetEstimate": "₹18,500",
  "metadata": {}
}
```

**Response (201)**:
```json
{
  "status": "SUCCESS",
  "trip": {...}
}
```

---

### Weather

#### GET `/api/weather`

Get current weather and forecast for a location.

**Query Parameters**: `location` (required)

**Response (200)**:
```json
{
  "location": "Madikeri, IN",
  "temp": 18,
  "condition": "Partly Cloudy",
  "humidity": 65,
  "rainProb": 10,
  "windSpeed": "12 km/h",
  "sunrise": "06:30 AM",
  "sunset": "06:00 PM",
  "travelScore": 88,
  "travelRecommendation": "Great conditions for sightseeing and outdoor activities!",
  "hourlyForecast": [
    { "time": "09:00", "temp": 16, "condition": "Clear", "rainProb": 0 },
    { "time": "12:00", "temp": 22, "condition": "Clouds", "rainProb": 10 }
  ],
  "demo": true
}
```

---

### Spatial Service (Proxied)

All `/api/spatial/*` requests are proxied to the FastAPI spatial service.

#### GET `/api/spatial/health`

Check spatial service health.

#### GET `/api/spatial/search/places`

Search places near a location.

**Query Parameters**:
- `lat` (required): Latitude
- `lng` (required): Longitude
- `radius_km` (optional, default: 50): Search radius
- `category` (optional): Filter by category
- `limit` (optional, default: 20): Max results

#### POST `/api/spatial/route/compute`

Compute route between locations.

**Request**:
```json
{
  "origin": { "lat": 12.9716, "lng": 77.5946 },
  "destination": { "lat": 12.4200, "lng": 75.7400 },
  "waypoints": [],
  "generate_alternatives": false
}
```

---

## Rate Limits

| Endpoint Category | Limit | Window |
|-------------------|-------|--------|
| General API | 100 req/min | 60s |
| AI Chat/Recommend | 20 req/min | 60s |
| Auth (register/login) | 10 req/min | 60s |

Rate limit exceeded returns `429` with `Retry-After` header.

---

## Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `NODE_ENV` | No | `development` or `production` |
| `PORT` | No | Server port (default: 5000) |
| `JWT_SECRET` | Yes (prod) | JWT signing secret (32+ chars) |
| `CORS_ORIGINS` | No | Comma-separated allowed origins |
| `DATABASE_URL` | Yes (prod) | PostgreSQL connection string |
| `POSTGRES_USER` | No | DB user (default: postgres) |
| `POSTGRES_PASSWORD` | Yes (prod) | DB password |
| `POSTGRES_HOST` | No | DB host (default: localhost) |
| `POSTGRES_PORT` | No | DB port (default: 5432) |
| `POSTGRES_DB` | No | DB name (default: travelwise) |
| `GEMINI_API_KEY` | No | Google Gemini API key |
| `OPENWEATHER_API_KEY` | No | OpenWeatherMap API key |
| `VITE_MAPBOX_TOKEN` | No | Mapbox GL token (frontend) |
| `VITE_API_BASE` | No | API base URL (frontend) |
| `SPATIAL_SERVICE_URL` | No | FastAPI service URL (default: http://localhost:8000) |
| `OSRM_ENGINE_URL` | No | OSRM routing engine URL |

---

## Frontend-Only Variables (VITE_*)

These are exposed to the browser:

| Variable | Description |
|----------|-------------|
| `VITE_MAPBOX_TOKEN` | Mapbox access token |
| `VITE_API_BASE` | API base URL |

**Never** use `VITE_` prefix for secrets like JWT_SECRET, DATABASE_URL, or API keys.