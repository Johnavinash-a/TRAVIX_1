import { spawn } from 'child_process';
import { fileURLToPath } from 'url';
import { dirname, resolve } from 'path';

const __dirname = dirname(fileURLToPath(import.meta.url));
const projectRoot = resolve(__dirname, '..');

const vite = spawn('node', ['node_modules/vite/bin/vite.js'], {
  cwd: projectRoot,
  stdio: 'inherit',
  shell: true
});

const server = spawn('node', [resolve(__dirname, 'travixServer.js')], {
  cwd: projectRoot,
  stdio: 'inherit',
  shell: true
});

console.log('🚀 Starting TRAVIX development environment...\n');
console.log('  Frontend: http://localhost:5173');
console.log('  Backend API: http://localhost:5000');
console.log('  Proxy: /api/* -> http://localhost:5000/api/*\n');

const shutdown = () => {
  vite.kill();
  server.kill();
  process.exit(0);
};

process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
