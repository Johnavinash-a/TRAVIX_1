import { spawn } from 'child_process';
import { fileURLToPath } from 'url';
import { dirname, resolve } from 'path';
import { existsSync } from 'fs';

const __dirname = dirname(fileURLToPath(import.meta.url));
const projectRoot = resolve(__dirname, '..');
const distPath = resolve(projectRoot, 'dist');

if (!existsSync(distPath)) {
  console.error('Build output (dist/) not found. Run: npm run build first');
  process.exit(1);
}

const server = spawn('node', [resolve(__dirname, 'travixServer.js')], {
  cwd: projectRoot,
  stdio: 'inherit',
  shell: true
});

console.log('🚀 Starting TRAVIX (single-server mode)...\n');
console.log('  Backend API: http://localhost:5000');
console.log('  Frontend: http://localhost:5000 (served from dist/)\n');
console.log('  Opening browser...\n');

const openCmd = process.platform === 'win32'
  ? 'start http://localhost:5000'
  : process.platform === 'darwin'
  ? 'open http://localhost:5000'
  : 'xdg-open http://localhost:5000';

setTimeout(() => { spawn(openCmd, { shell: true, detached: true }).unref(); }, 2000);

process.on('SIGINT', () => {
  server.kill();
  process.exit(0);
});
process.on('SIGTERM', () => {
  server.kill();
  process.exit(0);
});
