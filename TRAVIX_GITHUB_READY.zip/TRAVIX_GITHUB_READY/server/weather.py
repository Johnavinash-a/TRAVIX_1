

import os
import math
import logging
from typing import List, Optional, Dict, Any
from contextlib import asynccontextmanager

import uvicorn
from fastapi import FastAPI, Query, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field, field_validator
import httpx

# Configure Logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s")
logger = logging.getLogger("travelwise_spatial")

# Environment Configurations
POSTGRES_USER = os.getenv("POSTGRES_USER", "postgres")
POSTGRES_PASSWORD = os.getenv("POSTGRES_PASSWORD", "postgres")
POSTGRES_HOST = os.getenv("POSTGRES_HOST", "localhost")
POSTGRES_PORT = os.getenv("POSTGRES_PORT", "5432")
POSTGRES_DB = os.getenv("POSTGRES_DB", "travelwise")
DATABASE_URL = os.getenv(
    "DATABASE_URL",
    f"postgresql://{POSTGRES_USER}:{POSTGRES_PASSWORD}@{POSTGRES_HOST}:{POSTGRES_PORT}/{POSTGRES_DB}"
)
OSRM_ENGINE_URL = os.getenv("OSRM_ENGINE_URL", "http://router.project-osrm.org")

# Embedded PostGIS SQL Setup Script (Executed if PostGIS database is attached)
POSTGIS_SETUP_SQL = """
CREATE EXTENSION IF NOT EXISTS postgis;
CREATE EXTENSION IF NOT EXISTS pg_trgm;

CREATE TABLE IF NOT EXISTS places (
    id VARCHAR(64) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    category VARCHAR(100) NOT NULL,
    description TEXT,
    address TEXT,
    city VARCHAR(100) NOT NULL,
    state VARCHAR(100) NOT NULL,
    rating NUMERIC(3, 2) NOT NULL DEFAULT 4.0,
    popularity_score NUMERIC(5, 2) NOT NULL DEFAULT 50.0,
    location GEOMETRY(Point, 4326) NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_places_location_gist ON places USING GIST (location);
"""

# Global AsyncPG connection pool
db_pool = None

@asynccontextmanager
async def lifespan(app: FastAPI):
    global db_pool
    logger.info("Initializing Spatial Microservice Resources...")
    try:
        import asyncpg
        db_pool = await asyncpg.create_pool(DATABASE_URL, min_size=1, max_size=10, timeout=3.0)
        logger.info("PostGIS AsyncPG Connection Pool Established Successfully.")
        async with db_pool.acquire() as conn:
            await conn.execute(POSTGIS_SETUP_SQL)
    except Exception as e:
        logger.warning(f"PostGIS DB Pool unavailable ({e}). Fallback spatial calculation active.")
        db_pool = None
    yield
    if db_pool:
        await db_pool.close()
        logger.info("PostGIS Connection Pool Closed.")

app = FastAPI(
    title="TravelWise AI — VS Code Standalone Geospatial Microservice",
    description="Single-file FastAPI microservice executing PostGIS spatial search, composite ranking math, and OSRM routing.",
    version="1.0.0",
    lifespan=lifespan
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ============================================================================
# PYDANTIC V2 SCHEMAS
# ============================================================================

class Coordinates(BaseModel):
    lat: float = Field(..., ge=-90.0, le=90.0, description="Latitude")
    lng: float = Field(..., ge=-180.0, le=180.0, description="Longitude")

class PlaceResult(BaseModel):
    id: str
    name: str
    category: str
    description: Optional[str] = None
    address: Optional[str] = None
    city: str
    state: str
    rating: float
    popularity_score: float
    distance_km: float
    text_match_score: float
    composite_rank_score: float
    coordinates: Coordinates

class PlaceSearchResponse(BaseModel):
    query: Optional[str] = None
    category: Optional[str] = None
    center: Coordinates
    radius_km: float
    count: int
    results: List[PlaceResult]

class RouteComputeRequest(BaseModel):
    origin: Coordinates
    destination: Coordinates
    waypoints: Optional[List[Coordinates]] = Field(default_factory=list)
    generate_alternatives: bool = Field(default=False)

    @field_validator('waypoints')
    def check_waypoints_limit(cls, v):
        if v and len(v) > 25:
            raise ValueError("Maximum 25 intermediate waypoints permitted per request.")
        return v

class RouteLeg(BaseModel):
    leg_number: int
    start_location: Coordinates
    end_location: Coordinates
    distance_meters: float
    distance_km: float
    duration_seconds: float
    duration_minutes: float

class RouteOption(BaseModel):
    route_name: str
    is_primary: bool
    total_distance_meters: float
    total_distance_km: float
    total_duration_seconds: float
    total_duration_minutes: float
    geojson_polyline: Dict[str, Any]
    legs: List[RouteLeg]

class RouteComputeResponse(BaseModel):
    status: str
    primary_route: RouteOption
    alternative_routes: List[RouteOption] = []
    engine_used: str

# ============================================================================
# GEOSPATIAL MATH & FALLBACK DATASET
# ============================================================================

def haversine_distance_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    r = 6371.0 # Earth radius in km
    dlat = math.radians(lat2 - lat1)
    dlon = math.radians(lon2 - lon1)
    a = math.sin(dlat / 2)**2 + math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) * math.sin(dlon / 2)**2
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    return round(r * c, 3)

def compute_composite_score(text_match: float, distance_km: float, rating: float, popularity: float) -> float:
    """
    Score = (TextMatch * 0.35) + (1 / (1 + Distance_in_km) * 0.35) + (Rating/5.0 * 0.15) + (Popularity/100.0 * 0.15)
    """
    spatial_decay = 1.0 / (1.0 + distance_km)
    normalized_rating = max(0.0, min(5.0, rating)) / 5.0
    normalized_popularity = max(0.0, min(100.0, popularity)) / 100.0
    score = (text_match * 0.35) + (spatial_decay * 0.35) + (normalized_rating * 0.15) + (normalized_popularity * 0.15)
    return round(score, 4)

SAMPLE_PLACES_DATA = [
    {
        "id": "plc_abbey_falls", "name": "Abbey Falls", "category": "Attraction",
        "description": "Cascading waterfall in coffee estate.", "address": "Madikeri, Coorg",
        "city": "Madikeri", "state": "Karnataka", "rating": 4.7, "popularity_score": 88.5,
        "lat": 12.4578, "lng": 75.7197
    },
    {
        "id": "plc_raja_seat", "name": "Raja Seat Viewpoint", "category": "Attraction",
        "description": "Historic sunset garden viewpoint.", "address": "Madikeri Town",
        "city": "Madikeri", "state": "Karnataka", "rating": 4.8, "popularity_score": 92.0,
        "lat": 12.4184, "lng": 75.7369
    },
    {
        "id": "plc_mullayanagiri", "name": "Mullayanagiri Peak", "category": "Attraction",
        "description": "Highest mountain peak in Karnataka.", "address": "Chikmagalur Pass",
        "city": "Chikmagalur", "state": "Karnataka", "rating": 4.9, "popularity_score": 95.0,
        "lat": 13.3912, "lng": 75.7214
    },
    {
        "id": "plc_tata_ev_bidadi", "name": "Tata Power 60kW EV Fast Charger", "category": "EV_Charging",
        "description": "Dual CCS2 60kW DC fast charger.", "address": "Bidadi Toll Plaza",
        "city": "Ramanagara", "state": "Karnataka", "rating": 4.6, "popularity_score": 85.0,
        "lat": 12.7981, "lng": 77.3821
    },
    {
        "id": "plc_mylari_dosa", "name": "Original Hotel Vinayaka Mylari", "category": "Restaurant",
        "description": "Legendary breakfast hotel for butter dosas.", "address": "Nazarbad, Mysuru",
        "city": "Mysuru", "state": "Karnataka", "rating": 4.9, "popularity_score": 98.0,
        "lat": 12.3052, "lng": 76.6552
    }
]

# ============================================================================
# ENDPOINT 1: PLACE SEARCHING & RANKING
# ============================================================================

@app.get("/search/places", response_model=PlaceSearchResponse, tags=["Spatial Search"])
async def search_places(
    latitude: float = Query(..., ge=-90.0, le=90.0),
    longitude: float = Query(..., ge=-180.0, le=180.0),
    query: Optional[str] = Query(None),
    category: Optional[str] = Query(None),
    radius_km: float = Query(10.0, gt=0.0, le=500.0)
):
    results: List[PlaceResult] = []

    if db_pool:
        try:
            async with db_pool.acquire() as conn:
                sql = """
                    SELECT id, name, category, description, address, city, state, rating, popularity_score,
                           ST_Y(location::geometry) as lat, ST_X(location::geometry) as lng,
                           (ST_DistanceSphere(location, ST_SetSRID(ST_MakePoint($1, $2), 4326)) / 1000.0) as distance_km
                    FROM places
                    WHERE ST_DWithin(location::geography, ST_SetSRID(ST_MakePoint($1, $2), 4326)::geography, $3 * 1000.0)
                    AND ($4::text IS NULL OR category ILIKE $4::text)
                    ORDER BY distance_km ASC;
                """
                rows = await conn.fetch(sql, longitude, latitude, radius_km, category)
                for row in rows:
                    dist_km = round(float(row['distance_km']), 3)
                    text_score = 1.0 if not query else (0.9 if query.lower() in row['name'].lower() else 0.3)
                    rating = float(row['rating'])
                    pop = float(row['popularity_score'])
                    score = compute_composite_score(text_score, dist_km, rating, pop)
                    results.append(PlaceResult(
                        id=row['id'], name=row['name'], category=row['category'],
                        description=row['description'], address=row['address'], city=row['city'], state=row['state'],
                        rating=rating, popularity_score=pop, distance_km=dist_km, text_match_score=text_score,
                        composite_rank_score=score, coordinates=Coordinates(lat=float(row['lat']), lng=float(row['lng']))
                    ))
        except Exception as e:
            logger.warning(f"PostGIS DB query fallback ({e})")

    if not results:
        for p in SAMPLE_PLACES_DATA:
            dist_km = haversine_distance_km(latitude, longitude, p['lat'], p['lng'])
            if dist_km <= radius_km:
                if category and category.lower() not in p['category'].lower():
                    continue
                text_score = 1.0 if not query else (0.9 if query.lower() in p['name'].lower() or query.lower() in p['category'].lower() else 0.3)
                score = compute_composite_score(text_score, dist_km, p['rating'], p['popularity_score'])
                results.append(PlaceResult(
                    id=p['id'], name=p['name'], category=p['category'],
                    description=p['description'], address=p['address'], city=p['city'], state=p['state'],
                    rating=p['rating'], popularity_score=p['popularity_score'], distance_km=dist_km,
                    text_match_score=text_score, composite_rank_score=score,
                    coordinates=Coordinates(lat=p['lat'], lng=p['lng'])
                ))

    results.sort(key=lambda x: x.composite_rank_score, reverse=True)
    return PlaceSearchResponse(
        query=query, category=category, center=Coordinates(lat=latitude, lng=longitude),
        radius_km=radius_km, count=len(results), results=results
    )

# ============================================================================
# ENDPOINT 2: ROUTE COMPUTATION & ALTERNATIVES
# ============================================================================

@app.post("/route/compute", response_model=RouteComputeResponse, tags=["Routing Engine"])
async def compute_route(body: RouteComputeRequest):
    all_points: List[Coordinates] = [body.origin]
    if body.waypoints:
        all_points.extend(body.waypoints)
    all_points.append(body.destination)

    coords_str = ";".join([f"{pt.lng},{pt.lat}" for pt in all_points])
    osrm_url = f"{OSRM_ENGINE_URL}/route/v1/driving/{coords_str}"
    params = {
        "overview": "full", "geometries": "geojson", "steps": "true",
        "alternatives": "true" if body.generate_alternatives else "false"
    }

    async with httpx.AsyncClient(timeout=8.0) as client:
        try:
            res = await client.get(osrm_url, params=params)
            if res.status_code == 200:
                data = res.json()
                if data.get("code") == "Ok" and data.get("routes"):
                    primary_osrm = data["routes"][0]
                    primary_legs = []
                    for idx, leg in enumerate(primary_osrm.get("legs", [])):
                        dist_m = float(leg.get("distance", 0.0))
                        dur_s = float(leg.get("duration", 0.0))
                        primary_legs.append(RouteLeg(
                            leg_number=idx + 1, start_location=all_points[idx], end_location=all_points[idx + 1],
                            distance_meters=dist_m, distance_km=round(dist_m / 1000.0, 2),
                            duration_seconds=dur_s, duration_minutes=round(dur_s / 60.0, 1)
                        ))
                    
                    dist_m = float(primary_osrm.get("distance", 0.0))
                    dur_s = float(primary_osrm.get("duration", 0.0))
                    primary_route = RouteOption(
                        route_name="Primary Optimal Corridor", is_primary=True,
                        total_distance_meters=dist_m, total_distance_km=round(dist_m / 1000.0, 2),
                        total_duration_seconds=dur_s, total_duration_minutes=round(dur_s / 60.0, 1),
                        geojson_polyline=primary_osrm.get("geometry", {}), legs=primary_legs
                    )
                    return RouteComputeResponse(
                        status="SUCCESS", primary_route=primary_route, alternative_routes=[], engine_used="OSRM Async Engine"
                    )
        except Exception as e:
            logger.warning(f"OSRM fallback active ({e})")

    # Geodesic Fallback Routing
    legs = []
    total_dist_km = 0.0
    coords_list = []

    for i in range(len(all_points) - 1):
        pa, pb = all_points[i], all_points[i + 1]
        coords_list.append([pa.lng, pa.lat])
        d_km = haversine_distance_km(pa.lat, pa.lng, pb.lat, pb.lng) * 1.25
        d_m = d_km * 1000.0
        d_s = (d_km / 50.0) * 3600.0
        total_dist_km += d_km
        legs.append(RouteLeg(
            leg_number=i + 1, start_location=pa, end_location=pb,
            distance_meters=round(d_m, 1), distance_km=round(d_km, 2),
            duration_seconds=round(d_s, 1), duration_minutes=round(d_s / 60.0, 1)
        ))

    coords_list.append([all_points[-1].lng, all_points[-1].lat])
    total_dist_m = total_dist_km * 1000.0
    total_dur_s = (total_dist_km / 50.0) * 3600.0

    primary_route = RouteOption(
        route_name="Primary Scenic Corridor", is_primary=True,
        total_distance_meters=round(total_dist_m, 1), total_distance_km=round(total_dist_km, 2),
        total_duration_seconds=round(total_dur_s, 1), total_duration_minutes=round(total_dur_s / 60.0, 1),
        geojson_polyline={"type": "LineString", "coordinates": coords_list}, legs=legs
    )

    return RouteComputeResponse(
        status="SUCCESS", primary_route=primary_route, alternative_routes=[], engine_used="TravelWise Geodesic Engine"
    )

@app.get("/health")
async def health():
    return {"status": "healthy", "service": "VS Code Single File Spatial Microservice"}

