-- 001_destinations.sql
-- Seed data for destinations (India/South India focused for TRAVIX)

INSERT INTO destinations (id, name, state, category, budget_per_day_inr, tags, latitude, longitude, best_time_to_visit) VALUES
('coorg', 'Coorg (Kodagu)', 'Karnataka', 'Hill Station', 3500, ARRAY['nature', 'coffee', 'waterfall', 'photography', 'local_food'], 12.4200, 75.7400, 'October to March'),
('chikmagalur', 'Chikmagalur', 'Karnataka', 'Hill Station', 3200, ARRAY['nature', 'coffee', 'trekking', 'photography'], 13.3161, 75.7720, 'September to May'),
('wayanad', 'Wayanad', 'Kerala', 'Nature & Wildlife', 3800, ARRAY['nature', 'waterfalls', 'wildlife', 'local_food'], 11.6854, 76.1320, 'October to May'),
('munnar', 'Munnar', 'Kerala', 'Tea Gardens & Valleys', 4200, ARRAY['tea', 'valleys', 'cool', 'scenic', 'nature'], 10.0889, 77.0595, 'September to May'),
('mysore', 'Mysuru (Mysore)', 'Karnataka', 'Royal Palaces & Cultural Heritage', 3000, ARRAY['palace', 'heritage', 'history', 'silk', 'food'], 12.3052, 76.6552, 'All Year'),
('ooty', 'Ooty (Udhagamandalam)', 'Tamil Nadu', 'Hill Station', 3600, ARRAY['tea', 'botanical', 'cool', 'toy_train', 'scenic'], 11.4064, 76.6932, 'April to June, September to November'),
('kodaikanal', 'Kodaikanal', 'Tamil Nadu', 'Hill Station', 3400, ARRAY['lake', 'waterfalls', 'cool', 'trekking', 'scenic'], 10.2381, 77.4892, 'April to June, September to October'),
('alleppey', 'Alleppey (Alappuzha)', 'Kerala', 'Backwaters & Houseboats', 4000, ARRAY['backwaters', 'houseboat', 'canals', 'local_food', 'relaxation'], 9.4981, 76.3388, 'November to February'),
('kovalam', 'Kovalam', 'Kerala', 'Beach & Ayurveda', 4500, ARRAY['beach', 'ayurveda', 'yoga', 'sunset', 'seafood'], 8.4004, 76.9790, 'September to March'),
('hampi', 'Hampi', 'Karnataka', 'UNESCO Heritage & Ruins', 2800, ARRAY['heritage', 'ruins', 'bouldering', 'history', 'photography'], 15.3350, 76.4600, 'October to February'),
('gokarna', 'Gokarna', 'Karnataka', 'Beach & Temples', 2500, ARRAY['beach', 'temples', 'relaxation', 'trekking', 'spiritual'], 14.5463, 74.3172, 'October to March'),
('varkala', 'Varkala', 'Kerala', 'Cliff Beach & Spiritual', 3500, ARRAY['cliff', 'beach', 'ayurveda', 'temples', 'sunset'], 8.7371, 76.7163, 'October to March')
ON CONFLICT (id) DO UPDATE SET
    name = EXCLUDED.name,
    state = EXCLUDED.state,
    category = EXCLUDED.category,
    budget_per_day_inr = EXCLUDED.budget_per_day_inr,
    tags = EXCLUDED.tags,
    latitude = EXCLUDED.latitude,
    longitude = EXCLUDED.longitude,
    best_time_to_visit = EXCLUDED.best_time_to_visit;