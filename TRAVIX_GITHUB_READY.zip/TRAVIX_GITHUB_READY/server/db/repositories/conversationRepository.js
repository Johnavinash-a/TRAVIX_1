import { query } from '../pool.js';

export async function createConversation({ id, userId, state = {} }) {
  const result = await query(
    `INSERT INTO ai_conversations (id, user_id, state, created_at, updated_at)
     VALUES ($1, $2, $3, NOW(), NOW())
     RETURNING *`,
    [id, userId, JSON.stringify(state)]
  );
  return result.rows[0];
}

export async function findConversationById(id) {
  const result = await query(
    `SELECT * FROM ai_conversations WHERE id = $1`,
    [id]
  );
  return result.rows[0] || null;
}

export async function findConversationsByUserId(userId, limit = 20) {
  const result = await query(
    `SELECT * FROM ai_conversations WHERE user_id = $1 ORDER BY updated_at DESC LIMIT $2`,
    [userId, limit]
  );
  return result.rows;
}

export async function updateConversationState(id, state) {
  const result = await query(
    `UPDATE ai_conversations SET state = $1, updated_at = NOW() WHERE id = $2 RETURNING *`,
    [JSON.stringify(state), id]
  );
  return result.rows[0] || null;
}

export async function deleteConversation(id) {
  await query(`DELETE FROM ai_conversations WHERE id = $1`, [id]);
}