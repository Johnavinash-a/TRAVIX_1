import { query } from '../pool.js';

export async function createPlace({ id, name, category, description, address, city, state, rating, popularityScore, latitude, longitude }) {
  const result = await query(
    `INSERT INTO places (id, name, category, description, address, city, state, rating, popularity_score, location, created_at)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, ST_SetSRID(ST_MakePoint($10, $11), 4326), NOW())
     ON CONFLICT (id) DO UPDATE SET
       name = EXCLUDED.name,
       category = EXCLUDED.category,
       description = EXCLUDED.description,
       address = EXCLUDED.address,
       city = EXCLUDED.city,
       state = EXCLUDED.state,
       rating = EXCLUDED.rating,
       popularity_score = EXCLUDED.popularity_score,
       location = EXCLUDED.location
     RETURNING *`,
    [id, name, category, description, address, city, state, rating, popularityScore, longitude, latitude]
  );
  return result.rows[0];
}

export async function findPlaceById(id) {
  const result = await query(
    `SELECT *, ST_X(location) as lng, ST_Y(location) as lat FROM places WHERE id = $1`,
    [id]
  );
  return result.rows[0] || null;
}

export async function findPlacesNearby(lat, lng, radiusKm = 50, category = null, limit = 20) {
  let sql = `
    SELECT *, ST_X(location) as lng, ST_Y(location) as lat,
           ST_Distance(location, ST_SetSRID(ST_MakePoint($1, $2), 4326)::geography) / 1000 as distance_km
    FROM places
    WHERE ST_DWithin(location, ST_SetSRID(ST_MakePoint($1, $2), 4326)::geography, $3 * 1000)
  `;
  const params = [lng, lat, radiusKm * 1000];

  if (category) {
    sql += ` AND category = $${params.length + 1}`;
    params.push(category);
  }

  sql += ` ORDER BY distance_km ASC LIMIT $${params.length + 1}`;
  params.push(limit);

  const result = await query(sql, params);
  return result.rows;
}

export async function findPlacesByCategory(category, limit = 50) {
  const result = await query(
    `SELECT *, ST_X(location) as lng, ST_Y(location) as lat FROM places WHERE category = $1 ORDER BY popularity_score DESC LIMIT $2`,
    [category, limit]
  );
  return result.rows;
}