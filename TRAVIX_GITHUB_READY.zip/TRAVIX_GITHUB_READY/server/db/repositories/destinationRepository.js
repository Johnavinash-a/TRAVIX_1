import { query } from '../pool.js';

export async function createDestination({ id, name, state, category, budgetPerDayINR, tags, latitude, longitude, bestTimeToVisit }) {
  const result = await query(
    `INSERT INTO destinations (id, name, state, category, budget_per_day_inr, tags, latitude, longitude, best_time_to_visit, created_at)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, NOW())
     ON CONFLICT (id) DO UPDATE SET
       name = EXCLUDED.name,
       state = EXCLUDED.state,
       category = EXCLUDED.category,
       budget_per_day_inr = EXCLUDED.budget_per_day_inr,
       tags = EXCLUDED.tags,
       latitude = EXCLUDED.latitude,
       longitude = EXCLUDED.longitude,
       best_time_to_visit = EXCLUDED.best_time_to_visit
     RETURNING *`,
    [id, name, state, category, budgetPerDayINR, tags, latitude, longitude, bestTimeToVisit]
  );
  return result.rows[0];
}

export async function findDestinationById(id) {
  const result = await query(`SELECT * FROM destinations WHERE id = $1`, [id]);
  return result.rows[0] || null;
}

export async function findAllDestinations() {
  const result = await query(`SELECT * FROM destinations ORDER BY name`);
  return result.rows;
}

export async function findDestinationsByTags(tags) {
  const result = await query(
    `SELECT * FROM destinations WHERE tags && $1 ORDER BY name`,
    [tags]
  );
  return result.rows;
}