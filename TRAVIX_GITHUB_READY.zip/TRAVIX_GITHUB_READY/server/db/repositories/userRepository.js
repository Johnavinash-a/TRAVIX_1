import { query } from '../pool.js';

export async function createUser({ email, passwordHash, name }) {
  const result = await query(
    `INSERT INTO users (email, password_hash, name, created_at)
     VALUES ($1, $2, $3, NOW())
     RETURNING id, email, name, created_at`,
    [email, passwordHash, name]
  );
  return result.rows[0];
}

export async function findUserByEmail(email) {
  const result = await query(
    `SELECT id, email, password_hash, name, created_at FROM users WHERE email = $1`,
    [email]
  );
  return result.rows[0] || null;
}

export async function findUserById(id) {
  const result = await query(
    `SELECT id, email, name, created_at FROM users WHERE id = $1`,
    [id]
  );
  return result.rows[0] || null;
}

export async function updateUserProfile(userId, { name, city, travelerCount }) {
  const fields = [];
  const values = [];
  let paramIndex = 1;

  if (name !== undefined) {
    fields.push(`name = $${paramIndex++}`);
    values.push(name);
  }
  if (city !== undefined) {
    fields.push(`city = $${paramIndex++}`);
    values.push(city);
  }
  if (travelerCount !== undefined) {
    fields.push(`traveler_count = $${paramIndex++}`);
    values.push(travelerCount);
  }

  if (fields.length === 0) return null;

  fields.push(`updated_at = NOW()`);
  values.push(userId);

  const result = await query(
    `UPDATE users SET ${fields.join(', ')} WHERE id = $${paramIndex} RETURNING id, email, name, city, traveler_count, updated_at`,
    values
  );
  return result.rows[0] || null;
}

export async function getUserProfile(userId) {
  const result = await query(
    `SELECT id, email, name, city, traveler_count, created_at FROM users WHERE id = $1`,
    [userId]
  );
  return result.rows[0] || null;
}