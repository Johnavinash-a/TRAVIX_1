import { query } from '../pool.js';

export async function createMessage({ id, conversationId, sender, text, timestamp, metadata = {} }) {
  const result = await query(
    `INSERT INTO ai_messages (id, conversation_id, sender, text, timestamp, metadata, created_at)
     VALUES ($1, $2, $3, $4, $5, $6, NOW())
     RETURNING *`,
    [id, conversationId, sender, text, timestamp, JSON.stringify(metadata)]
  );
  return result.rows[0];
}

export async function findMessagesByConversationId(conversationId, limit = 100) {
  const result = await query(
    `SELECT * FROM ai_messages WHERE conversation_id = $1 ORDER BY created_at ASC LIMIT $2`,
    [conversationId, limit]
  );
  return result.rows;
}

export async function findRecentMessagesByUserId(userId, limit = 50) {
  const result = await query(
    `SELECT m.* FROM ai_messages m
     JOIN ai_conversations c ON m.conversation_id = c.id
     WHERE c.user_id = $1
     ORDER BY m.created_at DESC LIMIT $2`,
    [userId, limit]
  );
  return result.rows;
}