import { query } from '../pool.js';

export async function createSavedPlace({ userId, placeId, notes = '' }) {
  const result = await query(
    `INSERT INTO saved_places (user_id, place_id, notes, created_at)
     VALUES ($1, $2, $3, NOW())
     ON CONFLICT (user_id, place_id) DO UPDATE SET
       notes = EXCLUDED.notes
     RETURNING *`,
    [userId, placeId, notes]
  );
  return result.rows[0];
}

export async function findSavedPlacesByUserId(userId) {
  const result = await query(
    `SELECT sp.*, p.name, p.category, p.description, p.city, p.state, p.rating, p.popularity_score,
            ST_X(p.location) as lng, ST_Y(p.location) as lat
     FROM saved_places sp
     JOIN places p ON sp.place_id = p.id
     WHERE sp.user_id = $1
     ORDER BY sp.created_at DESC`,
    [userId]
  );
  return result.rows;
}

export async function deleteSavedPlace(userId, placeId) {
  await query(`DELETE FROM saved_places WHERE user_id = $1 AND place_id = $2`, [userId, placeId]);
}

export async function isPlaceSaved(userId, placeId) {
  const result = await query(
    `SELECT 1 FROM saved_places WHERE user_id = $1 AND place_id = $2`,
    [userId, placeId]
  );
  return result.rows.length > 0;
}