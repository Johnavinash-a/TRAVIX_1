import { query } from '../pool.js';

export async function createTrip({ userId, destinationName, plan, durationDays, budgetEstimate, metadata = {} }) {
  const result = await query(
    `INSERT INTO trips (user_id, destination_name, plan, duration_days, budget_estimate, metadata, created_at, updated_at)
     VALUES ($1, $2, $3, $4, $5, $6, NOW(), NOW())
     RETURNING *`,
    [userId, destinationName, JSON.stringify(plan), durationDays, budgetEstimate, JSON.stringify(metadata)]
  );
  return result.rows[0];
}

export async function findTripById(id) {
  const result = await query(`SELECT * FROM trips WHERE id = $1`, [id]);
  return result.rows[0] || null;
}

export async function findTripsByUserId(userId, limit = 20) {
  const result = await query(
    `SELECT * FROM trips WHERE user_id = $1 ORDER BY created_at DESC LIMIT $2`,
    [userId, limit]
  );
  return result.rows;
}

export async function updateTrip(id, updates) {
  const fields = [];
  const values = [];
  let paramIndex = 1;

  if (updates.plan !== undefined) {
    fields.push(`plan = $${paramIndex++}`);
    values.push(JSON.stringify(updates.plan));
  }
  if (updates.destinationName !== undefined) {
    fields.push(`destination_name = $${paramIndex++}`);
    values.push(updates.destinationName);
  }
  if (updates.durationDays !== undefined) {
    fields.push(`duration_days = $${paramIndex++}`);
    values.push(updates.durationDays);
  }
  if (updates.budgetEstimate !== undefined) {
    fields.push(`budget_estimate = $${paramIndex++}`);
    values.push(updates.budgetEstimate);
  }
  if (updates.metadata !== undefined) {
    fields.push(`metadata = $${paramIndex++}`);
    values.push(JSON.stringify(updates.metadata));
  }

  if (fields.length === 0) return null;

  fields.push(`updated_at = NOW()`);
  values.push(id);

  const result = await query(
    `UPDATE trips SET ${fields.join(', ')} WHERE id = $${paramIndex} RETURNING *`,
    values
  );
  return result.rows[0] || null;
}

export async function deleteTrip(id) {
  await query(`DELETE FROM trips WHERE id = $1`, [id]);
}