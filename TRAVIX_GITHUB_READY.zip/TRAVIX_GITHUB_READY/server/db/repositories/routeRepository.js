import { query } from '../pool.js';

export async function createRoute({ id, userId, name, origin, destination, waypoints, distanceKm, durationMinutes, geojsonPolyline, metadata = {} }) {
  const result = await query(
    `INSERT INTO routes (id, user_id, name, origin, destination, waypoints, distance_km, duration_minutes, geojson_polyline, metadata, created_at)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, NOW())
     RETURNING *`,
    [id, userId, name, JSON.stringify(origin), JSON.stringify(destination), JSON.stringify(waypoints), distanceKm, durationMinutes, JSON.stringify(geojsonPolyline), JSON.stringify(metadata)]
  );
  return result.rows[0];
}

export async function findRouteById(id) {
  const result = await query(`SELECT * FROM routes WHERE id = $1`, [id]);
  return result.rows[0] || null;
}

export async function findRoutesByUserId(userId, limit = 20) {
  const result = await query(
    `SELECT * FROM routes WHERE user_id = $1 ORDER BY created_at DESC LIMIT $2`,
    [userId, limit]
  );
  return result.rows;
}

export async function findWaypointsByRouteId(routeId) {
  const result = await query(
    `SELECT * FROM route_waypoints WHERE route_id = $1 ORDER BY sequence ASC`,
    [routeId]
  );
  return result.rows;
}

export async function createRouteWaypoints(routeId, waypoints) {
  const client = await import('../pool.js').then(m => m.getClient());
  try {
    await client.query('BEGIN');
    await client.query(`DELETE FROM route_waypoints WHERE route_id = $1`, [routeId]);
    for (let i = 0; i < waypoints.length; i++) {
      const wp = waypoints[i];
      await client.query(
        `INSERT INTO route_waypoints (route_id, sequence, name, lat, lng, metadata, created_at)
         VALUES ($1, $2, $3, $4, $5, $6, NOW())`,
        [routeId, i, wp.name, wp.lat, wp.lng, JSON.stringify(wp.metadata || {})]
      );
    }
    await client.query('COMMIT');
    return true;
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
}