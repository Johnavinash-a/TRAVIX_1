import { query } from '../pool.js';

export async function createRecommendation({ userId, destinationId, scores, context = {} }) {
  const result = await query(
    `INSERT INTO recommendations (user_id, destination_id, preference_score, budget_score, weather_score, distance_score, activity_score, accessibility_score, final_score, context, created_at)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, NOW())
     RETURNING *`,
    [userId, destinationId, scores.preference, scores.budget, scores.weather, scores.distance, scores.activity, scores.accessibility, scores.final, JSON.stringify(context)]
  );
  return result.rows[0];
}

export async function findRecommendationsByUserId(userId, limit = 10) {
  const result = await query(
    `SELECT r.*, d.name, d.state, d.category, d.latitude, d.longitude, d.best_time_to_visit
     FROM recommendations r
     JOIN destinations d ON r.destination_id = d.id
     WHERE r.user_id = $1
     ORDER BY r.final_score DESC, r.created_at DESC
     LIMIT $2`,
    [userId, limit]
  );
  return result.rows;
}

export async function findLatestRecommendationByUserId(userId) {
  const result = await query(
    `SELECT r.*, d.name, d.state, d.category, d.latitude, d.longitude, d.best_time_to_visit
     FROM recommendations r
     JOIN destinations d ON r.destination_id = d.id
     WHERE r.user_id = $1
     ORDER BY r.created_at DESC
     LIMIT 1`,
    [userId]
  );
  return result.rows[0] || null;
}