import { query } from '../pool.js';

export async function logUserTravelEvent({ userId, eventType, eventData = {}, metadata = {} }) {
  const result = await query(
    `INSERT INTO user_travel_events (user_id, event_type, event_data, metadata, created_at)
     VALUES ($1, $2, $3, $4, NOW())
     RETURNING *`,
    [userId, eventType, JSON.stringify(eventData), JSON.stringify(metadata)]
  );
  return result.rows[0];
}

export async function findTravelEventsByUserId(userId, limit = 50) {
  const result = await query(
    `SELECT * FROM user_travel_events WHERE user_id = $1 ORDER BY created_at DESC LIMIT $2`,
    [userId, limit]
  );
  return result.rows;
}

export async function findTravelEventsByType(eventType, limit = 100) {
  const result = await query(
    `SELECT * FROM user_travel_events WHERE event_type = $1 ORDER BY created_at DESC LIMIT $2`,
    [eventType, limit]
  );
  return result.rows;
}