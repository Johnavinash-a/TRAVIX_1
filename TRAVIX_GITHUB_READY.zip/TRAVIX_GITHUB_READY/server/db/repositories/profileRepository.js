import { query } from '../pool.js';

export async function createProfile({ userId, city, travelerCount, preferences }) {
  const result = await query(
    `INSERT INTO user_profiles (user_id, city, traveler_count, preferences, created_at, updated_at)
     VALUES ($1, $2, $3, $4, NOW(), NOW())
     ON CONFLICT (user_id) DO UPDATE SET
       city = EXCLUDED.city,
       traveler_count = EXCLUDED.traveler_count,
       preferences = EXCLUDED.preferences,
       updated_at = NOW()
     RETURNING *`,
    [userId, city, travelerCount, JSON.stringify(preferences || {})]
  );
  return result.rows[0];
}

export async function findProfileByUserId(userId) {
  const result = await query(
    `SELECT * FROM user_profiles WHERE user_id = $1`,
    [userId]
  );
  return result.rows[0] || null;
}

export async function updateProfile(userId, updates) {
  const fields = [];
  const values = [];
  let paramIndex = 1;

  if (updates.city !== undefined) {
    fields.push(`city = $${paramIndex++}`);
    values.push(updates.city);
  }
  if (updates.travelerCount !== undefined) {
    fields.push(`traveler_count = $${paramIndex++}`);
    values.push(updates.travelerCount);
  }
  if (updates.preferences !== undefined) {
    fields.push(`preferences = $${paramIndex++}`);
    values.push(JSON.stringify(updates.preferences));
  }

  if (fields.length === 0) return null;

  fields.push(`updated_at = NOW()`);
  values.push(userId);

  const result = await query(
    `UPDATE user_profiles SET ${fields.join(', ')} WHERE user_id = $${paramIndex} RETURNING *`,
    values
  );
  return result.rows[0] || null;
}