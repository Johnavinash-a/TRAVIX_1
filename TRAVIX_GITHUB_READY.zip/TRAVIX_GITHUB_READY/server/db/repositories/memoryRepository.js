import { query } from '../pool.js';

export async function upsertUserTravelMemory({ userId, budgetPreference, travelStyle, foodPreference, preferredTripLength, preferredAccommodation, homeCity, travelerCount, lastUpdated = new Date() }) {
  const result = await query(
    `INSERT INTO user_ai_memory (user_id, budget_preference, travel_style, food_preference, preferred_trip_length, preferred_accommodation, home_city, traveler_count, updated_at)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
     ON CONFLICT (user_id) DO UPDATE SET
       budget_preference = EXCLUDED.budget_preference,
       travel_style = EXCLUDED.travel_style,
       food_preference = EXCLUDED.food_preference,
       preferred_trip_length = EXCLUDED.preferred_trip_length,
       preferred_accommodation = EXCLUDED.preferred_accommodation,
       home_city = EXCLUDED.home_city,
       traveler_count = EXCLUDED.traveler_count,
       updated_at = EXCLUDED.updated_at
     RETURNING *`,
    [userId, budgetPreference, travelStyle, foodPreference, preferredTripLength, preferredAccommodation, homeCity, travelerCount, lastUpdated]
  );
  return result.rows[0];
}

export async function findUserTravelMemory(userId) {
  const result = await query(`SELECT * FROM user_ai_memory WHERE user_id = $1`, [userId]);
  return result.rows[0] || null;
}

export async function deleteUserTravelMemory(userId) {
  await query(`DELETE FROM user_ai_memory WHERE user_id = $1`, [userId]);
}