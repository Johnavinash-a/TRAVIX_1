import { query } from '../pool.js';

export async function createPreference({ userId, category, weight }) {
  const result = await query(
    `INSERT INTO travel_preferences (user_id, category, weight, created_at)
     VALUES ($1, $2, $3, NOW())
     ON CONFLICT (user_id, category) DO UPDATE SET
       weight = EXCLUDED.weight
     RETURNING *`,
    [userId, category, weight]
  );
  return result.rows[0];
}

export async function findPreferencesByUserId(userId) {
  const result = await query(
    `SELECT category, weight FROM travel_preferences WHERE user_id = $1`,
    [userId]
  );
  return result.rows;
}

export async function deletePreferencesByUserId(userId) {
  await query(`DELETE FROM travel_preferences WHERE user_id = $1`, [userId]);
}

export async function upsertPreferences(userId, preferences) {
  // preferences is an array of { category, weight }
  const client = await import('../pool.js').then(m => m.getClient());
  try {
    await client.query('BEGIN');
    await client.query(`DELETE FROM travel_preferences WHERE user_id = $1`, [userId]);
    for (const pref of preferences) {
      await client.query(
        `INSERT INTO travel_preferences (user_id, category, weight, created_at)
         VALUES ($1, $2, $3, NOW())`,
        [userId, pref.category, pref.weight]
      );
    }
    await client.query('COMMIT');
    return true;
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
}