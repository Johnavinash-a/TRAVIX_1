import pg from 'pg';
const { Pool } = pg;

const DATABASE_URL = process.env.DATABASE_URL;

if (!DATABASE_URL) {
  console.warn('WARNING: DATABASE_URL not set. Database features will be unavailable.');
}

const pool = DATABASE_URL ? new Pool({
  connectionString: DATABASE_URL,
  max: 20,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 5000,
  ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false,
}) : null;

export async function query(text, params) {
  if (!pool) {
    throw new Error('Database not configured. Set DATABASE_URL environment variable.');
  }
  const start = Date.now();
  const res = await pool.query(text, params);
  const duration = Date.now() - start;
  if (process.env.NODE_ENV !== 'production') {
    console.log('Executed query', { text: text.substring(0, 100), duration, rows: res.rowCount });
  }
  return res;
}

export async function getClient() {
  if (!pool) {
    throw new Error('Database not configured. Set DATABASE_URL environment variable.');
  }
  return pool.connect();
}

export async function closePool() {
  if (pool) {
    await pool.end();
  }
}

export function isConnected() {
  return pool !== null;
}

export { pool };