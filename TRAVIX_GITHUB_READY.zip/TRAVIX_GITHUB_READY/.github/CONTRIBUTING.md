# Contributing to TRAVIX

Thank you for your interest in contributing! This document outlines the process for contributing to the TRAVIX project.

## 🤝 Code of Conduct

By participating, you agree to uphold our [Code of Conduct](CODE_OF_CONDUCT.md). Please report unacceptable behavior to conduct@travix.ai.

## 🚀 Getting Started

1. **Fork** the repository
2. **Clone** your fork: `git clone https://github.com/YOUR_USERNAME/travix.git`
3. **Create a branch**: `git checkout -b feature/your-feature-name`
4. **Make changes** following our guidelines below
5. **Test** your changes: `npm test && npm run lint && npm run typecheck`
6. **Submit a PR** with a clear description

## 📋 Pull Request Process

### Before Submitting
- [ ] Tests pass (`npm test`)
- [ ] Linting passes (`npm run lint`)
- [ ] Type checking passes (`npm run typecheck`)
- [ ] Build succeeds (`npm run build`)
- [ ] Added/updated tests for new functionality
- [ ] Updated documentation if needed

### PR Title Format
Use conventional commits:
- `feat: add new travel recommendation algorithm`
- `fix: resolve map rendering issue on mobile`
- `docs: update deployment guide for Fly.io`
- `refactor: simplify SmartMap component`
- `test: add integration tests for auth flow`

### PR Template
Fill out the PR template completely:
- Description of changes
- Related issue number
- Screenshots (for UI changes)
- Testing instructions

## 🧪 Testing Guidelines

### Unit Tests
- Test individual components in isolation
- Use Vitest + React Testing Library
- Mock external dependencies (fetch, Mapbox, etc.)

```bash
npm test                    # Run all tests
npm run test:watch          # Watch mode
npm run test:ui             # Visual UI
```

### Integration Tests
- Test component interactions
- Test API integration with mocked fetch
- Test authentication flows

### E2E Tests (Future)
- Will use Playwright for full user flows

## 🎨 Code Style

### TypeScript/JSX
- Strict TypeScript enabled
- Functional components with hooks
- Named exports for components
- Props interfaces with `Props` suffix

```tsx
interface ButtonProps {
  onClick: () => void;
  children: React.ReactNode;
  variant?: 'primary' | 'secondary';
}

export function Button({ onClick, children, variant = 'primary' }: ButtonProps) {
  return <button className={variant} onClick={onClick}>{children}</button>;
}
```

### CSS/Tailwind
- Use Tailwind utility classes
- Custom CSS only when necessary
- Follow mobile-first responsive design

### Naming Conventions
- Components: `PascalCase` (`SmartMap.jsx`)
- Hooks: `useCamelCase` (`useMapContext`)
- Utilities: `camelCase` (`formatDate`)
- Constants: `UPPER_SNAKE_CASE` (`MAX_WAYPOINTS`)

## 📦 Commit Guidelines

Follow [Conventional Commits](https://www.conventionalcommits.org/):

```
<type>(<scope>): <description>

[optional body]

[optional footer]
```

Types:
- `feat` - New feature
- `fix` - Bug fix
- `docs` - Documentation
- `style` - Formatting (no code change)
- `refactor` - Code restructuring
- `test` - Adding tests
- `chore` - Maintenance

Example:
```
feat(ai): add Gemini 1.5 Flash support for recommendations

- Add model selection to AIProvider
- Update cost tracking for new model
- Add fallback to 1.5 Pro

Closes #123
```

## 🌿 Branch Strategy

| Branch | Purpose |
|--------|---------|
| `main` | Production-ready code |
| `develop` | Integration branch (optional) |
| `feature/*` | New features |
| `fix/*` | Bug fixes |
| `hotfix/*` | Urgent production fixes |
| `release/*` | Release preparation |

### Branch Naming
- `feature/travel-plan-sharing`
- `fix/map-rendering-mobile`
- `hotfix/auth-token-expiry`

## 🔍 Code Review Checklist

### For Authors
- [ ] Self-reviewed code
- [ ] Tests added/updated
- [ ] Documentation updated
- [ ] No console.log/debugger
- [ ] No commented-out code

### For Reviewers
- [ ] Code follows style guide
- [ ] Tests cover new functionality
- [ ] No security vulnerabilities
- [ ] Performance considerations addressed
- [ ] Accessibility maintained

## 🐛 Reporting Bugs

Use the bug report template:
1. Clear title and description
2. Steps to reproduce
3. Expected vs actual behavior
4. Screenshots/logs
5. Environment (OS, browser, Node version)

## 💡 Feature Requests

Use the feature request template:
1. Problem statement
2. Proposed solution
3. Alternatives considered
4. Additional context

## 📚 Documentation

Update relevant docs when:
- Adding new API endpoints
- Changing configuration
- Adding new dependencies
- Modifying deployment process

Files to update:
- `README.md`
- `DEPLOYMENT.md`
- `docs/` (if applicable)
- Code comments for complex logic

## 🏷️ Versioning

We follow [Semantic Versioning](https://semver.org/):
- `MAJOR` - Breaking changes
- `MINOR` - New features (backward compatible)
- `PATCH` - Bug fixes (backward compatible)

Releases are automated via GitHub Actions on tag push (`v*`).

## 📞 Getting Help

- **Questions**: [GitHub Discussions](https://github.com/OWNER/REPO/discussions)
- **Bugs**: [GitHub Issues](https://github.com/OWNER/REPO/issues)
- **Security**: [Security Policy](SECURITY.md)
- **Discord**: [Community Server](https://discord.gg/travix) (if available)

---

**Thank you for contributing to TRAVIX!** 🎒