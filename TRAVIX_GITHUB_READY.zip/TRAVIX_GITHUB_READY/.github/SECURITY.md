# Security Policy

## 🔒 Supported Versions

| Version | Supported |
|---------|-----------|
| 1.x.x   | ✅ Yes    |
| < 1.0   | ❌ No     |

## 🛡️ Reporting a Vulnerability

**Please do NOT report security vulnerabilities via public GitHub issues.**

Instead, report them privately via:

### Preferred: GitHub Security Advisories
1. Go to the repository's **Security** tab
2. Click **Report a vulnerability**
3. Fill in the details

### Alternative: Email
Send details to: **security@travix.ai**

Include:
- Description of the vulnerability
- Steps to reproduce
- Potential impact
- Suggested fix (if any)
- Your contact information

## ⏱️ Response Timeline

| Severity | Response | Resolution Target |
|----------|----------|-------------------|
| Critical | 24 hours | 72 hours |
| High     | 48 hours | 1 week |
| Medium   | 72 hours | 2 weeks |
| Low      | 1 week   | Next release |

## 🛡️ Security Measures

### Authentication & Authorization
- JWT tokens with RS256 (production) / HS256 (dev)
- bcrypt password hashing (cost factor 10)
- Token expiration (7 days default)
- Rate limiting on auth endpoints (5 req/s)

### Data Protection
- HTTPS enforced in production
- Secure cookies (HttpOnly, Secure, SameSite)
- CSP headers configured
- No sensitive data in logs

### Infrastructure
- Non-root Docker containers
- Read-only root filesystem (where possible)
- Minimal base images (Alpine/slim)
- Regular dependency updates (Dependabot)

### API Security
- Input validation on all endpoints
- Parameterized queries (no SQL injection)
- CORS configured per environment
- Request size limits (10MB default)

## 🔑 Secret Management

### Development
- `.env.local` (gitignored)
- Never commit real secrets

### Production
- GitHub Secrets / Platform secrets
- Rotated quarterly
- JWT_SECRET: 32+ chars, base64
- Database passwords: 24+ chars

## 📋 Vulnerability Disclosure Process

1. **Report received** → Acknowledgment within 24h
2. **Triage** → Severity assessment within 48h
3. **Fix development** → Target based on severity
4. **Testing** → Regression + security tests
5. **Release** → Patch version + security advisory
6. **Disclosure** → Public advisory after fix deployed

## 🏆 Hall of Fame

We recognize responsible disclosure:

| Researcher | Vulnerability | Date |
|------------|---------------|------|
| (awaiting first report) | | |

## 📞 Contact

- **Security Email**: security@travix.ai
- **PGP Key**: [Available on keyserver](https://keys.openpgp.org/search?q=travix.ai)
- **Bug Bounty**: Not currently offered (planned for v2.0)

---

**Thank you for helping keep TRAVIX secure!** 🛡️