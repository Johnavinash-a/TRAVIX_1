---
name: Pull Request Template
description: Standard PR template for TRAVIX
title: "[TYPE] Brief description"
labels: ["needs-review"]
assignees: []
---

## 📋 Description

Brief description of what this PR does.

## 🔗 Related Issue

Closes #(issue number)

## 🎯 Type of Change

- [ ] 🐛 Bug fix (non-breaking change fixing an issue)
- [ ] ✨ New feature (non-breaking change adding functionality)
- [ ] 💥 Breaking change (fix or feature causing existing functionality to change)
- [ ] 📝 Documentation update
- [ ] ♻️ Refactoring (no functional changes)
- [ ] ✅ Test additions/updates
- [ ] 🔧 Chore/maintenance

## 🧪 Testing

- [ ] Unit tests pass (`npm test`)
- [ ] Linting passes (`npm run lint`)
- [ ] Type checking passes (`npm run typecheck`)
- [ ] Build succeeds (`npm run build`)
- [ ] Added new tests for new functionality
- [ ] Updated existing tests if needed
- [ ] Manual testing performed

### Test Coverage
- [ ] New components tested
- [ ] Edge cases covered
- [ ] Integration points tested

## 📸 Screenshots (UI Changes)

| Before | After |
|--------|-------|
| ![before](url) | ![after](url) |

## 📝 Checklist

- [ ] Code follows project style guide
- [ ] Self-reviewed the code
- [ ] No `console.log` or `debugger` statements
- [ ] No commented-out code
- [ ] Variables/functions named clearly
- [ ] Complex logic commented
- [ ] Documentation updated (README, DEPLOYMENT.md, etc.)
- [ ] CHANGELOG.md updated (if applicable)

## 🚀 Deployment Notes

- [ ] No breaking changes
- [ ] Database migrations needed (if yes, describe)
- [ ] Environment variables added (if yes, list them)
- [ ] Feature flags needed (if yes, describe)

## 📋 Additional Context

Any other information, configuration, or data that might be necessary to review this PR.