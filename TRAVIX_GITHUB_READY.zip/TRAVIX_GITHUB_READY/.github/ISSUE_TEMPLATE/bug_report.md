---
name: Bug Report
description: Report a bug in TRAVIX
title: "[BUG] Brief description"
labels: ["bug", "needs-triage"]
assignees: []
---

## 🐛 Bug Description

Clear and concise description of the bug.

## 🔄 Steps to Reproduce

1. Go to '...'
2. Click on '...'
3. Scroll down to '...'
4. See error

## ✅ Expected Behavior

What you expected to happen.

## ❌ Actual Behavior

What actually happened.

## 📸 Screenshots/Logs

If applicable, add screenshots or error logs.

## 🖥️ Environment

- OS: [e.g., macOS 14.5, Windows 11, Ubuntu 22.04]
- Browser: [e.g., Chrome 125, Firefox 126, Safari 17]
- Node Version: [e.g., 20.15.0]
- npm Version: [e.g., 10.7.0]
- Deployment: [Local / Docker / Railway / Render / Fly.io / Kubernetes]

## 📦 Versions

- TRAVIX Version: [e.g., 1.2.3]
- Dependencies: [run `npm list` and paste relevant]

## 🔍 Additional Context

Any other information, configuration, or data that might help resolve the issue.