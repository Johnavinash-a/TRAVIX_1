---
name: Documentation Improvement
description: Suggest improvements to documentation
title: "[DOCS] Brief description"
labels: ["documentation", "needs-triage"]
assignees: []
---

## 📄 Documentation Issue

What documentation needs improvement?

- [ ] README.md
- [ ] DEPLOYMENT.md
- [ ] CONTRIBUTING.md
- [ ] API Documentation
- [ ] Code Comments
- [ ] Other: ___________

## 🔍 Current State

What's currently wrong or missing?

## ✨ Suggested Improvement

What should be changed or added?

## 📍 Location

File(s) and line numbers (if applicable):

## ✅ Acceptance Criteria

- [ ] Clear and concise
- [ ] Accurate and up-to-date
- [ ] Follows style guide
- [ ] Includes examples

## 📝 Additional Context

Any other information that might be helpful.