# TRAVIX - AI-Powered Smart Travel Platform

[![CI/CD](https://github.com/OWNER/REPO/actions/workflows/ci.yml/badge.svg)](https://github.com/OWNER/REPO/actions/workflows/ci.yml)
[![Docker](https://github.com/OWNER/REPO/actions/workflows/docker.yml/badge.svg)](https://github.com/OWNER/REPO/actions/workflows/docker.yml)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Node](https://img.shields.io/badge/Node-20+-green.svg)](https://nodejs.org/)
[![React](https://img.shields.io/badge/React-19-blue.svg)](https://react.dev/)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.5-blue.svg)](https://www.typescriptlang.org/)

Plan smarter journeys with AI-powered routes, real-time weather, personalized places, and cinematic Himalayan experiences.

## 🚀 Quick Deploy to GitHub

### Option 1: GitHub Codespaces (Instant Dev Environment)
[![Open in GitHub Codespaces](https://github.com/codespaces/badge.svg)](https://codespaces.new/OWNER/REPO)

### Option 2: Deploy to Railway (One-Click)
[![Deploy on Railway](https://railway.app/button.svg)](https://railway.app/template/OWNER/REPO)

### Option 3: Deploy to Render
[![Deploy to Render](https://render.com/images/deploy-to-render-button.svg)](https://render.com/deploy?repo=https://github.com/OWNER/REPO)

### Option 4: Deploy to Fly.io
```bash
fly launch --dockerfile Dockerfile --name travix
fly secrets set JWT_SECRET=$(openssl rand -base64 32)
fly deploy
```

---

## 📦 Project Structure

```
travix/
├── .github/
│   ├── workflows/
│   │   ├── ci.yml              # CI/CD pipeline
│   │   └── docker.yml          # Docker build & push
│   ├── dependabot.yml          # Dependency updates
│   ├── CODEOWNERS              # Code ownership
│   ├── CONTRIBUTING.md         # Contribution guide
│   ├── SECURITY.md             # Security policy
│   └── PULL_REQUEST_TEMPLATE.md
├── docker/
│   ├── Dockerfile              # Multi-stage Node.js build
│   ├── Dockerfile.spatial      # Multi-stage Python build
│   └── docker-compose.yml      # Local dev stack
├── k8s/                        # Kubernetes manifests
├── nginx/
│   └── nginx.conf              # Production reverse proxy
├── server/                     # Express + FastAPI backend
├── src/                        # React 19 frontend
├── .dockerignore
├── .env.example
├── .env.production
├── package.json
├── tsconfig.json
├── vite.config.ts
├── vitest.config.ts
└── README.md
```

---

## 🛠️ Tech Stack

| Layer | Technology |
|-------|------------|
| **Frontend** | React 19, Vite 6, Tailwind CSS 4, Framer Motion |
| **Backend** | Node.js 20, Express 4, FastAPI (Python 3.11) |
| **Database** | PostgreSQL 16 + PostGIS 3.4 |
| **AI** | Google Gemini (optional) + Rule-based fallback |
| **Maps** | Mapbox GL JS (optional) + SVG fallback |
| **Weather** | OpenWeatherMap API (optional) + Demo data |
| **Auth** | JWT (bcryptjs + jsonwebtoken) |
| **Testing** | Vitest, React Testing Library |
| **CI/CD** | GitHub Actions, Docker, GHCR |

---

## 🏃 Quick Start

### Prerequisites
- Node.js 20+
- Docker & Docker Compose (for full stack)
- Python 3.11+ (for spatial service)

### Local Development

```bash
# 1. Clone
git clone https://github.com/OWNER/REPO.git
cd travix

# 2. Install dependencies
npm install

# 3. Configure environment
cp .env.example .env.local
# Edit .env.local with your API keys

# 4. Start development (frontend + backend)
npm run dev:full

# Or separately:
npm run dev          # Frontend: http://localhost:5173
npm run server:dev   # Backend:  http://localhost:5000
```

### Full Stack with Docker

```bash
# 1. Configure
cp .env.production .env
# Edit .env with secrets

# 2. Start all services
docker-compose up -d --build

# 3. Verify
curl http://localhost:5000/api/health
```

Services:
- **Web**: http://localhost:5000
- **Spatial API**: http://localhost:8000
- **PostGIS**: localhost:5432

---

## 🔧 Available Scripts

| Command | Description |
|---------|-------------|
| `npm run dev` | Start Vite dev server |
| `npm run build` | Production build frontend |
| `npm run preview` | Preview production build |
| `npm run server:dev` | Start Express backend |
| `npm run dev:full` | Start both frontend + backend |
| `npm run start` | Production server (serves dist/) |
| `npm test` | Run tests (Vitest) |
| `npm run test:ui` | Test UI |
| `npm run lint` | ESLint |
| `npm run typecheck` | TypeScript check |

---

## 🌐 Environment Variables

### Required for Production
```env
NODE_ENV=production
PORT=5000
JWT_SECRET=your-super-secure-random-string-min-32-chars
POSTGRES_PASSWORD=your-secure-db-password
```

### Optional (Enable Features)
```env
GEMINI_API_KEY=your-gemini-key          # AI responses
OPENWEATHER_API_KEY=your-owm-key        # Live weather
VITE_MAPBOX_TOKEN=your-mapbox-token     # Real map tiles
VITE_API_BASE=https://your-domain.com   # API base URL
```

### Docker Compose (Auto-configured)
```env
POSTGRES_USER=postgres
POSTGRES_DB=travelwise
OSRM_ENGINE_URL=http://router.project-osrm.org
```

---

## 🐳 Docker Deployment

### Build Images
```bash
# Web (Node.js)
docker build -t travix-web -f docker/Dockerfile .

# Spatial (Python FastAPI)
docker build -t travix-spatial -f docker/Dockerfile.spatial .
```

### Run with Docker Compose
```bash
# Development
docker-compose -f docker/docker-compose.yml up -d

# Production
docker-compose -f docker/docker-compose.prod.yml up -d
```

### Push to Registry
```bash
docker tag travix-web ghcr.io/OWNER/REPO-web:latest
docker tag travix-spatial ghcr.io/OWNER/REPO-spatial:latest
docker push ghcr.io/OWNER/REPO-web:latest
docker push ghcr.io/OWNER/REPO-spatial:latest
```

---

## ☸️ Kubernetes Deployment

```bash
# Apply manifests
kubectl apply -f k8s/

# Check status
kubectl get pods -n travix
kubectl get svc -n travix
```

Manifests include:
- `k8s/namespace.yaml`
- `k8s/configmap.yaml`
- `k8s/secret.yaml` (create from .env.production)
- `k8s/web-deployment.yaml`
- `k8s/spatial-deployment.yaml`
- `k8s/postgis-statefulset.yaml`
- `k8s/ingress.yaml`
- `k8s/hpa.yaml`

---

## 🔄 CI/CD Pipeline

GitHub Actions (`.github/workflows/ci.yml`):

1. **Lint & Test** → ESLint, TypeScript, Vitest
2. **Build** → Vite production build
3. **Docker** → Multi-stage builds → Push to GHCR
3. **Deploy** → Staging (PRs) / Production (main)

### Triggers
- Push to `main` → Production deploy
- Pull Request → Preview deploy
- Tags `v*` → Release + GHCR publish

### Required Secrets (GitHub Settings → Secrets)
| Secret | Description |
|--------|-------------|
| `JWT_SECRET` | Auth token signing |
| `GEMINI_API_KEY` | Google AI |
| `OPENWEATHER_API_KEY` | Weather API |
| `VITE_MAPBOX_TOKEN` | Mapbox GL |
| `POSTGRES_PASSWORD` | Database |
| `RAILWAY_TOKEN` | Railway deploy (optional) |
| `RENDER_API_KEY` | Render deploy (optional) |

---

## 🧪 Testing

```bash
# Run all tests
npm test

# Watch mode
npm run test:watch

# UI mode
npm run test:ui

# Coverage
npm test -- --coverage
```

Test structure:
```
src/
├── components/
│   ├── *.test.jsx          # Component tests
│   └── App.integration.test.jsx
├── lib/
│   └── logger.test.ts
└── test/
    └── setup.ts
```

---

## 📝 API Endpoints

### Authentication
- `POST /api/auth/register` - Register user
- `POST /api/auth/login` - Login
- `GET /api/auth/me` - Get current user

### AI & Recommendations
- `POST /api/ai/chat` - Conversational AI
- `POST /api/ai/recommend` - Destination recommendations
- `GET /api/ai/memory?userId=xxx` - User travel memory

### Trips (Protected)
- `POST /api/trips` - Save trip
- `GET /api/trips` - List user trips

### Weather
- `GET /api/weather?location=London` - Current + forecast

### Spatial (Proxied to FastAPI)
- `GET /api/spatial/search/places` - Place search
- `POST /api/spatial/route/compute` - Route computation
- `GET /api/spatial/health` - Health check

### Health
- `GET /api/health` - Service status

---

## 🔒 Security

- JWT authentication with bcrypt password hashing
- Rate limiting (API: 10/s, Auth: 5/s)
- Helmet.js security headers
- CSP, HSTS, X-Frame-Options
- Non-root Docker containers
- Dependency scanning (Dependabot)
- Secret scanning (GitHub)

See [SECURITY.md](.github/SECURITY.md) for vulnerability reporting.

---

## 🤝 Contributing

1. Fork the repository
2. Create feature branch: `git checkout -b feature/amazing-feature`
3. Commit changes: `git commit -m 'Add amazing feature'`
4. Push to branch: `git push origin feature/amazing-feature`
5. Open Pull Request

See [CONTRIBUTING.md](.github/CONTRIBUTING.md) for details.

---

## 📄 License

MIT License - see [LICENSE](LICENSE) for details.

---

## 🙏 Acknowledgments

- [Mapbox GL JS](https://github.com/mapbox/mapbox-gl-js) for maps
- [OpenWeatherMap](https://openweathermap.org/) for weather data
- [OSRM](http://project-osrm.org/) for routing
- [PostGIS](https://postgis.net/) for spatial database
- [Framer Motion](https://www.framer.com/motion/) for animations
- [Lucide React](https://lucide.dev/) for icons

---

## 📞 Support

- **Issues**: [GitHub Issues](https://github.com/OWNER/REPO/issues)
- **Discussions**: [GitHub Discussions](https://github.com/OWNER/REPO/discussions)
- **Security**: [Security Policy](.github/SECURITY.md)

---

**Made with ❤️ for travelers everywhere**