

import express from 'express';
import cors from 'cors';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';

const app = express();
app.use(cors());
app.use(express.json({ limit: '10mb' }));

const PORT = process.env.PORT || 5000;
const JWT_SECRET = process.env.JWT_SECRET || 'travix-dev-secret-change-in-production';
const JWT_EXPIRES_IN = '7d';

const PORT = process.env.PORT || 5000;
const JWT_SECRET = process.env.JWT_SECRET || 'travix-dev-secret-change-in-production';
const JWT_EXPIRES_IN = '7d';
const SPATIAL_SERVICE_URL = process.env.SPATIAL_SERVICE_URL || 'http://localhost:8000';

// ============================================================================
// SPATIAL SERVICE PROXY
// ============================================================================

async function proxyToSpatialService(path, req, res) {
  try {
    const response = await fetch(`${SPATIAL_SERVICE_URL}${path}`, {
      method: req.method,
      headers: {
        'Content-Type': 'application/json',
        ...(req.headers.authorization && { 'Authorization': req.headers.authorization }),
      },
      body: ['GET', 'HEAD'].includes(req.method) ? undefined : JSON.stringify(req.body),
    });
    const data = await response.json();
    res.status(response.status).json(data);
  } catch (err) {
    res.status(502).json({ error: 'Spatial service unavailable', details: err.message });
  }
}

app.all('/api/spatial/:path*', (req, res) => {
  const path = req.params.path ? `/${req.params.path}` : '';
  const query = new URLSearchParams(req.query).toString();
  const fullPath = `${path}${query ? `?${query}` : ''}`;
  proxyToSpatialService(fullPath, req, res);
});

// Health check for spatial service
app.get('/api/spatial/health', async (req, res) => {
  try {
    const response = await fetch(`${SPATIAL_SERVICE_URL}/health`);
    const data = await response.json();
    res.json(data);
  } catch (err) {
    res.status(503).json({ status: 'unavailable', service: 'spatial', error: err.message });
  }
});

// ============================================================================
// AUTHENTICATION MIDDLEWARE & UTILITIES
// ============================================================================

function generateToken(user) {
  return jwt.sign(
    { userId: user.id, email: user.email, name: user.name },
    JWT_SECRET,
    { expiresIn: JWT_EXPIRES_IN }
  );
}

function verifyToken(token) {
  try {
    return jwt.verify(token, JWT_SECRET);
  } catch (err) {
    return null;
  }
}

function authMiddleware(req, res, next) {
  const authHeader = req.headers.authorization;
  if (!authHeader?.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'No token provided' });
  }
  const token = authHeader.substring(7);
  const decoded = verifyToken(token);
  if (!decoded) {
    return res.status(401).json({ error: 'Invalid or expired token' });
  }
  req.user = decoded;
  next();
}

// ============================================================================
// 1. IN-MEMORY PERSISTENT DATABASE ENGINE
// ============================================================================

class TravixDatabase {
  constructor() {
    this.collections = {
      users: [],
      aiConversations: [],
      aiMessages: [],
      profiles: [],
      preferences: [],
      savedPlaces: [],
      trips: [],
      destinations: [
        {
          id: 'coorg',
          name: 'Coorg (Kodagu)',
          state: 'Karnataka',
          category: 'Hill Station',
          budgetPerDayINR: 3500,
          tags: ['nature', 'coffee', 'waterfall', 'photography', 'local_food'],
          latitude: 12.4200,
          longitude: 75.7400,
          bestTimeToVisit: 'October to March'
        },
        {
          id: 'chikmagalur',
          name: 'Chikmagalur',
          state: 'Karnataka',
          category: 'Hill Station',
          budgetPerDayINR: 3200,
          tags: ['nature', 'coffee', 'trekking', 'photography'],
          latitude: 13.3161,
          longitude: 75.7720,
          bestTimeToVisit: 'September to May'
        },
        {
          id: 'wayanad',
          name: 'Wayanad',
          state: 'Kerala',
          category: 'Nature & Wildlife',
          budgetPerDayINR: 3800,
          tags: ['nature', 'waterfalls', 'wildlife', 'local_food'],
          latitude: 11.6854,
          longitude: 76.1320,
          bestTimeToVisit: 'October to May'
        },
        {
          id: 'munnar',
          name: 'Munnar',
          state: 'Kerala',
          category: 'Tea Gardens & Valleys',
          budgetPerDayINR: 4200,
          tags: ['tea', 'valleys', 'cool', 'scenic', 'nature'],
          latitude: 10.0889,
          longitude: 77.0595,
          bestTimeToVisit: 'September to May'
        },
        {
          id: 'mysore',
          name: 'Mysuru (Mysore)',
          state: 'Karnataka',
          category: 'Royal Palaces & Cultural Heritage',
          budgetPerDayINR: 3000,
          tags: ['palace', 'heritage', 'history', 'silk', 'food'],
          latitude: 12.3052,
          longitude: 76.6552,
          bestTimeToVisit: 'All Year'
        }
      ],
      attractions: [
        { id: 'att_abbey', name: 'Abbey Falls', category: 'Waterfall', city: 'Coorg', lat: 12.4578, lng: 75.7197, accessibility: 'moderate' },
        { id: 'att_raja', name: 'Raja Seat Sunset Viewpoint', category: 'Viewpoint', city: 'Coorg', lat: 12.4184, lng: 75.7369, accessibility: 'senior_friendly' },
        { id: 'att_zoo', name: 'Mysore Zoo', category: 'Park', city: 'Mysuru', lat: 12.3020, lng: 76.6640, accessibility: 'battery_cars' }
      ],
      restaurants: [
        { id: 'rest_mylari', name: 'Original Hotel Vinayaka Mylari', city: 'Mysuru', cuisine: 'Traditional South Indian Dosa', pricePerPersonINR: 150, rating: 4.9 },
        { id: 'rest_pandi', name: 'Coorg Cuisine Restaurant', city: 'Coorg', cuisine: 'Kodava Pandi Curry', pricePerPersonINR: 350, rating: 4.8 }
      ],
      hotels: [
        { id: 'hot_evolve', name: 'Evolve Back Luxury Resort', city: 'Coorg', tier: 'PREMIUM', pricePerNightINR: 18000, rating: 4.9 },
        { id: 'hot_homestay', name: 'Kodagu Coffee Estate Homestay', city: 'Coorg', tier: 'LOCAL', pricePerNightINR: 2800, rating: 4.7 }
      ]
    };
  }

  getCollection(name) {
    if (!this.collections[name]) this.collections[name] = [];
    return this.collections[name];
  }

  find(name, predicate) {
    const list = this.getCollection(name);
    return predicate ? list.filter(predicate) : list;
  }

  findOne(name, predicate) {
    return this.getCollection(name).find(predicate);
  }

  insert(name, item) {
    const list = this.getCollection(name);
    const newItem = { id: item.id || `${name}_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`, createdAt: new Date().toISOString(), ...item };
    list.push(newItem);
    return newItem;
  }

  update(name, predicate, updates) {
    const list = this.getCollection(name);
    const index = list.findIndex(predicate);
    if (index !== -1) {
      list[index] = { ...list[index], ...updates, updatedAt: new Date().toISOString() };
      return list[index];
    }
    return null;
  }
}

const db = new TravixDatabase();

// ============================================================================
// 2. AI MODEL ABSTRACTION PROVIDER
// ============================================================================

class AIProvider {
  async generateResponse(systemPrompt, userPrompt, context = {}) {
    return `Travix Agent: Processed request for "${userPrompt}".`;
  }
}

class GeminiAIProvider extends AIProvider {
  constructor(apiKey) {
    super();
    this.apiKey = apiKey;
  }

  async generateResponse(systemPrompt, userPrompt, context = {}) {
    try {
      const { GoogleGenerativeAI } = await import('@google/generative-ai');
      const genAI = new GoogleGenerativeAI(this.apiKey);
      const model = genAI.getGenerativeModel({ model: 'gemini-1.5-flash' });
      const result = await model.generateContent(`${systemPrompt}\n\nUser Context: ${JSON.stringify(context)}\n\nRequest: ${userPrompt}`);
      return result.response.text();
    } catch (err) {
      return `Travix Intelligent Engine: Recommended options for ${userPrompt}.`;
    }
  }
}

function createAIProvider() {
  if (process.env.GEMINI_API_KEY) {
    return new GeminiAIProvider(process.env.GEMINI_API_KEY);
  }
  return new AIProvider();
}

// ============================================================================
// 3. INTENT ROUTER & DOMAIN GUARDRAILS
// ============================================================================

const NON_TRAVEL_KEYWORDS = [
  'java', 'python', 'programming', 'code', 'math homework', 'solve equation',
  'who is president', 'quantum physics', 'stock market', 'crypto'
];

function detectIntentAndDomain(message) {
  if (!message || typeof message !== 'string') return { isTravelDomain: true, intent: 'GENERAL_TRAVEL' };
  const text = message.toLowerCase().trim();

  if (NON_TRAVEL_KEYWORDS.some(kw => text.includes(kw))) {
    return {
      isTravelDomain: false,
      intent: 'NON_TRAVEL_REJECT',
      redirectMessage: "I'm your Travix travel assistant. I can help you plan trips, find places, routes, food, hotels and experiences. What destination are you planning to visit?"
    };
  }

  return { isTravelDomain: true, intent: 'TRAVEL_QUERY' };
}

// ============================================================================
// 4. MAP HANDOFF & GOOGLE MAPS TOOLS
// ============================================================================

function buildMapAction(type, destination, origin = null) {
  const destQuery = destination.query || `${destination.name}, ${destination.city || destination.state || ''}`;
  const encodedDest = encodeURIComponent(destQuery);
  const lat = destination.latitude || destination.lat || 12.42;
  const lng = destination.longitude || destination.lng || 75.74;

  let googleMapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodedDest}`;
  if (origin) {
    const originQuery = origin.name || origin.city || origin;
    googleMapsUrl = `https://www.google.com/maps/dir/?api=1&origin=${encodeURIComponent(originQuery)}&destination=${encodedDest}`;
  }

  return {
    action: "OPEN_GOOGLE_MAPS",
    type: "OPEN_GOOGLE_MAPS",
    destination: {
      name: destination.name,
      city: destination.city || destination.state || '',
      latitude: lat,
      longitude: lng
    },
    googleMapsUrl,
    mapData: {
      center: { lat, lng },
      zoom: 12,
      marker: { title: destination.name, lat, lng }
    }
  };
}

function haversineDistanceKm(lat1, lon1, lat2, lon2) {
  const r = 6371.0;
  const dlat = (lat2 - lat1) * (Math.PI / 180);
  const dlon = (lon2 - lon1) * (Math.PI / 180);
  const a = Math.sin(dlat / 2) ** 2 + Math.cos(lat1 * (Math.PI / 180)) * Math.cos(lat2 * (Math.PI / 180)) * Math.sin(dlon / 2) ** 2;
  return r * (2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a)));
}

// ============================================================================
// 5. GROUP DEMOGRAPHICS & AGE CRITERIA PLANNER
// ============================================================================

function analyzeGroupDemographics(travelers = []) {
  if (!travelers || !travelers.length) {
    return { totalCount: 1, hasChildren: false, hasSeniors: false, pacingTag: 'STANDARD_ACTIVE' };
  }

  let childrenCount = 0;
  let seniorCount = 0;

  travelers.forEach(t => {
    const age = typeof t === 'object' ? (t.age || 25) : parseInt(t) || 25;
    if (age <= 12) childrenCount++;
    else if (age >= 60) seniorCount++;
  });

  const hasChildren = childrenCount > 0;
  const hasSeniors = seniorCount > 0;

  let pacingTag = 'HIGH_ENERGY';
  if (hasSeniors && hasChildren) pacingTag = 'FAMILY_RELAXED_ACCESSIBLE';
  else if (hasSeniors) pacingTag = 'SENIOR_ADAPTED_PAVED';
  else if (hasChildren) pacingTag = 'KIDS_FAMILY_SAFE';

  return {
    totalCount: travelers.length,
    childrenCount,
    seniorCount,
    hasChildren,
    hasSeniors,
    pacingTag
  };
}

// ============================================================================
// 6. PERSISTENT USER MEMORY & PREFERENCE SCORING
// ============================================================================

function loadUserTravelMemory(userId) {
  const profile = db.findOne('profiles', p => p.userId === userId) || {};
  return {
    userId,
    homeCity: profile.city || 'Bengaluru',
    travelerCount: profile.travelerCount || 2,
    preferences: profile.preferences || { nature: 0.8, food: 0.75, photography: 0.7 }
  };
}

// ============================================================================
// 7. COMPOSITE RANKING & RECOMMENDATION ENGINE
// ============================================================================

function recommendDestinations(context = {}) {
  const { location = 'Bengaluru', budget = 15000, duration = 2, travelers = [{ age: 25 }, { age: 26 }] } = context;
  const demographics = analyzeGroupDemographics(travelers);
  const candidateDestinations = db.find('destinations');

  return candidateDestinations.map(dest => {
    let recommendationScore = 77;
    if (demographics.hasSeniors && (dest.id === 'coorg' || dest.id === 'mysore')) recommendationScore += 12;
    if (demographics.hasChildren && dest.id === 'mysore') recommendationScore += 10;

    const estimatedCostINR = (dest.budgetPerDayINR || 3500) * duration * travelers.length;
    const mapAction = buildMapAction("OPEN_GOOGLE_MAPS", dest, location);

    return {
      name: dest.name,
      location: `${dest.state}, India`,
      reason: `Recommended because you enjoy nature, and it matches your group pacing for ${travelers.length} traveler(s).`,
      recommendationScore: Math.min(99, recommendationScore),
      weatherScore: 92,
      preferenceScore: 78,
      budgetEstimate: `₹${estimatedCostINR.toLocaleString('en-IN')}`,
      estimatedTravelTime: `4.5 hours drive from ${location}`,
      bestTimeToVisit: dest.bestTimeToVisit || 'October to March',
      categories: dest.tags || ['Nature', 'Hill Station'],
      places: [
        { name: `${dest.name} Viewpoint`, category: "Attraction" },
        { name: "Local Specialty Restaurant", category: "Food" }
      ],
      mapData: mapAction.mapData,
      mapAction
    };
  }).sort((a, b) => b.recommendationScore - a.recommendationScore);
}

// ============================================================================
// 8. INTELLIGENT QUESTION GENERATOR
// ============================================================================

function generateIntelligentFollowUpQuestion(state) {
  if (!state.travelersCount && (!state.travelers || !state.travelers.length)) {
    return "How many people are travelling?";
  }
  if (!state.travelers || !state.travelers.length) {
    return "What are the age groups of the travelers (e.g. 25, 54 and 8)?";
  }
  if (!state.budget) {
    return "What is your approximate budget for the trip (e.g. ₹15,000)?";
  }
  if (!state.preferences || !state.preferences.length) {
    return "What would you prefer: nature, food, adventure, history, shopping, or a mixture?";
  }
  return null;
}

// ============================================================================
// 9. CORE CONVERSATIONAL AGENT FUNCTION
// ============================================================================

export async function travelAgent(message, conversationId = 'conv_default', userId = 'user_default') {
  // 1. Guardrail Verification
  const domainCheck = detectIntentAndDomain(message);
  if (!domainCheck.isTravelDomain) {
    return {
      message: domainCheck.redirectMessage,
      intent: "NON_TRAVEL_REJECT",
      recommendations: [],
      mapActions: [],
      followUpQuestion: null
    };
  }

  // 2. Load Memory & Conversation State
  const memory = loadUserTravelMemory(userId);
  let convRecord = db.findOne('aiConversations', c => c.id === conversationId);
  if (!convRecord) {
    convRecord = db.insert('aiConversations', {
      id: conversationId,
      userId,
      state: { conversationId, userId, travelers: null, budget: null, preferences: [] }
    });
  }

  const state = convRecord.state;
  const text = message.toLowerCase();

  // 3. Extract Travel Parameters
  if (text.includes('coorg')) state.destination = 'Coorg';
  if (text.includes('bengaluru') || text.includes('bangalore')) state.origin = 'Bengaluru';

  const budgetMatch = text.match(/(?:₹|rs\.?|rupees)?\s*(\d{1,2},?\d{3})/i);
  if (budgetMatch) state.budget = parseInt(budgetMatch[1].replace(',', ''));

  const numbersInMsg = text.match(/\b\d{1,2}\b/g);
  if (text.includes('ages') || (numbersInMsg && numbersInMsg.length >= 2)) {
    const parsedAges = (numbersInMsg || []).map(n => parseInt(n)).filter(n => n > 0 && n <= 100);
    if (parsedAges.length >= 2) {
      state.travelers = parsedAges.map(age => ({ age }));
      state.travelersCount = parsedAges.length;
    }
  } else if (numbersInMsg && numbersInMsg.length === 1 && !state.budget) {
    const count = parseInt(numbersInMsg[0]);
    if (count > 0 && count <= 20) {
      state.travelersCount = count;
      state.travelers = Array.from({ length: count }, () => ({ age: 25 }));
    }
  }

  if (text.includes('nature')) state.preferences.push('nature');
  if (text.includes('food')) state.preferences.push('food');

  db.update('aiConversations', c => c.id === conversationId, { state });

  // 4. Check Follow-Up Question
  const followUp = generateIntelligentFollowUpQuestion(state);
  if (followUp && !state.destination) {
    return {
      message: followUp,
      intent: "GENERAL_TRAVEL",
      recommendations: [],
      mapActions: [],
      followUpQuestion: followUp,
      conversationState: state
    };
  }

  // 5. Run Group Intelligence & Recommendations
  const groupAnalysis = analyzeGroupDemographics(state.travelers || [{ age: 25 }, { age: 26 }]);
  const recommendations = recommendDestinations({
    location: state.origin || memory.homeCity || 'Bengaluru',
    budget: state.budget || 15000,
    duration: 2,
    travelers: state.travelers || [{ age: 25 }, { age: 26 }]
  }).slice(0, 3);

  const mapActions = recommendations.map(r => r.mapAction);

  let responseMessage = `I found ${recommendations.length} trips that fit your group and budget:\n\n`;
  recommendations.forEach((rec, idx) => {
    responseMessage += `${idx + 1}. ${rec.name}\nNature Score: ${rec.recommendationScore}/100 | Family Suitability: ${groupAnalysis.hasSeniors ? '92/100 (Senior Adapted)' : '95/100'}\nEstimated Cost: ${rec.budgetEstimate}\n${rec.reason}\n\n`;
  });

  return {
    message: responseMessage.trim(),
    intent: "DESTINATION_SEARCH",
    recommendations,
    groupPacingTag: groupAnalysis.pacingTag,
    mapActions,
    followUpQuestion: null
  };
}

// ============================================================================
// 10. EXPRESS REST API ENDPOINTS
// ============================================================================

app.post('/api/ai/chat', authMiddleware, async (req, res) => {
  try {
    const { message, conversationId } = req.body;
    const userId = req.user?.userId || req.body.userId || 'user_demo';
    const response = await travelAgent(message || 'Suggest a trip', conversationId || 'conv_demo', userId);
    res.json(response);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/ai/chat', (req, res) => {
  // Fallback without auth for backward compatibility
  try {
    const { message, conversationId, userId } = req.body;
    const response = await travelAgent(message || 'Suggest a trip', conversationId || 'conv_demo', userId || 'user_demo');
    res.json(response);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/ai/recommend', (req, res) => {
  const recommendations = recommendDestinations(req.body);
  res.json({ status: 'SUCCESS', count: recommendations.length, recommendations });
});

app.get('/api/ai/memory', (req, res) => {
  const memory = loadUserTravelMemory(req.query.userId || 'user_demo');
  res.json({ status: 'SUCCESS', memory });
});

// ============================================================================
// AUTHENTICATION ENDPOINTS
// ============================================================================

app.post('/api/auth/register', async (req, res) => {
  try {
    const { email, password, name } = req.body;
    if (!email || !password || !name) {
      return res.status(400).json({ error: 'Email, password, and name are required' });
    }
    const existingUser = db.findOne('users', u => u.email === email);
    if (existingUser) {
      return res.status(409).json({ error: 'Email already registered' });
    }
    const hashedPassword = await bcrypt.hash(password, 10);
    const user = db.insert('users', {
      email,
      password: hashedPassword,
      name,
      createdAt: new Date().toISOString(),
    });
    const token = generateToken(user);
    res.status(201).json({
      token,
      user: { id: user.id, email: user.email, name: user.name }
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required' });
    }
    const user = db.findOne('users', u => u.email === email);
    if (!user) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }
    const valid = await bcrypt.compare(password, user.password);
    if (!valid) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }
    const token = generateToken(user);
    res.json({
      token,
      user: { id: user.id, email: user.email, name: user.name }
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/auth/me', authMiddleware, (req, res) => {
  const user = db.findOne('users', u => u.id === req.user.userId);
  if (!user) {
    return res.status(404).json({ error: 'User not found' });
  }
  res.json({ user: { id: user.id, email: user.email, name: user.name } });
});

// Protected example: save a trip
app.post('/api/trips', authMiddleware, (req, res) => {
  const trip = db.insert('trips', { ...req.body, userId: req.user.userId, createdAt: new Date().toISOString() });
  res.status(201).json({ status: 'SUCCESS', trip });
});

app.get('/api/trips', authMiddleware, (req, res) => {
  const trips = db.find('trips', t => t.userId === req.user.userId);
  res.json({ status: 'SUCCESS', trips });
});

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', service: 'Travix Standalone Travel AI Agent', timestamp: new Date().toISOString() });
});

// ============================================================================
// 11. WEATHER INTEGRATION (OpenWeatherMap)
// ============================================================================

function calculateTravelScore(temp, humidity, windSpeed, weatherMain) {
  let score = 100;
  if (temp < 15 || temp > 30) score -= 20;
  if (temp < 5 || temp > 38) score -= 30;
  if (humidity > 80) score -= 15;
  if (weatherMain === 'Rain' || weatherMain === 'Drizzle') score -= 25;
  if (weatherMain === 'Thunderstorm' || weatherMain === 'Snow') score -= 45;
  return Math.max(0, score);
}

app.get('/api/weather', async (req, res) => {
  const { location } = req.query;
  if (!location) {
    return res.status(400).json({ error: 'Location parameter is required.' });
  }
  const apiKey = process.env.OPENWEATHER_API_KEY;
  if (!apiKey) {
    return res.status(200).json({
      location: 'Demo Location',
      temp: 18,
      condition: 'Partly Cloudy',
      humidity: 65,
      rainProb: 10,
      windSpeed: '12 km/h',
      sunrise: '06:30 AM',
      sunset: '06:00 PM',
      travelScore: 88,
      travelRecommendation: 'Great conditions for sightseeing and outdoor activities!',
      hourlyForecast: [
        { time: '09:00', temp: 16, condition: 'Clear', rainProb: 0 },
        { time: '12:00', temp: 22, condition: 'Clouds', rainProb: 10 },
        { time: '15:00', temp: 24, condition: 'Clouds', rainProb: 5 },
        { time: '18:00', temp: 20, condition: 'Clear', rainProb: 0 },
        { time: '21:00', temp: 15, condition: 'Clear', rainProb: 0 },
      ],
      demo: true
    });
  }
  try {
    const weatherUrl = `https://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(location)}&units=metric&appid=${apiKey}`;
    const forecastUrl = `https://api.openweathermap.org/data/2.5/forecast?q=${encodeURIComponent(location)}&units=metric&appid=${apiKey}`;
    const [weatherRes, forecastRes] = await Promise.all([
      fetch(weatherUrl),
      fetch(forecastUrl)
    ]);
    if (!weatherRes.ok) {
      return res.status(weatherRes.status).json({ error: 'City not found or API error.' });
    }
    const data = await weatherRes.json();
    const forecastData = await forecastRes.json();

    const hourlyForecast = (forecastData.list || []).slice(0, 5).map(item => {
      const date = new Date(item.dt * 1000);
      return {
        time: date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        temp: Math.round(item.main.temp),
        condition: item.weather[0].main,
        rainProb: Math.round((item.pop || 0) * 100)
      };
    });

    const formatTime = (timestamp) => new Date(timestamp * 1000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const travelScore = calculateTravelScore(data.main.temp, data.main.humidity, data.wind.speed, data.weather[0].main);

    const responsePayload = {
      location: `${data.name}, ${data.sys.country}`,
      temp: Math.round(data.main.temp),
      condition: data.weather[0].description.replace(/\b\w/g, c => c.toUpperCase()),
      humidity: data.main.humidity,
      rainProb: Math.round((forecastData.list?.[0]?.pop || 0) * 100),
      windSpeed: `${Math.round(data.wind.speed * 3.6)} km/h`,
      sunrise: formatTime(data.sys.sunrise),
      sunset: formatTime(data.sys.sunset),
      travelScore: travelScore,
      travelRecommendation: travelScore > 75 ? 'Great conditions for sightseeing and outdoor activities!' : 'Weather conditions are moderate to poor. Plan accordingly.',
      hourlyForecast: hourlyForecast
    };
    res.json(responsePayload);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch weather data from server.' });
  }
});

// ============================================================================
// 12. SERVE FRONTEND IN PRODUCTION
// ============================================================================

import path from 'path';
const __dirname = path.resolve();
app.use(express.static(path.join(__dirname, 'dist')));
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'dist', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`🚀 Travix Personal Travel AI Agent running on http://localhost:${PORT}`);
});