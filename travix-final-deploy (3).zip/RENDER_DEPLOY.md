# Render Deployment Configuration for TRAVIX

## Option 1: Web Service (Recommended)

### Build Command
```bash
npm ci && npm run build
```

### Start Command
```bash
node server/start.js
```

### Environment Variables (set in Render Dashboard)
```
NODE_ENV=production
PORT=10000
JWT_SECRET=<generate: openssl rand -base64 32>
GEMINI_API_KEY=<your-gemini-key>
OPENWEATHER_API_KEY=<your-openweather-key>
VITE_MAPBOX_TOKEN=<your-mapbox-token>
VITE_API_BASE=https://your-app.onrender.com
DATABASE_URL=<from Render PostgreSQL>
SPATIAL_SERVICE_URL=http://localhost:8000
```

### Render PostgreSQL Setup
1. Create PostgreSQL database in Render
2. Copy the **External Database URL** → set as `DATABASE_URL`
3. The app will auto-run migrations on first start (or run manually)

---

## Option 2: Docker (Alternative)

### Dockerfile Path
```
docker/Dockerfile
```

### Build Context
```
.
```

### Environment Variables (same as above)

---

## render.yaml (Infrastructure as Code)

Create `render.yaml` in repo root:

```yaml
services:
  - type: web
    name: travix-web
    runtime: docker
    dockerfilePath: docker/Dockerfile
    envVars:
      - key: NODE_ENV
        value: production
      - key: PORT
        value: "10000"
      - key: JWT_SECRET
        generateValue: true
      - key: GEMINI_API_KEY
        sync: false
      - key: OPENWEATHER_API_KEY
        sync: false
      - key: VITE_MAPBOX_TOKEN
        sync: false
      - key: VITE_API_BASE
        fromService:
          type: web
          name: travix-web
          property: host
    docker:
      buildCommand: npm ci && npm run build
      startCommand: node server/start.js

  - type: pserv
    name: travix-postgres
    plan: starter
    envVars:
      - key: POSTGRES_USER
        value: postgres
      - key: POSTGRES_PASSWORD
        generateValue: true
      - key: POSTGRES_DB
        value: travelwise

databases:
  - name: travix-db
    databaseName: travelwise
    user: postgres
    plan: starter
```

---

## Quick Deploy Steps

1. **Push to GitHub**
2. **Connect repo to Render**
3. **Choose "Web Service" → "Node.js"**
4. **Set Build Command**: `npm ci && npm run build`
5. **Set Start Command**: `node server/start.js`
6. **Add PostgreSQL** → copy URL to `DATABASE_URL`
7. **Set Environment Variables** (see above)
8. **Deploy**

---

## Health Check

Render will probe `/api/health` - ensure it returns 200 when DB + spatial service are healthy.

---

## Notes

- **Spatial Service**: Runs internally in the same container (FastAPI on port 8000)
- **Static Files**: Served by Express from `dist/`
- **WebSockets**: Not used currently
- **Port**: Render assigns `PORT=10000` - app reads `process.env.PORT`